# Adaptive Obstacle Avoidance for Autonomous Drones (IEEE 8491889)

A professional simulation suite implementing the research paper:
> **"Development of Autonomous Drones for Adaptive Obstacle Avoidance in Real World Environments"**  
> *Arne Devos, Emad Samuel Malki Ebeid, Poramate Manoonpong*  
> **IEEE Xplore**: [https://ieeexplore.ieee.org/document/8491889](https://ieeexplore.ieee.org/document/8491889) | 21st Euromicro Conference on Digital System Design (DSD 2018).

---

## 1. Overview & Theoretical Background

Conventional obstacle avoidance in autonomous drones predominantly relies on heavy computer vision or computationally expensive Model Predictive Control (MPC). This paper proposes and validates a **computationally lightweight, bio-inspired adaptive neural controller** that:
1. Requires **zero dynamic model** or offline pre-training.
2. Uses simple dual forward-facing distance sensors (ultrasonic / optical LiDAR).
3. Overcomes complex environmental deadlocks, sharp corners, and narrow passages where classic reactive controllers (e.g. Braitenberg, potential fields) oscillate or become permanently trapped.
4. Dynamically adapts forward speed and turning angle through **synaptic plasticity with homeostatic scaling**.

```
                           +------------------------+
                           | Dual Rangefinders      |
                           | Left (dL) / Right (dR) |
                           +-----------+------------+
                                       |
                           +-----------v------------+
                           | Sensory Normalization  |
                           | I1, I2 in [-1, 1]      |
                           +-----------+------------+
                                       |
                  +--------------------v--------------------+
                  |   2-Neuron Recurrent Network (MRC)     |
                  |                                         |
                  |  O1(t) = tanh(b1*O1 + c*O2 + a1*I1)     |
                  |  O2(t) = tanh(b2*O2 + c*O1 + a1*I2)     |
                  |                                         |
                  |  Synaptic Plasticity (Deadlock Escape): |
                  |  dot{b_i} = mu_b * v_i * T_i - gamma_b  |
                  +--------------------+--------------------+
                                       |
                    +------------------+------------------+
                    |                                     |
         +----------v-----------+             +-----------v------------+
         | Yaw-Rate Steering    |             | Proactive Speed Adapt  |
         | psi_dot = -Ky*(O1-O2)|             | vx = f(max(v1, v2))    |
         +----------+-----------+             +-----------+------------+
                    |                                     |
                    +------------------+------------------+
                                       |
                           +-----------v------------+
                           | Cascaded Quadrotor AP  |
                           | Altitude, Roll, Pitch  |
                           +-----------+------------+
                                       |
                           +-----------v------------+
                           | 6-DOF Physics Engine   |
                           | (MuJoCo / ArduPilot)   |
                           +------------------------+
```

---

## 2. Mathematical Formulations

### A. Sensory Normalization
The raw distance readings $d_L, d_R \in [d_{min}, d_{max}]$ are normalized to inputs $I_1, I_2 \in [-1, 1]$:
$$I_i(t) = 1.0 - 2.0 \cdot \left(\frac{\text{clip}(d_i, d_{min}, d_{max}) - d_{min}}{d_{max} - d_{min}}\right)$$
* $I_i = -1.0$: Clear path ($d \ge d_{max} = 3.5\text{ m}$).
* $I_i = +1.0$: Imminent collision ($d \le d_{min} = 0.25\text{ m}$).

### B. Two-Neuron Minimal Recurrent Controller (MRC)
Two discrete-time non-spiking neurons with self-excitatory weights $b_1, b_2$ and mutual symmetric inhibitory connection $c$:
$$O_1(t) = \tanh\left(b_1(t) O_1(t-1) + c(t) O_2(t-1) + a_1 I_1(t)\right)$$
$$O_2(t) = \tanh\left(b_2(t) O_2(t-1) + c(t) O_1(t-1) + a_1 I_2(t)\right)$$
* Normalized firing rate: $v_i(t) = \frac{O_i(t) + 1}{2} \in [0, 1]$.
* Mutual inhibition: $c(t) = -\frac{q_1(t) + q_2(t)}{2}$ with $q_{init} = 3.5 \implies c_{init} = -3.5$.

### C. Online Synaptic Plasticity & Homeostatic Scaling
Reflex signal $T_i(t)$ triggers when obstacle distance is within critical threshold ($d < d_{reflex} = 0.85\text{ m}$):
$$T_i(t) = \begin{cases} 1.0, & \text{if } d_i < d_{reflex} \\ 0.0, & \text{otherwise} \end{cases}$$

Synaptic weights adapt online according to:
$$\dot{b}_i(t) = \mu_b \cdot v_i(t) \cdot T_i(t) - \gamma_b \cdot (b_i(t) - b_{init})$$
$$\dot{q}_i(t) = \mu_q \cdot v_i(t) \cdot T_i(t) - \gamma_q \cdot (q_i(t) - q_{init})$$

* **$\mu_b, \mu_q$**: Learning rates driving weight expansion during entrapment.
* **$\gamma_b, \gamma_q$**: Synaptic scaling forgetting rates driving homeostatic decay back to baseline ($b_{init}=2.4, c_{init}=-3.5$) once clear.

### D. Steering and Speed Adaptation
* **Steering (Yaw Rate)**:
  $$\dot{\psi} = -K_{yaw} \cdot (O_1 - O_2)$$
  Obstacle on left ($O_1 > O_2$) triggers clockwise yaw ($\dot{\psi} < 0$, turning right). Obstacle on right ($O_2 > O_1$) triggers counter-clockwise yaw ($\dot{\psi} > 0$, turning left).
* **Speed Adaptation**:
  $$v_x(t) = v_{cruise} \cdot f(\min(d_L, d_R))$$
  Decelerates smoothly starting at $2.6\text{ m}$, brakes to $0.0\text{ m/s}$ at $1.7\text{ m}$, and initiates reverse backing up ($-0.25 v_{cruise}$) if inside $1.2\text{ m}$ to provide ample pivot clearance.

---

## 3. Project Structure

```
adaptive_drone_simulation/
├── models/
│   ├── quadrotor.xml              # F450 quadrotor MJCF model with dual rangefinders
│   ├── world_deadlock.xml         # U-shaped trap / deadlock benchmark
│   ├── world_corner.xml           # Sharp 90-degree corner & narrow passage
│   ├── world_simple_obstacle.xml  # Single obstacle avoidance arena
│   └── world_cluttered_field.xml  # Multi-obstacle exploration arena
├── src/
│   ├── __init__.py
│   ├── neural_controller.py       # 2-neuron MRC + correlation plasticity + scaling
│   ├── quadrotor_sim.py          # 6-DOF MuJoCo simulation & cascaded autopilot
│   └── telemetry_plotter.py       # Publication-grade plotting of trajectories & weights
├── ardupilot_bridge/
│   ├── ardupilot_companion.py     # MAVLink companion computer for Pixhawk/ArduPilot
│   └── README_ARDUPILOT.md        # Step-by-step SITL & Gazebo guide
├── results/                       # Generated telemetry figures and plots
├── run_simulation.py              # Main CLI execution launcher
├── test_simulation.py             # Automated unit & integration test suite
├── requirements.txt               # Dependencies
└── README.md
```

---

## 4. How to Open and Run

### Step 1: Install Dependencies
Open a terminal (PowerShell or Command Prompt) and install dependencies:
```bash
pip install -r requirements.txt
```
*(Note: `mujoco`, `numpy`, `matplotlib` are already installed and verified on your system).*

---

### Step 2: Run the Benchmark Scenarios

#### Scenario 1: U-Shaped Deadlock (Core Paper Experiment)
Watch the drone fly into the concave trap, trigger synaptic plasticity to break deadlock symmetry, execute a clean $180^\circ$ turn, and fly out:
* **Interactive 3D Window (GUI)**:
  ```bash
  python run_simulation.py --scenario deadlock --gui
  ```
  *3D Controls*:
  * Left-Click + Drag: Rotate camera view.
  * Right-Click + Drag: Pan camera.
  * Scroll Wheel: Zoom in / out.
  * Spacebar: Pause / Resume simulation.

* **Headless Fast Simulation & Telemetry Plot**:
  ```bash
  python run_simulation.py --scenario deadlock --duration 20.0
  ```

---

#### Scenario 2: Reproduce the Paper's Non-Adaptive vs. Adaptive Comparison
Directly compare the static controller (trapped in deadlock) against the adaptive controller (escapes trap):
```bash
python run_simulation.py --scenario compare --duration 20.0
```
This automatically produces a side-by-side comparative figure saved to:
`results/deadlock_comparison_paper_result.png`.

---

#### Scenario 3: Sharp Corner & Narrow Passage
Test navigation through an angled corner and narrow corridor:
```bash
python run_simulation.py --scenario corner --gui
```

---

#### Scenario 4: Single Obstacle Avoidance
Test smooth deceleration and evasive maneuvering around an isolated obstacle:
```bash
python run_simulation.py --scenario obstacle --gui
```

---

#### Scenario 5: Cluttered Obstacle Arena
Test exploration through a randomly distributed field of 12 obstacles:
```bash
python run_simulation.py --scenario cluttered --gui --duration 30.0
```

---

### Step 3: Run with Environmental Perturbations (Wind Gusts)
As evaluated in the paper, test robustness against unpredictable wind disturbances:
```bash
python run_simulation.py --scenario deadlock --wind --gui
```

---

### Step 4: Run the Automated Test Suite
To verify controller dynamics, weight adaptation, and flight stability:
```bash
python test_simulation.py
```
Expected output:
```
Ran 6 tests in 0.37s
OK
```

---

## 5. Running with ArduPilot & Gazebo

If you want to run the controller as an external companion computer interfacing with **ArduPilot SITL** or **Gazebo**:

1. Start ArduPilot SITL:
   ```bash
   sim_vehicle.py -v ArduCopter --console
   ```
2. Start the companion computer script:
   ```bash
   python ardupilot_bridge/ardupilot_companion.py --connect udpin:0.0.0.0:14550 --speed 1.0 --plasticity on
   ```
See [ardupilot_bridge/README_ARDUPILOT.md](file:///C:/Users/ASUS/.gemini/antigravity/scratch/adaptive_drone_simulation/ardupilot_bridge/README_ARDUPILOT.md) for full Gazebo instructions.

---

## 6. Citation

```bibtex
@inproceedings{devos2018development,
  title={Development of Autonomous Drones for Adaptive Obstacle Avoidance in Real World Environments},
  author={Devos, Arne and Ebeid, Emad Samuel Malki and Manoonpong, Poramate},
  booktitle={2018 21st Euromicro Conference on Digital System Design (DSD)},
  pages={645--652},
  year={2018},
  organization={IEEE},
  doi={10.1109/DSD.2018.00112}
}
```
