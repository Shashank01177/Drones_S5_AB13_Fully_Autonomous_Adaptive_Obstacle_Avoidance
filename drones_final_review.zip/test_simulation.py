"""
Automated Test Suite for Adaptive Drone Obstacle Avoidance Simulation.
Verifies neural dynamics, plasticity updates, simulation models, and flight stability.
"""

import os
import sys
import unittest
import numpy as np

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
sys.path.insert(0, PROJECT_ROOT)

from src.neural_controller import AdaptiveNeuralController
from src.quadrotor_sim import QuadrotorSimulation


class TestAdaptiveController(unittest.TestCase):
    """Test suite for neural controller equations and dynamics."""

    def setUp(self):
        self.controller = AdaptiveNeuralController(v_cruise=1.0, dt=0.02)

    def test_sensor_normalization(self):
        """Test normalization from distance range [d_min, d_max] to [-1, 1]."""
        # Far distance -> -1.0
        self.assertAlmostEqual(self.controller.normalize_sensor(3.5), -1.0, places=2)
        self.assertAlmostEqual(self.controller.normalize_sensor(5.0), -1.0, places=2)
        
        # Close distance -> +1.0
        self.assertAlmostEqual(self.controller.normalize_sensor(0.25), 1.0, places=2)
        self.assertAlmostEqual(self.controller.normalize_sensor(0.10), 1.0, places=2)
        
        # Mid distance
        mid = (3.5 + 0.25) / 2.0
        self.assertAlmostEqual(self.controller.normalize_sensor(mid), 0.0, places=2)

    def test_reflex_trigger(self):
        """Test reflex signal trigger when distance < d_reflex."""
        # Safe distance
        info_safe = self.controller.step(2.5, 2.5)
        self.assertEqual(info_safe["T1"], 0.0)
        self.assertEqual(info_safe["T2"], 0.0)

        # Dangerous distance on left
        info_danger = self.controller.step(0.5, 2.5)
        self.assertEqual(info_danger["T1"], 1.0)
        self.assertEqual(info_danger["T2"], 0.0)

    def test_plasticity_adaptation_and_recovery(self):
        """Verify synaptic plasticity increases weights on reflex and recovers via scaling."""
        b1_init = self.controller.b1
        
        # Simulate obstacle on left for 30 steps
        for _ in range(30):
            self.controller.step(0.4, 2.5)
            
        b1_adapted = self.controller.b1
        self.assertGreater(b1_adapted, b1_init, "Synaptic weight b1 should increase under reflex")

        # Simulate clear space: synaptic scaling should decay b1 back toward b_init
        for _ in range(500):
            self.controller.step(3.5, 3.5)
            
        b1_recovered = self.controller.b1
        self.assertLess(b1_recovered, b1_adapted, "Synaptic scaling should decay weight back toward baseline")

    def test_speed_adaptation(self):
        """Verify speed reduces as obstacle approaches and stops/reverses when too close."""
        # Far -> full cruise speed
        info1 = self.controller.step(3.5, 3.5)
        self.assertAlmostEqual(info1["cmd_vx"], 1.0, places=1)

        # Approaching -> decelerates
        for _ in range(10):
            info2 = self.controller.step(1.0, 1.0)
        self.assertLess(info2["cmd_vx"], 1.0, "Speed should adapt downwards as obstacle nears")


class TestSimulationPhysics(unittest.TestCase):
    """Test suite for MuJoCo quadrotor physics and autopilot."""

    def test_models_exist_and_load(self):
        """Verify all MJCF XML model files are valid and compile in MuJoCo."""
        scenarios = ["world_park_environment.xml", "quadrotor.xml"]
        for xml_file in scenarios:
            path = os.path.join(PROJECT_ROOT, "models", xml_file)
            self.assertTrue(os.path.exists(path), f"File {xml_file} must exist")
        sim = QuadrotorSimulation(world_xml_path=os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml"))
        self.assertGreater(sim.mass, 0.5)

    def test_flight_stability_hover(self):
        """Verify drone hovers stably at target altitude without crashing."""
        path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
        sim = QuadrotorSimulation(world_xml_path=path, target_altitude=1.5, cruise_speed=0.0)
        sim.reset(start_pos=(0.0, 0.0, 1.5))
        
        # Step for 2 seconds
        telemetry = sim.run_headless(duration_sec=2.0)
        self.assertGreater(len(telemetry), 50)
        
        final_z = telemetry[-1]["pos_z"]
        self.assertAlmostEqual(final_z, 1.5, delta=0.25, msg="Drone altitude should be maintained around 1.5m")

    def test_park_arena_single_stick_boundary_and_hold(self):
        """
        Verify the IEEE 8491889 bounded park arena with single thin stick obstacle:
        1. Drone evades single stick obstacle on path.
        2. Drone stays strictly within rectangular boundary (X: [-1.5, 13.5], Y: [-2.5, 2.5]).
        3. Drone reaches destination helipad and completes 10-second hold.
        """
        path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
        self.assertTrue(os.path.exists(path), "world_park_environment.xml must exist")

        ctrl = AdaptiveNeuralController(v_cruise=1.0, enable_plasticity=True)
        sim = QuadrotorSimulation(
            world_xml_path=path,
            neural_controller=ctrl,
            target_goal=(12.0, 0.0, 1.5),
            continuous_mode=False,
        )
        sim.reset(start_pos=(0.0, 0.0, 1.5), target_goal=(12.0, 0.0, 1.5), stick_pos=(5.0, 0.0))

        # Run headless through mission completion and 10s hold
        telemetry = sim.run_headless(duration_sec=36.0)
        self.assertGreater(len(telemetry), 200)

        # 1. Boundary confinement check
        xs = [r["pos_x"] for r in telemetry]
        ys = [r["pos_y"] for r in telemetry]
        self.assertGreaterEqual(min(xs), -1.5, "Drone must not cross West boundary (-1.5m)")
        self.assertLessEqual(max(xs), 13.5, "Drone must not cross East boundary (13.5m)")
        self.assertGreaterEqual(min(ys), -2.5, "Drone must not cross South boundary (-2.5m)")
        self.assertLessEqual(max(ys), 2.5, "Drone must not cross North boundary (+2.5m)")

        # 2. Stick obstacle avoidance check (must clear stick at x=5.0m without collision)
        final = telemetry[-1]
        self.assertTrue(final["goal_reached"], "Drone should reach goal helipad")
        self.assertTrue(final["mission_complete"], "Drone should land at destination")
        self.assertTrue(final["hold_complete"], "Drone should complete 10s destination hold")
        self.assertGreaterEqual(final["hold_timer"], 10.0, "Hold timer should reach 10 seconds")

    def test_multi_stick_placement_and_custom_speed(self):
        """
        Verify placing multiple stick obstacles as user wishes and starting speed (0.01 to 10 m/s):
        1. User places multiple sticks (e.g. 3 sticks at various coordinates).
        2. Speed input parses correctly (0.01, 0.1, 0.01m/s, 10m/s).
        3. Drone operates stably at configured speeds with strictly 2 LiDAR sensors.
        """
        path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
        ctrl = AdaptiveNeuralController(v_cruise=0.1, enable_plasticity=True)
        sim = QuadrotorSimulation(
            world_xml_path=path,
            neural_controller=ctrl,
            cruise_speed=0.1,
            continuous_mode=False,
            target_goal=(12.0, 0.0, 1.5),
        )
        
        # User places multiple sticks as wish: 3 stick obstacles
        custom_sticks = [(3.0, 0.2), (6.0, -0.2), (9.0, 0.1)]
        sim.reset(
            start_pos=(0.0, 0.0, 1.5),
            target_goal=(12.0, 0.0, 1.5),
            obstacles=custom_sticks,
        )
        self.assertEqual(len(sim.active_obstacles), 3, "Should have 3 placed stick obstacles")

        # Test fine speed 0.1 m/s tracking
        telemetry = sim.run_headless(duration_sec=1.0)
        self.assertGreater(len(telemetry), 20)
        final = telemetry[-1]
        self.assertAlmostEqual(final["pos_z"], 1.5, delta=0.15)
        self.assertAlmostEqual(final["cmd_vx"], 0.1, delta=0.05)

        # Test ultra-fine speed 0.01 m/s
        sim.cruise_speed = 0.01
        sim.controller.v_cruise = 0.01
        telemetry_fine = sim.run_headless(duration_sec=0.5)
        self.assertAlmostEqual(telemetry_fine[-1]["cmd_vx"], 0.01, delta=0.005)

        # Verify exactly 2 LiDAR sensors are read
        sensors = sim.get_sensors()
        self.assertEqual(len(sensors), 2, "Must have strictly 2 LiDAR sensors")

    def test_ground_start_and_ground_landing(self):
        """
        Verify complete flight cycle starting from ground and ending at ground only:
        1. Drone starts resting on ground at White Helipad (z = 0.072m).
        2. Climbs vertically to cruise altitude (z = 1.5m) with cmd_vx = 0.
        3. Navigates forward, evading stick obstacle.
        4. Descends vertically to ground at Light Red Helipad (z <= 0.075m).
        5. Motors shut off (ctrl[:] = 0.0) upon touchdown.
        """
        path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
        ctrl = AdaptiveNeuralController(v_cruise=1.0, enable_plasticity=True)
        sim = QuadrotorSimulation(
            world_xml_path=path,
            neural_controller=ctrl,
            cruise_speed=1.0,
            continuous_mode=False,
            target_goal=(8.0, 0.0, 1.5),
        )
        # Ground start at (0.0, 0.0, 0.072)
        sim.reset(
            start_pos=(0.0, 0.0, 0.072),
            target_goal=(8.0, 0.0, 1.5),
            obstacles=[(4.0, 0.0)],
        )
        self.assertEqual(sim.flight_phase, "TAKEOFF")
        self.assertAlmostEqual(sim.data.qpos[2], 0.072, delta=0.005)

        # Run flight to completion
        telemetry = sim.run_headless(duration_sec=32.0)
        self.assertGreater(len(telemetry), 200)

        # Verify initial takeoff phase: cmd_vx = 0
        initial_records = telemetry[:15]
        for r in initial_records:
            if r["flight_phase"] == "TAKEOFF":
                self.assertAlmostEqual(r["cmd_vx"], 0.0, delta=0.01, msg="cmd_vx must be 0 during vertical takeoff")

        # Verify it reached cruise altitude
        max_z = max(r["pos_z"] for r in telemetry)
        self.assertAlmostEqual(max_z, 1.5, delta=0.25, msg="Drone must climb to cruise altitude")

        # Verify landing at ground
        final = telemetry[-1]
        self.assertTrue(final["goal_reached"], "Drone must reach destination")
        self.assertTrue(final["mission_complete"], "Drone mission must be complete")
        self.assertEqual(final["flight_phase"], "LANDED")
        self.assertLessEqual(final["pos_z"], 0.080, "Drone must end on ground (pos_z <= 0.080m)")
        # Motors must be shut off
        self.assertAlmostEqual(float(np.sum(sim.data.ctrl)), 0.0, places=4, msg="Motors must shut off on touchdown")

    def test_planner_announce_task_finished(self):
        """Verify that after the drone has landed, Task finished is triggered and announced."""
        from src.park_mission_planner import ParkMissionPlanner
        import tkinter as tk
        root = tk.Tk()
        root.withdraw()
        planner = ParkMissionPlanner(root=root)
        self.assertFalse(planner.has_spoken_finished)
        planner.announce_task_finished()
        root.update()
        self.assertTrue(planner.has_spoken_finished)
        self.assertIn("Task finished", planner.hud_status.cget("text"))
        self.assertIn("TASK FINISHED", planner.banner_lbl.cget("text"))
        root.destroy()

    def test_whole_packed_obstacle_aperture_passability(self):
        """
        Verify Aperture Sizing & Passability (IEEE 8491889 Section IV.B):
        1. When obstacles are whole packed ahead (no gap >= drone size 0.68m),
           the drone calculates the blockage, brakes to 0 m/s, and hovers safely in standoff.
        2. When a passable gap >= drone size exists, the drone moves forward and passes.
        """
        path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
        ctrl = AdaptiveNeuralController(v_cruise=0.8, enable_plasticity=True)
        sim = QuadrotorSimulation(
            world_xml_path=path,
            neural_controller=ctrl,
            cruise_speed=0.8,
            continuous_mode=False,
            target_goal=(10.0, 0.0, 1.5),
        )

        # 1. Whole Packed Barrier at X = 5.0m across arena Y in [-2.5, 2.5]
        # Placing sticks every 0.55m leaves gaps of ~0.47m (drone size is 0.68m)
        packed_sticks = [(5.0, float(y)) for y in np.arange(-2.2, 2.3, 0.55)]
        sim.reset(
            start_pos=(0.0, 0.0, 1.5),
            target_goal=(10.0, 0.0, 1.5),
            obstacles=packed_sticks,
        )
        self.assertGreaterEqual(len(sim.active_obstacles), 8)

        # Run towards the packed barrier
        telemetry = sim.run_headless(duration_sec=8.0)
        final_record = telemetry[-1]

        # Drone must detect blockage and halt forward flight
        self.assertTrue(final_record["path_blocked"], "Drone must detect whole packed corridor")
        self.assertLess(final_record["gap_width"], sim.min_passable_width, "Detected gap must be smaller than drone size")
        self.assertAlmostEqual(final_record["cmd_vx"], 0.0, places=2, msg="Forward velocity must brake to 0 m/s when path is blocked")
        # Drone must NOT crash through the barrier (stay in front of X=5.0m)
        self.assertLess(final_record["pos_x"], 4.5, "Drone must hold safe standoff in front of packed obstacle")

    def test_multiple_ending_points_with_ground_touchdowns(self):
        """
        Verify Multiple Ending Points with Sequential Ground Touchdowns:
        1. 1 Starting Point on ground (0.0, 0.0, 0.072m).
        2. User places multiple ending points: [(3.0, 0.8), (6.5, -0.8), (10.0, 0.0)].
        3. Drone climbs from ground, flies to End #1, descends and touches down on ground.
        4. Drone takes off from ground, flies to End #2, descends and touches down on ground.
        5. Drone takes off from ground, flies to Final End #3, touches down on ground,
           shuts off motors (ctrl[:] = 0.0), and marks mission complete.
        """
        path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
        ctrl = AdaptiveNeuralController(v_cruise=1.0, enable_plasticity=True)
        end_points = [(3.0, 0.8), (6.0, -0.8), (10.0, 0.0)]
        sim = QuadrotorSimulation(
            world_xml_path=path,
            neural_controller=ctrl,
            cruise_speed=1.0,
            continuous_mode=False,
            waypoints=end_points,
            target_goal=(end_points[-1][0], end_points[-1][1], 1.5),
        )
        sim.reset(
            start_pos=(0.0, 0.0, 0.072),
            target_goal=(end_points[-1][0], end_points[-1][1], 1.5),
            waypoints=end_points,
            obstacles=[(4.5, 0.0)],
        )

        self.assertEqual(len(sim.waypoints), 3)
        self.assertEqual(sim.current_waypoint_idx, 0)
        self.assertEqual(sim.flight_phase, "TAKEOFF")

        # Step simulation to completion (completes in ~33s)
        telemetry = sim.run_headless(duration_sec=36.0)
        self.assertGreater(len(telemetry), 300)

        # Track which waypoints experienced a ground touchdown (z <= 0.080m)
        touchdown_wps = set()
        for r in telemetry:
            if r["pos_z"] <= 0.080:
                touchdown_wps.add(r["waypoint_idx"])

        # Drone must have touched down at every ending point (wp 0, wp 1, and wp 2)
        self.assertIn(0, touchdown_wps, "Must touch down on ground at Ending Point #1")
        self.assertIn(1, touchdown_wps, "Must touch down on ground at Ending Point #2")
        self.assertIn(2, touchdown_wps, "Must touch down on ground at Final Ending Point #3")

        final = telemetry[-1]
        self.assertTrue(final["mission_complete"], "Mission must be complete at final destination")
        self.assertTrue(final["goal_reached"], "Goal must be reached")
        self.assertEqual(final["flight_phase"], "LANDED")
        self.assertLessEqual(final["pos_z"], 0.080, "Final state must be on the ground")
        self.assertAlmostEqual(float(np.sum(sim.data.ctrl)), 0.0, places=4, msg="Motors must be cut off on final landing")

    def test_wing_clearance_and_zero_obstacle_collision(self):
        """
        Verify Wing/Rotor Blade Obstacle Clearance and Physical Collision:
        1. All 4 arms and 4 rotor blade discs have active collision geoms enabled in MuJoCo.
        2. During flight past stick obstacle at (5.0, 0.0), wing tip distance stays strictly positive (>= 0.25m margin).
        3. Zero physical contact events occur between any drone geom and any obstacle geom.
        4. Mission completes successfully to destination.
        """
        path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
        ctrl = AdaptiveNeuralController(v_cruise=1.0, enable_plasticity=True)
        sim = QuadrotorSimulation(
            world_xml_path=path,
            neural_controller=ctrl,
            cruise_speed=1.0,
            continuous_mode=False,
            target_goal=(12.0, 0.0, 1.5),
        )
        sim.reset(start_pos=(0.0, 0.0, 1.5), target_goal=(12.0, 0.0, 1.5), stick_pos=(5.0, 0.0))

        # Verify active collision geoms exist for wings and rotor blade discs in MuJoCo model
        blade_geom_names = ["prop_col_fr", "prop_col_fl", "prop_col_rr", "prop_col_rl"]
        arm_geom_names = ["arm_fr", "arm_fl", "arm_rr", "arm_rl"]
        for gname in blade_geom_names + arm_geom_names:
            gid = sim.model.geom(gname).id
            self.assertGreaterEqual(gid, 0, f"Geom {gname} must exist in model")
            self.assertEqual(sim.model.geom_contype[gid], 1, f"Geom {gname} contype must be 1 (active collision)")
            self.assertEqual(sim.model.geom_conaffinity[gid], 1, f"Geom {gname} conaffinity must be 1 (active collision)")

        # Track wing clearance and MuJoCo contact events throughout entire flight
        obs_x, obs_y = 5.0, 0.0
        obs_r = 0.04
        blade_r = 0.115
        rotor_offsets = [
            (0.16, -0.16),
            (0.16, 0.16),
            (-0.16, -0.16),
            (-0.16, 0.16)
        ]

        min_wing_clearance = 999.0
        min_center_dist = 999.0
        obstacle_contact_count = 0

        for _ in range(1200):
            sim.step_control()
            state = sim.get_state()
            pos = state["pos"]
            yaw = state["yaw"]

            c_dist = float(np.hypot(pos[0] - obs_x, pos[1] - obs_y))
            if c_dist < min_center_dist:
                min_center_dist = c_dist

            cy, sy = float(np.cos(yaw)), float(np.sin(yaw))
            for bx, by in rotor_offsets:
                wx = pos[0] + (bx * cy - by * sy)
                wy = pos[1] + (bx * sy + by * cy)
                r_dist = float(np.hypot(wx - obs_x, wy - obs_y))
                margin = (r_dist - obs_r) - blade_r
                if margin < min_wing_clearance:
                    min_wing_clearance = margin

            # Check for any physical collision between drone and stick in MuJoCo physics
            for ci in range(sim.data.ncon):
                contact = sim.data.contact[ci]
                n1 = sim.model.geom(contact.geom1).name
                n2 = sim.model.geom(contact.geom2).name
                if "stick" in n1 or "stick" in n2:
                    obstacle_contact_count += 1

            if sim.goal_reached and sim.hold_complete:
                break

        # Verification asserts:
        self.assertEqual(obstacle_contact_count, 0, "Drone wings/body must never make physical contact with stick obstacle")
        self.assertGreater(min_wing_clearance, 0.25, f"Wing clearance must maintain >= 0.25m safe margin, got {min_wing_clearance:.3f}m")
        self.assertGreater(min_center_dist, 0.65, f"Center distance must maintain >= 0.65m safe clearance, got {min_center_dist:.3f}m")
        self.assertTrue(sim.goal_reached, "Drone must complete mission successfully")


if __name__ == "__main__":
    unittest.main()
