@echo off
title Running Automated Test Suite
cd /d "%~dp0"
echo =====================================================================
echo  RUNNING AUTOMATED UNIT TEST SUITE (13 VERIFICATION TESTS)
echo =====================================================================
echo.
python test_simulation.py
echo.
pause
