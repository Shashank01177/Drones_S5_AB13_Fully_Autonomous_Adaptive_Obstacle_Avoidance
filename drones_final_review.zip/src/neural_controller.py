"""
Adaptive Neural Controller for Autonomous Drone Obstacle Avoidance
Based on IEEE 8491889 (Devos, Ebeid, Manoonpong 2018) and foundational papers
(Pedersen & Manoonpong 2018; Grinke et al. 2015; Jaiton et al. 2022).

Architecture:
- 2-neuron Minimal Recurrent Controller (MRC) with even inhibitory loop
- Online correlation-based learning rule for synaptic plasticity
- Synaptic scaling for homeostatic stabilization
- Dynamic turning angle modulation (hysteresis expansion)
- Speed adaptation with proximity-based braking and emergency back-up
"""

import numpy as np


class AdaptiveNeuralController:
    """
    Two-neuron recurrent neural controller with synaptic plasticity
    and homeostatic scaling for adaptive drone navigation.
    """

    def __init__(
        self,
        # Sensor normalization parameters
        d_min: float = 0.25,      # meters (maximum proximity danger)
        d_max: float = 3.5,       # meters (detection horizon)
        d_reflex: float = 0.85,    # meters (reflexive trigger threshold)
        
        # Neural network architectural parameters
        a1: float = 4.7,          # Input synaptic weight
        b_init: float = 2.4,      # Initial self-excitatory weight
        q_init: float = 3.5,      # Initial mutual inhibitory weight (c = -q)
        
        # Plasticity & scaling parameters
        enable_plasticity: bool = True,
        mu_b: float = 0.08,       # Learning rate for self-excitation
        mu_q: float = 0.12,       # Learning rate for mutual inhibition
        gamma_b: float = 0.005,   # Synaptic scaling (forgetting) rate for b
        gamma_q: float = 0.005,   # Synaptic scaling (forgetting) rate for q
        
        # Velocity and steering mapping
        v_cruise: float = 0.5,    # Default forward cruise speed (m/s) (range 0.001 - 1.0 m/s)
        k_yaw: float = 0.40,      # Slow, smooth steering yaw-rate gain (gentle graceful turning)
        dt: float = 0.02,         # Control update step (50 Hz)
    ):
        self.d_min = d_min
        self.d_max = d_max
        self.d_reflex = d_reflex
        
        self.a1 = a1
        self.b_init = b_init
        self.q_init = q_init
        
        self.enable_plasticity = enable_plasticity
        self.mu_b = mu_b
        self.mu_q = mu_q
        self.gamma_b = gamma_b
        self.gamma_q = gamma_q
        
        self.v_cruise = v_cruise
        self.k_yaw = k_yaw
        self.dt = dt
        
        self.reset()

    def reset(self):
        """Reset neural states, weights, and histories to initial values."""
        # Neuronal activation outputs O_i in [-1, 1]
        # Initialized to -1 (no obstacle state)
        self.O1 = -1.0
        self.O2 = -1.0
        
        # Normalized firing rates v_i in [0, 1]
        self.v1 = (self.O1 + 1.0) / 2.0
        self.v2 = (self.O2 + 1.0) / 2.0
        self.v1_prev = self.v1
        self.v2_prev = self.v2
        
        # Synaptic weights
        self.b1 = self.b_init
        self.b2 = self.b_init
        self.q1 = self.q_init
        self.q2 = self.q_init
        self.c = -self.q_init  # Symmetric mutual inhibition
        
        # Reflex signals
        self.T1 = 0.0
        self.T2 = 0.0
        
        # Raw sensory inputs I_i in [-1, 1]
        self.I1 = -1.0
        self.I2 = -1.0
        
        # Commands
        self.cmd_vx = self.v_cruise
        self.cmd_yaw_rate = 0.0
        
        # Evasion persistence memory for goal navigation
        self.evasion_timer = 0.0
        self.evasion_side = 0.0
        
        # Statistics for diagnostics
        self.time = 0.0
        self.total_plasticity_updates = 0

    def normalize_sensor(self, d: float) -> float:
        """
        Maps a distance reading d (meters) to neural input I in [-1, 1].
        -1.0 means no obstacle (d >= d_max).
        +1.0 means obstacle in collision distance (d <= d_min).
        """
        if np.isnan(d) or d >= self.d_max or d < 0:
            return -1.0
        d_clamped = np.clip(d, self.d_min, self.d_max)
        # Linear inverse mapping: d_max -> -1.0, d_min -> +1.0
        return float(1.0 - 2.0 * ((d_clamped - self.d_min) / (self.d_max - self.d_min)))

    def step(
        self,
        dist_left: float,
        dist_right: float,
        goal_heading_err: float = None,
        dist_to_goal: float = None,
    ) -> dict:
        """
        Executes one discrete update of the adaptive neural controller.
        
        Args:
            dist_left: Distance reading from left-facing rangefinder (meters)
            dist_right: Distance reading from right-facing rangefinder (meters)
            goal_heading_err: Optional heading angle error to goal (radians, [-pi, pi])
            dist_to_goal: Optional Euclidean distance to destination goal (meters)
            
        Returns:
            dict containing commanded forward velocity, yaw rate, and telemetry state.
        """
        # 1. Normalize sensory inputs
        self.I1 = self.normalize_sensor(dist_left)
        self.I2 = self.normalize_sensor(dist_right)
        
        # 2. Evaluate reflex signals T_i
        # Triggers when obstacle is dangerously close (d < d_reflex or I > -0.5)
        self.T1 = 1.0 if (dist_left < self.d_reflex and dist_left > 0) else 0.0
        self.T2 = 1.0 if (dist_right < self.d_reflex and dist_right > 0) else 0.0
        
        # 3. Update discrete-time recurrent neuron outputs O_i(t)
        # Using previous outputs O_1(t-1), O_2(t-1)
        O1_prev = self.O1
        O2_prev = self.O2
        
        # Mutual inhibition is symmetric: c12 = c21 = c = -(q1 + q2)/2
        self.c = -0.5 * (self.q1 + self.q2)
        
        # Equations:
        # a_1(t) = b1 * O1_prev + c * O2_prev + a1 * I1
        # a_2(t) = b2 * O2_prev + c * O1_prev + a1 * I2
        act1 = self.b1 * O1_prev + self.c * O2_prev + self.a1 * self.I1
        act2 = self.b2 * O2_prev + self.c * O1_prev + self.a1 * self.I2
        
        self.O1 = float(np.tanh(act1))
        self.O2 = float(np.tanh(act2))
        
        # 4. Compute positive normalized firing rates v_i in [0, 1]
        self.v1_prev = self.v1
        self.v2_prev = self.v2
        self.v1 = float((self.O1 + 1.0) / 2.0)
        self.v2 = float((self.O2 + 1.0) / 2.0)
        
        # 5. Online Correlation-Based Synaptic Plasticity & Homeostatic Scaling
        # Formulated according to Devos et al. (2018) & Grinke et al. (2015):
        # dot{b}_i = mu_b * v_i * T_i - gamma_b * (b_i - b_init)
        # dot{q}_i = mu_q * v_i * T_i - gamma_q * (q_i - q_init)
        if self.enable_plasticity:
            # When both sensors are triggered in a symmetric deadlock,
            # natural microscopic asymmetry triggers winner-take-all competition
            noise_asym = 0.0
            if self.T1 > 0 and self.T2 > 0:
                noise_asym = 0.05

            dot_b1 = self.mu_b * (self.v1 + noise_asym) * self.T1 - self.gamma_b * (self.b1 - self.b_init)
            dot_b2 = self.mu_b * self.v2 * self.T2 - self.gamma_b * (self.b2 - self.b_init)
            
            dot_q1 = self.mu_q * (self.v1 + noise_asym) * self.T1 - self.gamma_q * (self.q1 - self.q_init)
            dot_q2 = self.mu_q * self.v2 * self.T2 - self.gamma_q * (self.q2 - self.q_init)
            
            # Integrate weight changes
            self.b1 = float(np.clip(self.b1 + dot_b1, self.b_init * 0.8, 6.5))
            self.b2 = float(np.clip(self.b2 + dot_b2, self.b_init * 0.8, 6.5))
            self.q1 = float(np.clip(self.q1 + dot_q1, self.q_init * 0.8, 8.0))
            self.q2 = float(np.clip(self.q2 + dot_q2, self.q_init * 0.8, 8.0))
            
            if self.T1 > 0 or self.T2 > 0:
                self.total_plasticity_updates += 1
        else:
            # Constant non-plastic baseline (b = 2.4, c = -3.5)
            self.b1 = self.b_init
            self.b2 = self.b_init
            self.q1 = self.q_init
            self.q2 = self.q_init
            self.c = -self.q_init
            
        # 6. Motor Output Mapping
        # (A) Steering command (yaw rate): Slow, smooth turning requested by user
        avoid_yaw_rate = float(np.clip(-self.k_yaw * (self.O1 - self.O2), -0.35, 0.35))
        
        min_dist = min(dist_left, dist_right)
        max_v = max(self.v1, self.v2)

        # Detect active obstacle avoidance need and maintain evasion memory
        if min_dist < 2.5 or max_v > 0.15:
            self.evasion_timer = 0.9  # Maintain evasion heading bias for 0.9s
            if dist_left < dist_right - 0.05:
                self.evasion_side = -1.0  # Obstacle on left -> detour right
            elif dist_right < dist_left - 0.05:
                self.evasion_side = 1.0   # Obstacle on right -> detour left
            elif self.evasion_side == 0.0:
                self.evasion_side = -1.0  # Default initial evasion side
        elif self.evasion_timer > 0.0:
            self.evasion_timer = max(0.0, self.evasion_timer - self.dt)
            if self.evasion_timer == 0.0:
                self.evasion_side = 0.0

        if goal_heading_err is not None:
            # Slow, graceful, smooth turning towards the target (capped at 0.35 rad/s ~ 20 deg/s)
            self.cmd_yaw_rate = float(np.clip(0.75 * goal_heading_err, -0.35, 0.35))
        else:
            self.cmd_yaw_rate = float(np.clip(avoid_yaw_rate, -0.35, 0.35))
        
        # (B) Forward Speed Adaptation:
        # Handles all cruise speeds smoothly (0.001 m/s up to 1.0 m/s and beyond)
        if dist_to_goal is not None and dist_to_goal < 0.38:
            # Reached goal helipad: stop forward motion and hover for touchdown
            self.cmd_vx = 0.0
            self.cmd_yaw_rate = 0.0
        else:
            # 1. Goal approach deceleration profile
            if dist_to_goal is not None:
                v_goal = max(0.15, 0.85 * dist_to_goal)
            else:
                v_goal = self.v_cruise

            # Slow down during significant turns so the graceful turning rate maintains tight path radius
            if goal_heading_err is not None and abs(goal_heading_err) > 0.30:
                turn_factor = max(0.25, 1.0 - 0.75 * (abs(goal_heading_err) / np.pi))
                v_goal = min(v_goal, self.v_cruise * turn_factor)

            # 2. Obstacle evasion deceleration only applies at higher cruise speeds (> 0.35 m/s)
            # For low speeds (0.001 - 0.35 m/s), flight is already slow and controlled
            if self.v_cruise > 0.35:
                if min_dist < 1.3:
                    v_obs = max(0.25, 0.60 * self.v_cruise)
                elif min_dist < 2.5:
                    v_obs = max(0.35, 0.80 * self.v_cruise)
                else:
                    v_obs = self.v_cruise
            else:
                v_obs = self.v_cruise

            self.cmd_vx = float(min(self.v_cruise, v_goal, v_obs))

        self.time += self.dt
        
        return {
            "time": self.time,
            "dist_left": dist_left,
            "dist_right": dist_right,
            "I1": self.I1,
            "I2": self.I2,
            "O1": self.O1,
            "O2": self.O2,
            "v1": self.v1,
            "v2": self.v2,
            "T1": self.T1,
            "T2": self.T2,
            "b1": self.b1,
            "b2": self.b2,
            "q1": self.q1,
            "q2": self.q2,
            "c": self.c,
            "cmd_vx": self.cmd_vx,
            "cmd_yaw_rate": self.cmd_yaw_rate,
        }
