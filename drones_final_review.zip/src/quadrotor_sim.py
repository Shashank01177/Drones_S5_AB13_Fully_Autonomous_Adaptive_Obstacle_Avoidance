"""
Quadrotor 6-DOF Simulation Engine in MuJoCo with Autopilot and Adaptive Neural Control.
Based on IEEE 8491889 (Devos, Ebeid, Manoonpong 2018).
"""

import os
import time
import numpy as np
import mujoco
from .neural_controller import AdaptiveNeuralController


class QuadrotorSimulation:
    """
    MuJoCo-based Quadrotor physics simulation and autopilot.
    Integrates low-level flight stabilization (Cascaded PID for altitude, attitude, and velocity)
    with high-level Adaptive Neural Controller for obstacle avoidance.
    """

    def __init__(
        self,
        world_xml_path: str,
        neural_controller: AdaptiveNeuralController = None,
        target_altitude: float = 1.5,
        cruise_speed: float = 1.0,
        control_freq: float = 50.0,   # Hz (20ms control cycle)
        enable_wind: bool = False,
        target_goal: tuple = None,
        waypoints: list = None,
        continuous_mode: bool = True,
        goal_radius: float = 0.55,
    ):
        if not os.path.exists(world_xml_path):
            raise FileNotFoundError(f"Model XML file not found at: {world_xml_path}")

        self.world_xml_path = world_xml_path
        self.model = mujoco.MjModel.from_xml_path(world_xml_path)
        self.data = mujoco.MjData(self.model)

        self.ctrl_freq = control_freq
        self.ctrl_dt = 1.0 / control_freq
        self.sim_dt = self.model.opt.timestep  # e.g., 0.002s or 0.005s
        self.sim_steps_per_ctrl = max(1, int(round(self.ctrl_dt / self.sim_dt)))

        self.ground_altitude = 0.072
        self.cruise_altitude = target_altitude if target_altitude is not None else 1.5
        self.target_altitude = self.ground_altitude
        self.initial_target_altitude = self.ground_altitude
        self.cruise_speed = cruise_speed
        self.enable_wind = enable_wind
        self.target_goal = target_goal
        self.goal_radius = goal_radius
        self.continuous_mode = continuous_mode
        self.waypoints = [tuple(w[:2]) for w in waypoints] if waypoints else ([(target_goal[0], target_goal[1])] if target_goal else [])
        self.current_waypoint_idx = 0
        self.patrol_direction = 1  # +1 = forward through waypoints, -1 = reverse back to start
        self.start_pos = (0.5, 0.0, self.ground_altitude)
        self.start_coord = (0.5, 0.0)
        self.flight_phase = "TAKEOFF"
        self.goal_reached = False
        self.mission_complete = False
        self.touchdown_timer = 0.0

        # Instantiate or assign neural controller
        if neural_controller is None:
            self.controller = AdaptiveNeuralController(v_cruise=cruise_speed, dt=self.ctrl_dt)
        else:
            self.controller = neural_controller
            self.controller.dt = self.ctrl_dt

        # Drone physical parameters
        drone_body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, "drone")
        self.mass = float(self.model.body_subtreemass[drone_body_id])
        self.g = abs(self.model.opt.gravity[2])
        self.hover_thrust_total = self.mass * self.g
        self.hover_thrust_per_motor = self.hover_thrust_total / 4.0
        self.arm_length = 0.16  # meters

        # Cascaded Autopilot Gains (Tuned for critical damping and tight tracking)
        # 1. Altitude PID
        self.kp_z = 28.0
        self.kd_z = 12.0
        self.ki_z = 2.0
        self.integral_z_err = 0.0

        # 2. Velocity-to-Attitude Gains (Limit max tilt to 10 degrees = 0.17 rad)
        self.kp_vx = 0.18
        self.kd_vx = 0.12
        self.kp_vy = 0.18
        self.kd_vy = 0.12

        # 3. Attitude PD (Stiff and critically damped)
        self.kp_att = 1.80
        self.kd_att = 0.28
        self.kp_yaw = 0.80
        self.kd_yaw = 0.25

        # Slender Stick Obstacles Pool (Users can place multiple sticks as their wish!)
        self.stick_mocap_ids = []
        for i in range(15):
            bid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, f"stick_obs_{i}")
            if bid >= 0 and self.model.body_mocapid[bid] >= 0:
                self.stick_mocap_ids.append(int(self.model.body_mocapid[bid]))
        if not self.stick_mocap_ids:
            bid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, "stick_obs")
            if bid >= 0 and self.model.body_mocapid[bid] >= 0:
                self.stick_mocap_ids.append(int(self.model.body_mocapid[bid]))
        self.stick_mocap_id = self.stick_mocap_ids[0] if self.stick_mocap_ids else -1
        self.stick_pos = (5.0, 0.0)
        self.next_stick_idx = 0

        # Ending Helipads Mocap Pool (Users can place multiple ending points as their wish!)
        self.end_pad_mocap_ids = []
        for i in range(10):
            bid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, f"end_pad_{i}")
            if bid >= 0 and self.model.body_mocapid[bid] >= 0:
                self.end_pad_mocap_ids.append(int(self.model.body_mocapid[bid]))

        # Rectangular Flight Arena Boundaries: X in [-1.5, 13.5], Y in [-2.5, 2.5]
        self.boundary_x = (-1.5, 13.5)
        self.boundary_y = (-2.5, 2.5)

        # Dynamic Tree / Plant Obstacle Mocap Pool (for legacy multi-obstacle worlds)
        self.plant_mocap_ids = []
        for i in range(20):
            bid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, f"plant_obs_{i}")
            if bid >= 0 and self.model.body_mocapid[bid] >= 0:
                self.plant_mocap_ids.append(self.model.body_mocapid[bid])
        self.next_plant_idx = 0
        self.active_obstacles = []
        self.pending_obstacles_queue = None

        # Physical drone dimensions & passability thresholds (IEEE 8491889 Section IV.B)
        self.drone_wingspan = 0.52        # Total physical frame size (meters)
        self.safety_margin = 0.16         # Aerodynamic / blade safety buffer (meters)
        self.min_passable_width = self.drone_wingspan + self.safety_margin  # 0.68m
        self.path_blocked = False
        self.measured_gap_width = 999.0
        self.blockage_reason = ""

        # Telemetry storage
        self.telemetry = []
        self.reset()

    def place_stick_obstacle(self, x: float, y: float) -> bool:
        """
        Dynamically places a slender stick obstacle at (x, y) as the user wishes.
        """
        if self.next_stick_idx < len(self.stick_mocap_ids):
            mocap_id = self.stick_mocap_ids[self.next_stick_idx]
            self.data.mocap_pos[mocap_id] = [float(x), float(y), 0.0]
            self.active_obstacles.append((float(x), float(y)))
            self.next_stick_idx += 1
            print(f"  [STICK] Placed Stick Obstacle #{self.next_stick_idx} at ({float(x):.2f}, {float(y):.2f})m")
            return True
        elif self.next_plant_idx < len(self.plant_mocap_ids):
            mocap_id = self.plant_mocap_ids[self.next_plant_idx]
            self.data.mocap_pos[mocap_id] = [float(x), float(y), 0.0]
            self.active_obstacles.append((float(x), float(y)))
            self.next_plant_idx += 1
            return True
        return False

    def start_new_journey_from_here(self, new_goal_xy: tuple, new_obstacles: list = None, new_waypoints: list = None):
        """
        Begins a new autonomous flight journey starting directly from the drone's current position,
        without closing or restarting the 3D simulation!
        """
        curr_state = self.get_state()
        pos = curr_state["pos"]
        
        self.start_pos = (float(pos[0]), float(pos[1]), float(pos[2]))
        self.start_coord = (float(pos[0]), float(pos[1]))
        gx, gy = float(new_goal_xy[0]), float(new_goal_xy[1])
        self.target_goal = (gx, gy, self.cruise_altitude)
        if new_waypoints:
            self.waypoints = [tuple(p) for p in new_waypoints]
        else:
            self.waypoints = [(gx, gy)]
        self.current_waypoint_idx = 0
        self.patrol_direction = 1
        
        # Reset flight and touchdown state for the new leg: smooth takeoff from ground
        self.target_altitude = self.ground_altitude if pos[2] < 0.25 else float(pos[2])
        self.goal_reached = False
        self.mission_complete = False
        self.touchdown_timer = 0.0
        self.hold_destination_timer = 0.0
        self.hold_complete = False
        self.flight_phase = "TAKEOFF"
        self.path_blocked = False
        self.measured_gap_width = 999.0
        self.blockage_reason = ""
        
        # Pre-align heading towards first waypoint of new journey (identical to initial reset)
        first_target = self.waypoints[0]
        dx_next = first_target[0] - pos[0]
        dy_next = first_target[1] - pos[1]
        if np.hypot(dx_next, dy_next) > 0.01:
            target_yaw_rad = np.arctan2(dy_next, dx_next)
            cy = np.cos(target_yaw_rad * 0.5)
            sy = np.sin(target_yaw_rad * 0.5)
            self.data.qpos[3] = cy
            self.data.qpos[4] = 0.0
            self.data.qpos[5] = 0.0
            self.data.qpos[6] = sy
        if pos[2] < 0.25:
            self.data.qpos[2] = self.ground_altitude
        self.data.qvel[:] = 0.0
        mujoco.mj_forward(self.model, self.data)

        self.integral_z_err = 0.0
        self.integral_vx_err = 0.0
        self.controller.O1 = -1.0
        self.controller.O2 = -1.0
        self.controller.cmd_yaw_rate = 0.0
        self.controller.cmd_vx = 0.0
        self.controller.evasion_timer = 0.0
        self.controller.evasion_side = 0.0
        
        # Place new stick obstacles if provided
        if new_obstacles:
            for ox, oy in new_obstacles:
                self.place_stick_obstacle(ox, oy)
                
        # Move visual helipads to current start and new goal
        self.update_helipad_geoms(start_xy=self.start_coord, goal_xy=(gx, gy), waypoints=self.waypoints)

    def clear_stick_obstacles(self):
        """Hides all stick obstacles underground at z = -50m."""
        for mocap_id in self.stick_mocap_ids:
            self.data.mocap_pos[mocap_id] = [0.0, 0.0, -50.0]
        self.next_stick_idx = 0
        self.active_obstacles = []

    def set_stick_position(self, x: float, y: float):
        """Places/repositions a stick obstacle."""
        self.clear_stick_obstacles()
        self.place_stick_obstacle(x, y)
        self.stick_pos = (float(x), float(y))

    def spawn_tree_obstacle(self, x: float, y: float) -> bool:
        """Places an obstacle at (x, y)."""
        return self.place_stick_obstacle(x, y)

    def update_helipad_geoms(self, start_xy: tuple = None, goal_xy: tuple = None, waypoints: list = None):
        """
        Dynamically relocates the visual helipads (Start Pad in white, Land Pads in light red)
        to match custom user-specified starting position and multiple ending points/waypoints.
        """
        if start_xy is not None:
            sx, sy = float(start_xy[0]), float(start_xy[1])
            geom_map_start = {
                "start_pad_base": [sx, sy, 0.005],
                "start_h_bar1": [sx - 0.22, sy, 0.010],
                "start_h_bar2": [sx + 0.22, sy, 0.010],
                "start_h_cross": [sx, sy, 0.010],
            }
            for name, pos in geom_map_start.items():
                gid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_GEOM, name)
                if gid != -1:
                    self.model.geom_pos[gid] = pos

        wps = waypoints if waypoints is not None else ([goal_xy] if goal_xy is not None else [])
        if hasattr(self, "end_pad_mocap_ids") and self.end_pad_mocap_ids:
            for i, mocap_id in enumerate(self.end_pad_mocap_ids):
                if i < len(wps) and wps[i] is not None:
                    wx, wy = float(wps[i][0]), float(wps[i][1])
                    self.data.mocap_pos[mocap_id] = [wx, wy, 0.005]
                else:
                    self.data.mocap_pos[mocap_id] = [0.0, 0.0, -50.0]

        if goal_xy is not None:
            gx, gy = float(goal_xy[0]), float(goal_xy[1])
            z_offset = -50.0 if (hasattr(self, "end_pad_mocap_ids") and self.end_pad_mocap_ids) else 0.005
            geom_map_land = {
                "land_pad_base": [gx, gy, z_offset],
                "land_h_bar1": [gx - 0.25, gy, z_offset + 0.005],
                "land_h_bar2": [gx + 0.25, gy, z_offset + 0.005],
                "land_h_cross": [gx, gy, z_offset + 0.005],
            }
            for name, pos in geom_map_land.items():
                gid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_GEOM, name)
                if gid != -1:
                    self.model.geom_pos[gid] = pos

    def reset(
        self,
        start_pos: tuple = None,
        start_yaw_deg: float = None,
        target_goal: tuple = None,
        waypoints: list = None,
        continuous_mode: bool = None,
        obstacles: list = None,
        stick_pos: tuple = None,
    ):
        """Reset drone state, coordinates, path waypoints, and simulation data."""
        mujoco.mj_resetData(self.model, self.data)

        # Reset dynamic tree / plant obstacles if present in model
        for mocap_id in self.plant_mocap_ids:
            self.data.mocap_pos[mocap_id] = [0.0, 0.0, -30.0]
        self.next_plant_idx = 0

        # Reset stick obstacles pool
        self.clear_stick_obstacles()
        if obstacles and len(obstacles) > 0:
            for ox, oy in obstacles:
                self.place_stick_obstacle(ox, oy)
        elif stick_pos is not None:
            self.place_stick_obstacle(stick_pos[0], stick_pos[1])
        elif hasattr(self, "stick_mocap_ids") and self.stick_mocap_ids:
            self.place_stick_obstacle(5.0, 0.0)

        if continuous_mode is not None:
            self.continuous_mode = continuous_mode

        if waypoints is not None:
            self.waypoints = [tuple(w[:2]) for w in waypoints]
            self.target_goal = (self.waypoints[-1][0], self.waypoints[-1][1], self.cruise_altitude)
        elif target_goal is not None:
            self.target_goal = (target_goal[0], target_goal[1], target_goal[2] if len(target_goal) > 2 else self.cruise_altitude)
            self.waypoints = [(target_goal[0], target_goal[1])]

        if start_pos is not None:
            if len(start_pos) > 2 and float(start_pos[2]) > 0.5:
                # Direct hover/cruise test (z > 0.5m)
                sz = float(start_pos[2])
                self.target_altitude = sz
                self.initial_target_altitude = sz
                self.flight_phase = "CRUISE"
            else:
                # Realistic ground start on helipad
                sz = self.ground_altitude
                self.target_altitude = self.ground_altitude
                self.initial_target_altitude = self.ground_altitude
                self.flight_phase = "TAKEOFF"
            self.start_pos = (float(start_pos[0]), float(start_pos[1]), sz)
            self.start_coord = (float(start_pos[0]), float(start_pos[1]))
        elif not hasattr(self, "start_pos") or self.start_pos is None:
            self.start_pos = (0.5, 0.0, self.ground_altitude)
            self.start_coord = (0.5, 0.0)
            self.target_altitude = self.ground_altitude
            self.initial_target_altitude = self.ground_altitude
            self.flight_phase = "TAKEOFF"
        else:
            if len(self.start_pos) > 2 and float(self.start_pos[2]) > 0.5:
                self.flight_phase = "CRUISE"
                self.target_altitude = float(self.start_pos[2])
                self.initial_target_altitude = float(self.start_pos[2])
            else:
                self.flight_phase = "TAKEOFF"
                self.target_altitude = self.ground_altitude
                self.initial_target_altitude = self.ground_altitude

        # Update visual helipad positions in 3D world
        final_goal_coord = self.waypoints[-1] if self.waypoints else (self.target_goal[:2] if self.target_goal else None)
        self.update_helipad_geoms(start_xy=self.start_coord, goal_xy=final_goal_coord, waypoints=self.waypoints)

        # Compute initial heading towards first waypoint if not provided
        if start_yaw_deg is None:
            if self.waypoints:
                first_target = self.waypoints[0]
                dx = first_target[0] - self.start_coord[0]
                dy = first_target[1] - self.start_coord[1]
                if np.hypot(dx, dy) > 0.01:
                    start_yaw_deg = float(np.rad2deg(np.arctan2(dy, dx)))
                else:
                    start_yaw_deg = 0.0
            else:
                start_yaw_deg = 0.0

        # Position (x, y, z)
        self.data.qpos[0] = self.start_pos[0]
        self.data.qpos[1] = self.start_pos[1]
        self.data.qpos[2] = self.start_pos[2]

        # Orientation quaternion (w, x, y, z) from yaw
        yaw_rad = np.deg2rad(start_yaw_deg)
        self.data.qpos[3] = np.cos(yaw_rad / 2.0)
        self.data.qpos[4] = 0.0
        self.data.qpos[5] = 0.0
        self.data.qpos[6] = np.sin(yaw_rad / 2.0)

        # Zero velocities
        self.data.qvel[:] = 0.0

        # Initial forward kinematics
        mujoco.mj_forward(self.model, self.data)

        self.target_altitude = self.initial_target_altitude
        self.integral_z_err = 0.0
        self.integral_vx_err = 0.0
        self.controller.reset()
        self.telemetry = []
        self.current_waypoint_idx = 0
        self.patrol_direction = 1
        self.goal_reached = False
        self.mission_complete = False
        self.touchdown_timer = 0.0
        self.hold_destination_timer = 0.0
        self.hold_duration = 10.0
        self.hold_complete = False
        self.path_blocked = False
        self.measured_gap_width = 999.0
        self.blockage_reason = ""
        self.trail_points = []

    def get_state(self) -> dict:
        """Extract position, quaternion, Euler angles, linear/angular velocities."""
        pos = self.data.qpos[0:3].copy()
        quat = self.data.qpos[3:7].copy()  # [w, x, y, z]
        
        # Convert quaternion to Roll, Pitch, Yaw (radians)
        w, x, y, z = quat
        # Roll (x-axis rotation)
        sinr_cosp = 2 * (w * x + y * z)
        cosr_cosp = 1 - 2 * (x * x + y * y)
        roll = np.arctan2(sinr_cosp, cosr_cosp)
        
        # Pitch (y-axis rotation)
        sinp = 2 * (w * y - z * x)
        pitch = np.arcsin(np.clip(sinp, -1.0, 1.0))
        
        # Yaw (z-axis rotation)
        siny_cosp = 2 * (w * z + x * y)
        cosy_cosp = 1 - 2 * (y * y + z * z)
        yaw = np.arctan2(siny_cosp, cosy_cosp)
        
        # Linear velocity in world frame
        linvel_world = self.data.qvel[0:3].copy()
        # Angular velocity in body frame
        angvel_body = self.data.qvel[3:6].copy()
        
        # Rotate linear velocity to body frame
        # Rotation matrix R_wb:
        R_bw = np.array([
            [np.cos(yaw)*np.cos(pitch), np.sin(yaw)*np.cos(pitch), -np.sin(pitch)],
            [np.cos(yaw)*np.sin(pitch)*np.sin(roll) - np.sin(yaw)*np.cos(roll),
             np.sin(yaw)*np.sin(pitch)*np.sin(roll) + np.cos(yaw)*np.cos(roll),
             np.cos(pitch)*np.sin(roll)],
            [np.cos(yaw)*np.sin(pitch)*np.cos(roll) + np.sin(yaw)*np.sin(roll),
             np.sin(yaw)*np.sin(pitch)*np.cos(roll) - np.cos(yaw)*np.sin(roll),
             np.cos(pitch)*np.cos(roll)]
        ])
        linvel_body = R_bw @ linvel_world
        
        return {
            "pos": pos,
            "quat": quat,
            "roll": roll,
            "pitch": pitch,
            "yaw": yaw,
            "linvel_world": linvel_world,
            "linvel_body": linvel_body,
            "angvel_body": angvel_body,
        }

    def get_sensors(self) -> tuple:
        """
        Reads the strictly 2 forward LiDAR rangefinder sensors (range_left and range_right, IEEE 8491889).
        Perception is pitch-stabilized in the horizontal plane to maintain clear forward perception
        at any cruise speed (up to 10 m/s) without ground tilt interference.
        """
        yaw = self.get_state()["yaw"]
        d_max = self.controller.d_max

        def cast_lidar(site_name: str, angle_offset_deg: float) -> float:
            sid = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, site_name)
            if sid < 0:
                return d_max
            p0 = self.data.site_xpos[sid].copy()
            ang = yaw + np.deg2rad(angle_offset_deg)
            ray_dir = np.array([np.cos(ang), np.sin(ang), 0.0], dtype=np.float64)
            geom_out = np.zeros(1, dtype=np.int32)
            d = float(mujoco.mj_ray(self.model, self.data, p0, ray_dir, None, 1, -1, geom_out))
            if 0.08 < d <= d_max:
                return d
            return d_max

        # Exactly 2 forward LiDAR sensors (Left sector and Right sector, IEEE 8491889)
        d_left_candidates = [cast_lidar("site_range_left", ang) for ang in [+4.0, +12.0, +20.0]]
        d_right_candidates = [cast_lidar("site_range_right", ang) for ang in [-4.0, -12.0, -20.0]]
        dist_left = min(d_left_candidates)
        dist_right = min(d_right_candidates)

        return dist_left, dist_right

    def compute_autopilot_control(self, cmd_vx: float, cmd_yaw_rate: float):
        """
        Computes 4 rotor motor thrusts to track commanded forward speed, altitude, and yaw rate.
        """
        state = self.get_state()
        pos = state["pos"]
        roll = state["roll"]
        pitch = state["pitch"]
        yaw = state["yaw"]
        vx_b = state["linvel_body"][0]
        vy_b = state["linvel_body"][1]
        vz_w = state["linvel_world"][2]
        wx = state["angvel_body"][0]
        wy = state["angvel_body"][1]
        wz = state["angvel_body"][2]

        # 1. Altitude Control (Vertical thrust)
        z_err = self.target_altitude - pos[2]
        self.integral_z_err = np.clip(self.integral_z_err + z_err * self.ctrl_dt, -1.0, 1.0)
        
        thrust_z = (
            self.hover_thrust_total
            + self.kp_z * z_err
            - self.kd_z * vz_w
            + self.ki_z * self.integral_z_err
        )
        # Account for tilt compensation: T = Fz / (cos(roll)*cos(pitch))
        tilt_factor = np.clip(np.cos(roll) * np.cos(pitch), 0.6, 1.0)
        thrust_z = thrust_z / tilt_factor

        # 2. Horizontal Velocity Control -> Desired Pitch and Roll
        # Positive pitch (theta > 0) tilts thrust forward (+X)
        if not hasattr(self, "integral_vx_err"):
            self.integral_vx_err = 0.0
        if cmd_vx > 0.0001:
            err_vx = cmd_vx - vx_b
            self.integral_vx_err = float(np.clip(self.integral_vx_err + err_vx * self.ctrl_dt, -0.20, 0.20))
        else:
            err_vx = 0.0 - vx_b
            self.integral_vx_err = 0.0

        # Scale max pitch tilt for higher cruise speeds up to 10 m/s
        max_tilt = float(np.clip(0.18 + 0.035 * max(0.0, cmd_vx - 1.0), 0.18, 0.52))
        theta_des = np.clip(self.kp_vx * err_vx + 0.10 * self.integral_vx_err - self.kd_vx * vx_b, -max_tilt, max_tilt)

        # Negative roll (phi < 0) tilts thrust left (+Y)
        err_vy = 0.0 - vy_b
        phi_des = np.clip(-(self.kp_vy * err_vy - self.kd_vy * vy_b), -0.18, 0.18)

        # 3. Attitude Control (Moments tau_x, tau_y, tau_z)
        tau_x = self.kp_att * (phi_des - roll) - self.kd_att * wx
        tau_y = self.kp_att * (theta_des - pitch) - self.kd_att * wy
        tau_z = self.kd_yaw * (cmd_yaw_rate - wz)

        # 4. Motor Mixer (X-Configuration)
        # FR: (+X, -Y) -> +Z, -roll, -pitch, -yaw
        # FL: (+X, +Y) -> +Z, +roll, -pitch, +yaw
        # RR: (-X, -Y) -> +Z, -roll, +pitch, +yaw
        # RL: (-X, +Y) -> +Z, +roll, +pitch, -yaw
        f_base = thrust_z / 4.0
        
        d_arm = self.arm_length
        c_tau = 0.02  # Torque to thrust ratio
        
        u_fr = f_base - (tau_x / (4 * d_arm)) - (tau_y / (4 * d_arm)) - (tau_z / (4 * c_tau))
        u_fl = f_base + (tau_x / (4 * d_arm)) - (tau_y / (4 * d_arm)) + (tau_z / (4 * c_tau))
        u_rr = f_base - (tau_x / (4 * d_arm)) + (tau_y / (4 * d_arm)) + (tau_z / (4 * c_tau))
        u_rl = f_base + (tau_x / (4 * d_arm)) + (tau_y / (4 * d_arm)) - (tau_z / (4 * c_tau))

        # Clamp motor thrusts within actuator limits [0, 16.0 N]
        self.data.ctrl[0] = np.clip(u_fr, 0.0, 16.0)
        self.data.ctrl[1] = np.clip(u_fl, 0.0, 16.0)
        self.data.ctrl[2] = np.clip(u_rr, 0.0, 16.0)
        self.data.ctrl[3] = np.clip(u_rl, 0.0, 16.0)

    def step_control(self) -> dict:
        """
        Executes one high-level control step:
        Reads sensors, evaluates neural controller, updates autopilot, and steps physics.
        """
        # 0. Check for dynamically spawned tree/plant obstacles from interactive planner
        if hasattr(self, "pending_obstacles_queue") and self.pending_obstacles_queue is not None:
            while not self.pending_obstacles_queue.empty():
                try:
                    ox, oy = self.pending_obstacles_queue.get_nowait()
                    self.spawn_tree_obstacle(ox, oy)
                except Exception:
                    break

        state = self.get_state()
        pos = state["pos"]
        yaw = state["yaw"]

        # 1. Read distance sensors
        dist_left, dist_right = self.get_sensors()

        # 2. Waypoint guidance & continuous patrol logic
        goal_heading_err = None
        dist_to_goal = None
        curr_target = None
        evading_obstacle = False

        if self.waypoints:
            if self.patrol_direction == 1:
                curr_target = self.waypoints[self.current_waypoint_idx]
            else:
                curr_target = self.waypoints[self.current_waypoint_idx] if self.current_waypoint_idx >= 0 else self.start_coord

            target_pt = np.array(curr_target, dtype=np.float64)
            v_to_goal = target_pt - pos[:2]
            dist_to_goal = float(np.linalg.norm(v_to_goal))

            # Reset passability state
            self.path_blocked = False
            self.measured_gap_width = 999.0
            self.blockage_reason = ""

            # Check if any placed stick obstacle is blocking the direct path ahead (only during CRUISE)
            if self.active_obstacles and dist_to_goal > 0.65 and self.flight_phase == "CRUISE":
                u_goal = v_to_goal / dist_to_goal
                u_perp = np.array([-u_goal[1], u_goal[0]])  # Left perpendicular

                closest_obs = None
                min_s = 999.0
                for ox, oy in self.active_obstacles:
                    v_obs = np.array([ox - pos[0], oy - pos[1]])
                    s_along = float(np.dot(v_obs, u_goal))
                    d_lat = float(np.dot(v_obs, u_perp))
                    # Obstacle is ahead of drone and within collision corridor
                    # Extended to -0.55m to ensure rear wings fully clear before release
                    if -0.55 < s_along < 3.2 and abs(d_lat) < 1.6:
                        if s_along < min_s:
                            min_s = s_along
                            closest_obs = (ox, oy, s_along, d_lat)

                if closest_obs is not None:
                    ox, oy, s_along, d_lat = closest_obs

                    # Calculate lateral clearance on left (+u_perp) and right (-u_perp)
                    # 1. Boundary wall limits: Y in [-2.5, 2.5]
                    y_north = self.boundary_y[1]
                    y_south = self.boundary_y[0]
                    clearance_left = float(y_north - oy - 0.04)
                    clearance_right = float(oy - y_south - 0.04)

                    # 2. Check other obstacles forming a wall / barrier across the corridor
                    for ox2, oy2 in self.active_obstacles:
                        if (ox2, oy2) == (ox, oy):
                            continue
                        if abs(ox2 - ox) < 0.90:  # Obstacles in same transverse line/cluster
                            if oy2 > oy:
                                gap_l = (oy2 - oy) - 0.08
                                clearance_left = min(clearance_left, gap_l)
                            elif oy2 < oy:
                                gap_r = (oy - oy2) - 0.08
                                clearance_right = min(clearance_right, gap_r)

                    passable_left = (clearance_left >= self.min_passable_width)
                    passable_right = (clearance_right >= self.min_passable_width)
                    max_gap = max(clearance_left, clearance_right)
                    self.measured_gap_width = float(max_gap)

                    if not passable_left and not passable_right:
                        # WHOLE PACKED: No passage wider than drone wingspan + margin
                        self.path_blocked = True
                        self.blockage_reason = f"Whole packed: Gap {max_gap:.2f}m < Drone {self.min_passable_width:.2f}m"
                        # Hold safe standoff distance 1.2m before obstacle
                        standoff = max(0.85, s_along - 1.2)
                        target_pt = pos[:2] + standoff * u_goal
                    else:
                        # PASSABLE: At least one side accommodates drone size
                        self.path_blocked = False
                        if passable_left and not passable_right:
                            detour_dir = 1.0
                        elif passable_right and not passable_left:
                            detour_dir = -1.0
                        else:
                            # Both sides open: choose side with greater clearance or open space
                            if abs(d_lat) >= 0.04:
                                detour_dir = -1.0 if d_lat > 0 else 1.0
                            else:
                                detour_dir = -1.0 if pos[1] >= 0 else 1.0

                        clearance = 0.88  # 88 cm clearance ensures 35-45 cm visible safety gap from outer wing tip
                        if s_along > 0.25:
                            # Approach phase: steer outward ahead of the obstacle
                            bypass_pt = np.array([ox, oy]) + detour_dir * clearance * u_perp - 0.25 * u_goal
                        else:
                            # Bypass phase: fly parallel to corridor past the obstacle
                            bypass_pt = np.array([ox, oy]) + detour_dir * clearance * u_perp + 0.60 * u_goal

                        # Hold bypass corridor until rear wing tips (at -0.34m) have completely cleared the obstacle
                        if s_along > -0.45:
                            target_pt = bypass_pt
                            if s_along < 2.5:
                                evading_obstacle = True

            dx = target_pt[0] - pos[0]
            dy = target_pt[1] - pos[1]
            dist_to_target = float(np.hypot(dx, dy))
            desired_yaw = np.arctan2(dy, dx)
            goal_heading_err = float((desired_yaw - yaw + np.pi) % (2.0 * np.pi) - np.pi)

            # Check if drone reached the actual flight waypoint (Destination helipad)
            dist_to_waypoint = float(np.hypot(curr_target[0] - pos[0], curr_target[1] - pos[1]))
            dist_to_goal = dist_to_waypoint

            if dist_to_waypoint <= self.goal_radius:
                if self.patrol_direction == 1:
                    if self.continuous_mode:
                        if self.current_waypoint_idx < len(self.waypoints) - 1:
                            self.current_waypoint_idx += 1
                        else:
                            # Reached final waypoint: reverse patrol direction!
                            self.patrol_direction = -1
                            if len(self.waypoints) > 1:
                                self.current_waypoint_idx = len(self.waypoints) - 2
                            else:
                                self.current_waypoint_idx = -1  # head back to start_coord
                    else:
                        # Single mode: touch down on ground at this ending point
                        if self.flight_phase == "CRUISE":
                            self.flight_phase = "LANDING"
                else:
                    # Reverse patrol journey back to start
                    if self.current_waypoint_idx > 0:
                        self.current_waypoint_idx -= 1
                    elif self.current_waypoint_idx == 0:
                        self.current_waypoint_idx = -1  # next is start_coord
                    else:
                        # Reached start_coord! Reverse patrol direction forward!
                        self.patrol_direction = 1
                        self.current_waypoint_idx = 0

            # Flight Phase State Machine (Ground Start -> Cruise -> Ground Landing -> Next End Point)
            if self.flight_phase == "TAKEOFF":
                self.touchdown_timer = 0.0
                # Smooth vertical climb from ground (0.072m) to cruise altitude
                self.target_altitude = min(self.cruise_altitude, self.target_altitude + 0.85 * self.ctrl_dt)
                if pos[2] >= (self.cruise_altitude - 0.15):
                    self.flight_phase = "CRUISE"

            elif self.flight_phase == "LANDING" and not self.continuous_mode:
                # Smooth vertical descent from cruise altitude down to ground helipad
                self.target_altitude = max(0.070, self.target_altitude - 0.50 * self.ctrl_dt)
                if pos[2] <= 0.080:
                    self.touchdown_timer += self.ctrl_dt
                    if self.touchdown_timer >= 1.20:
                        # Touchdown complete on the ground!
                        if self.current_waypoint_idx < len(self.waypoints) - 1:
                            # Intermediate ending point: ground touchdown complete!
                            # Advance to next ending point, reset touchdown timer, and take off again!
                            print(f"\n[MISSION] [OK] Drone touched down on ground at Ending Point #{self.current_waypoint_idx + 1} at ({pos[0]:.2f}, {pos[1]:.2f})m. Taking off for Ending Point #{self.current_waypoint_idx + 2}!")
                            self.current_waypoint_idx += 1
                            self.touchdown_timer = 0.0
                            self.flight_phase = "TAKEOFF"
                            self.target_altitude = self.ground_altitude

                            # Re-align heading directly towards next waypoint on ground helipad (identical to initial reset)
                            next_target = self.waypoints[self.current_waypoint_idx]
                            dx_next = next_target[0] - pos[0]
                            dy_next = next_target[1] - pos[1]
                            target_yaw_rad = np.arctan2(dy_next, dx_next) if np.hypot(dx_next, dy_next) > 0.01 else yaw
                            cy = np.cos(target_yaw_rad * 0.5)
                            sy = np.sin(target_yaw_rad * 0.5)
                            self.data.qpos[3] = cy
                            self.data.qpos[4] = 0.0
                            self.data.qpos[5] = 0.0
                            self.data.qpos[6] = sy
                            self.data.qpos[2] = self.ground_altitude
                            self.data.qvel[:] = 0.0
                            mujoco.mj_forward(self.model, self.data)

                            self.integral_z_err = 0.0
                            self.integral_vx_err = 0.0
                            self.controller.O1 = -1.0
                            self.controller.O2 = -1.0
                            self.controller.cmd_yaw_rate = 0.0
                            self.controller.cmd_vx = 0.0
                            self.controller.evasion_timer = 0.0
                            self.controller.evasion_side = 0.0
                        else:
                            # Final ending point reached!
                            self.mission_complete = True
                            self.goal_reached = True
                            self.flight_phase = "LANDED"
                            print(f"\n[SIMULATION] [SUCCESS] Task finished! Drone landed safely on ground at ({pos[0]:.2f}, {pos[1]:.2f})m.")

            elif self.flight_phase == "LANDED" and not self.continuous_mode:
                self.target_altitude = self.ground_altitude
                self.mission_complete = True
                self.hold_destination_timer += self.ctrl_dt
                if self.hold_destination_timer >= self.hold_duration:
                    self.hold_complete = True

        # 3. Neural Controller update
        # In continuous mode, do not brake at waypoints (maintain continuous flight).
        # Only in single mode approaching final destination do we brake to land.
        eval_dist_to_goal = dist_to_goal if (not self.continuous_mode and self.current_waypoint_idx == len(self.waypoints) - 1 and self.patrol_direction == 1) else None

        ctrl_info = self.controller.step(
            dist_left,
            dist_right,
            goal_heading_err=goal_heading_err if not self.mission_complete else 0.0,
            dist_to_goal=eval_dist_to_goal if not self.mission_complete else 0.0,
        )
        if self.flight_phase in ("LANDED", "LANDING") or self.mission_complete:
            cmd_vx = 0.0
            cmd_yaw_rate = 0.0
        elif self.path_blocked:
            # Whole packed blockage: halt forward flight, hover safely in standoff
            cmd_vx = 0.0
            cmd_yaw_rate = 0.0
        elif self.flight_phase == "TAKEOFF":
            cmd_vx = 0.0
            if pos[2] < 0.12:
                cmd_yaw_rate = 0.0
            else:
                cmd_yaw_rate = float(np.clip(0.6 * goal_heading_err, -0.35, 0.35)) if goal_heading_err is not None else 0.0
        else:
            cmd_vx = ctrl_info["cmd_vx"]
            cmd_yaw_rate = ctrl_info["cmd_yaw_rate"]

            # Tight turn speed braking: prevents overshooting waypoints during sharp turns
            if goal_heading_err is not None and abs(goal_heading_err) > np.deg2rad(25.0):
                cmd_vx = min(cmd_vx, max(0.25, 0.65 * (1.0 - abs(goal_heading_err) / np.pi)))

            # Obstacle evasion speed regulation: allows gentle, wide yaw turning without corner-cutting
            if evading_obstacle:
                cmd_vx = min(cmd_vx, 0.45)

            # Boundary containment steering: strictly confines drone within rectangular arena
            # Arena: X in [-1.5, 13.5], Y in [-2.5, 2.5]
            margin_y = 0.55
            if pos[1] > (self.boundary_y[1] - margin_y):
                # Approaching North boundary (Y = +2.5m) -> steer South (-Y) slowly and smoothly
                excess = (pos[1] - (self.boundary_y[1] - margin_y)) / margin_y
                cmd_yaw_rate = float(np.clip(cmd_yaw_rate - 0.35 * excess, -0.35, 0.35))
            elif pos[1] < (self.boundary_y[0] + margin_y):
                # Approaching South boundary (Y = -2.5m) -> steer North (+Y) slowly and smoothly
                excess = ((self.boundary_y[0] + margin_y) - pos[1]) / margin_y
                cmd_yaw_rate = float(np.clip(cmd_yaw_rate + 0.35 * excess, -0.35, 0.35))

            # Approaching East wall (+13.5m) or West wall (-1.5m)
            if pos[0] > (self.boundary_x[1] - 0.6) and not self.goal_reached:
                cmd_vx = min(cmd_vx, 0.2)
            elif pos[0] < (self.boundary_x[0] + 0.6) and self.patrol_direction == -1:
                cmd_vx = min(cmd_vx, 0.2)

        # 4. Apply wind perturbation if enabled (random gusts as described in paper)
        if self.enable_wind:
            wind_fx = np.random.normal(0.0, 0.4)
            wind_fy = np.random.normal(0.2, 0.5)
            self.data.qfrc_applied[0] = wind_fx
            self.data.qfrc_applied[1] = wind_fy

        # 5. Step physics at high frequency (sim_steps_per_ctrl)
        for _ in range(self.sim_steps_per_ctrl):
            if self.mission_complete or self.flight_phase == "LANDED":
                self.data.ctrl[:] = 0.0
            else:
                self.compute_autopilot_control(cmd_vx, cmd_yaw_rate)
            mujoco.mj_step(self.model, self.data)

        # 6. Record telemetry snapshot
        state_after = self.get_state()
        record = {
            "sim_time": float(self.data.time),
            "pos_x": float(state_after["pos"][0]),
            "pos_y": float(state_after["pos"][1]),
            "pos_z": float(state_after["pos"][2]),
            "flight_phase": self.flight_phase,
            "path_blocked": self.path_blocked,
            "gap_width": float(self.measured_gap_width),
            "drone_size": float(self.drone_wingspan),
            "min_passable_width": float(self.min_passable_width),
            "roll": float(np.rad2deg(state_after["roll"])),
            "pitch": float(np.rad2deg(state_after["pitch"])),
            "yaw": float(np.rad2deg(state_after["yaw"])),
            "vx_body": float(state_after["linvel_body"][0]),
            "vy_body": float(state_after["linvel_body"][1]),
            "dist_to_goal": dist_to_goal if dist_to_goal is not None else 0.0,
            "goal_reached": self.goal_reached,
            "mission_complete": self.mission_complete,
            "hold_timer": float(self.hold_destination_timer),
            "hold_remaining": max(0.0, float(self.hold_duration - self.hold_destination_timer)),
            "hold_complete": self.hold_complete,
            "stick_pos_x": float(self.stick_pos[0]),
            "stick_pos_y": float(self.stick_pos[1]),
            "waypoint_idx": self.current_waypoint_idx,
            "patrol_direction": self.patrol_direction,
            **ctrl_info,
            "cmd_vx": float(cmd_vx),
            "cmd_yaw_rate": float(cmd_yaw_rate),
        }
        self.telemetry.append(record)
        
        # Real-time 3D flight trajectory trail (capped to prevent geometry buffer overflow)
        p_now = np.array([record["pos_x"], record["pos_y"], record["pos_z"]])
        is_alert = (min(record["dist_left"], record["dist_right"]) < 2.5)
        if not self.trail_points or np.linalg.norm(p_now - self.trail_points[-1][0]) > 0.08:
            self.trail_points.append((p_now, is_alert))
            if len(self.trail_points) > 350:
                self.trail_points.pop(0)

        return record

    def run_headless(self, duration_sec: float = 25.0) -> list:
        """
        Runs the simulation in headless (fast-forward) mode without rendering window.
        Returns complete telemetry log.
        """
        total_steps = int(duration_sec * self.ctrl_freq)
        for _ in range(total_steps):
            self.step_control()
            if self.hold_complete or (self.continuous_mode and self.mission_complete):
                break
        return self.telemetry

    def render_lidar_beams(self, viewer):
        """
        Renders the active 3D LiDAR laser beams and obstacle contact points in the visualizer.
        Beams glow cool cyan in clear space and bright hazard amber/red upon detecting an obstacle.
        """
        if not hasattr(viewer, "user_scn"):
            return

        viewer.user_scn.ngeom = 0
        
        # EXACTLY 2 LiDAR sensors (Only 2 laser lights, IEEE 8491889)
        # 1: Left LiDAR (+10 deg), 2: Right LiDAR (-10 deg)
        sensor_sites = [
            ("site_range_left", +10.0),
            ("site_range_right", -10.0),
        ]

        yaw = self.get_state()["yaw"]
        d_max = self.controller.d_max

        for site_name, angle_offset_deg in sensor_sites:
            try:
                site_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_SITE, site_name)
            except Exception:
                continue

            if site_id < 0:
                continue

            p_start = self.data.site_xpos[site_id].copy()
            ang = yaw + np.deg2rad(angle_offset_deg)
            beam_dir = np.array([np.cos(ang), np.sin(ang), 0.0], dtype=np.float64)
            geom_out = np.zeros(1, dtype=np.int32)
            ray_dist = float(mujoco.mj_ray(self.model, self.data, p_start, beam_dir, None, 1, -1, geom_out))

            hit = (0.08 < ray_dist <= d_max)
            beam_length = ray_dist if hit else d_max
            p_end = p_start + beam_length * beam_dir

            if hit:
                # Warning bright hazard red laser when obstacle detected
                rgba = np.array([1.0, 0.10, 0.10, 0.95], dtype=np.float32)
                beam_width = 0.009
            else:
                # Scanning warm golden laser in clear space (Zero blue transparency)
                rgba = np.array([0.98, 0.85, 0.20, 0.65], dtype=np.float32)
                beam_width = 0.005

            # Draw laser beam capsule (1 of the 2 lights)
            if viewer.user_scn.ngeom < viewer.user_scn.maxgeom - 5:
                g_idx = viewer.user_scn.ngeom
                mujoco.mjv_initGeom(
                    viewer.user_scn.geoms[g_idx],
                    mujoco.mjtGeom.mjGEOM_CAPSULE,
                    np.zeros(3),
                    np.zeros(3),
                    np.eye(3).flatten(),
                    rgba
                )
                mujoco.mjv_connector(
                    viewer.user_scn.geoms[g_idx],
                    mujoco.mjtGeom.mjGEOM_CAPSULE,
                    beam_width,
                    p_start,
                    p_end
                )
                viewer.user_scn.ngeom += 1

                # If hit obstacle, place illuminated contact marker sphere
                if hit and viewer.user_scn.ngeom < viewer.user_scn.maxgeom - 5:
                    c_idx = viewer.user_scn.ngeom
                    mujoco.mjv_initGeom(
                        viewer.user_scn.geoms[c_idx],
                        mujoco.mjtGeom.mjGEOM_SPHERE,
                        np.array([0.038, 0.038, 0.038]),
                        p_end,
                        np.eye(3).flatten(),
                        np.array([1.0, 0.15, 0.15, 0.95], dtype=np.float32)
                    )
                    viewer.user_scn.ngeom += 1

        # ==================== 3D REAL-TIME TRAJECTORY TRAIL ====================
        # Renders a continuous 3D ribbon trail behind the drone as it maneuvers:
        # Sky-Blue during clear cruising, Vivid Red during active obstacle evasion!
        if hasattr(self, "trail_points") and len(self.trail_points) >= 2:
            for i in range(len(self.trail_points) - 1):
                if viewer.user_scn.ngeom >= viewer.user_scn.maxgeom - 10:
                    break
                p1, alert1 = self.trail_points[i]
                p2, alert2 = self.trail_points[i + 1]
                
                if alert1 or alert2:
                    t_rgba = np.array([1.0, 0.15, 0.15, 0.90], dtype=np.float32)
                    t_width = 0.016
                else:
                    t_rgba = np.array([0.22, 0.75, 1.0, 0.75], dtype=np.float32)
                    t_width = 0.010

                t_idx = viewer.user_scn.ngeom
                mujoco.mjv_initGeom(
                    viewer.user_scn.geoms[t_idx],
                    mujoco.mjtGeom.mjGEOM_CAPSULE,
                    np.zeros(3),
                    np.zeros(3),
                    np.eye(3).flatten(),
                    t_rgba
                )
                mujoco.mjv_connector(
                    viewer.user_scn.geoms[t_idx],
                    mujoco.mjtGeom.mjGEOM_CAPSULE,
                    t_width,
                    p1,
                    p2
                )
                viewer.user_scn.ngeom += 1

    def run_interactive(self, duration_sec: float = None, cam_mode: str = "arena"):
        """
        Runs the simulation in MuJoCo's interactive 3D graphical viewer with:
        - Real-time 3D LiDAR laser beam rendering
        - Multi-camera director modes (arena, chase, fpv)
        - Live Ground Control Station (GCS) telemetry HUD
        - Stays open until explicitly closed by the user
        """
        import mujoco.viewer

        print("\n" + "="*76)
        print("     LAUNCHING 3D AEROSPACE AUTONOMOUS DRONE FLIGHT SIMULATION")
        print("="*76)
        print("  Visual Features:  Real-Time 3D LiDAR Laser Beams (Cyan/Red)")
        print("                    FAA Navigation Lights & Spinning Rotor Blurs")
        print("                    Asphalt Runway & Dynamic Relocatable Helipads")
        print(f"  Camera Mode:      {cam_mode.upper()} View")
        print(f"  Flight Mode:      {'Continuous Patrol (Indefinite Navigation)' if self.continuous_mode else 'Single Flight (Lands at Destination)'}")
        print("  Control:          Simulation runs continuously until YOU close this window")
        print("  Interactive:      Left-Click = Rotate | Right-Click = Pan | Scroll = Zoom")
        print("="*76 + "\n")

        with mujoco.viewer.launch_passive(self.model, self.data) as viewer:
            # Set default camera viewing angle dynamically framed around path
            final_coord = self.waypoints[-1] if self.waypoints else (self.target_goal[:2] if self.target_goal else (12.0, 0.0))
            mid_x = (self.start_coord[0] + final_coord[0]) / 2.0
            mid_y = (self.start_coord[1] + final_coord[1]) / 2.0
            span = float(np.hypot(final_coord[0] - self.start_coord[0], final_coord[1] - self.start_coord[1]))

            if cam_mode == "arena":
                viewer.cam.distance = max(14.0, span * 1.25)
                viewer.cam.elevation = -28.0
                viewer.cam.azimuth = 145.0
                viewer.cam.lookat[:] = [mid_x, mid_y, 1.2]
            elif cam_mode == "chase":
                viewer.cam.distance = 4.2
                viewer.cam.elevation = -18.0
                viewer.cam.azimuth = 180.0
                viewer.cam.lookat[:] = [self.start_pos[0], self.start_pos[1], self.start_pos[2]]
            elif cam_mode == "fpv":
                viewer.cam.distance = 0.4
                viewer.cam.elevation = -5.0
                viewer.cam.azimuth = 0.0
                viewer.cam.lookat[:] = [self.start_pos[0] + 2.0, self.start_pos[1], self.start_pos[2]]

            start_time = time.time()
            sim_time = 0.0
            last_print_time = 0.0
            debrief_printed = False

            def format_bar(val: float, max_val: float = 3.5, width: int = 5) -> str:
                filled = int(round((val / max_val) * width))
                filled = max(0, min(width, filled))
                return "█" * filled + "░" * (width - filled)

            while viewer.is_running() and (duration_sec is None or sim_time < duration_sec):
                step_start = time.time()

                record = self.step_control()
                sim_time = record["sim_time"]

                # Render active 3D LiDAR laser beams
                self.render_lidar_beams(viewer)

                # Dynamic camera tracking for Chase & FPV modes
                pos = [record["pos_x"], record["pos_y"], record["pos_z"]]
                yaw_deg = record["yaw"]
                yaw_rad = np.deg2rad(yaw_deg)
                
                if cam_mode == "chase":
                    viewer.cam.lookat[:] = [pos[0] + 0.4 * np.cos(yaw_rad), pos[1] + 0.4 * np.sin(yaw_rad), pos[2] + 0.25]
                    viewer.cam.distance = 3.8
                    viewer.cam.elevation = -16.0
                    viewer.cam.azimuth = float(yaw_deg + 180.0)
                elif cam_mode == "fpv":
                    viewer.cam.lookat[:] = [pos[0] + 3.0 * np.cos(yaw_rad), pos[1] + 3.0 * np.sin(yaw_rad), pos[2]]
                    viewer.cam.distance = 0.35
                    viewer.cam.elevation = -5.0
                    viewer.cam.azimuth = float(yaw_deg)

                # Live Ground Control Station (GCS) HUD Telemetry
                if sim_time - last_print_time >= 0.4:
                    last_print_time = sim_time
                    d_l = record["dist_left"]
                    d_r = record["dist_right"]
                    min_l = min(d_l, d_r)
                    vx = record["cmd_vx"]
                    alt = record["pos_z"]
                    hdg = int(round(record["yaw"]))
                    g_dist = record.get("dist_to_goal", 0.0)
                    b1 = record.get("b1", 2.4)
                    b2 = record.get("b2", 2.4)

                    if self.mission_complete:
                        stage = "TOUCHDOWN_REST"
                    elif self.goal_reached:
                        stage = "TOUCHDOWN_DESC"
                    elif min_l < 2.2:
                        stage = "NEURAL_AVOIDANCE"
                    elif self.continuous_mode and self.waypoints:
                        d_str = "FWD" if self.patrol_direction == 1 else "REV"
                        wp_num = (self.current_waypoint_idx + 1) if self.current_waypoint_idx >= 0 else 0
                        stage = f"PATROL_{d_str}_WP{wp_num}"
                    elif g_dist < 2.0:
                        stage = "FINAL_APPROACH"
                    else:
                        stage = "CRUISE_EN_ROUTE"

                    bar_l = format_bar(d_l)
                    bar_r = format_bar(d_r)
                    print(f"  [GCS] T={sim_time:5.1f}s | {stage:<17} | ALT:{alt:4.2f}m | SPD:{vx:4.2f}m/s | HDG:{hdg:+4d}° | GOAL:{g_dist:4.1f}m | LiDAR:[L:{bar_l} R:{bar_r}] | W:[{b1:.2f}, {b2:.2f}]")

                # Sync graphics
                viewer.sync()

                # In single flight mode: display debrief once upon landing without terminating the window!
                if self.mission_complete and not debrief_printed:
                    debrief_printed = True
                    final = self.telemetry[-1]
                    min_clearance = min(min(t["dist_left"], t["dist_right"]) for t in self.telemetry)
                    print("\n" + "=" * 76)
                    print("              AEROSPACE MISSION PERFORMANCE DEBRIEFING")
                    print("=" * 76)
                    print(f"  Flight Outcome:        SUCCESSFUL TOUCHDOWN ON ENDING HELIPAD")
                    print(f"  Final Coordinates:     ({final['pos_x']:.2f}, {final['pos_y']:.2f}, {final['pos_z']:.2f}) m")
                    print(f"  Touchdown Precision:   {final.get('dist_to_goal', 0.0):.2f} m from helipad center")
                    print(f"  Total Flight Duration: {sim_time:.2f} seconds")
                    print(f"  Min Obstacle Margin:   {min_clearance:.2f} meters (Zero Collision Event)")
                    print(f"  Autopilot Flight Mode: MOTORS DISARMED / VIEWER ACTIVE")
                    print("  Note: Window remains open for inspection. Close window or press ESC to exit.")
                    print("=" * 76 + "\n")

                # Real-time synchronization
                elapsed = time.time() - step_start
                sleep_time = self.ctrl_dt - elapsed
                if sleep_time > 0:
                    time.sleep(sleep_time)

            if not debrief_printed and self.telemetry:
                final = self.telemetry[-1]
                min_clearance = min(min(t["dist_left"], t["dist_right"]) for t in self.telemetry)
                print("\n" + "=" * 76)
                print("             SIMULATION SESSION CLOSED BY USER")
                print("=" * 76)
                print(f"  Final Drone Position:  ({final['pos_x']:.2f}, {final['pos_y']:.2f}, {final['pos_z']:.2f}) m")
                print(f"  Total Simulation Time: {sim_time:.2f} seconds")
                print(f"  Min Obstacle Margin:   {min_clearance:.2f} meters")
                print("=" * 76 + "\n")

        return self.telemetry

        return self.telemetry
