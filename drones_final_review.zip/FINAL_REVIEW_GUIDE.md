# Autonomous Quadrotor Drone Obstacle Avoidance Simulation
## Final Review & Demonstration Guide (IEEE 8491889)

---

## 1. Project Overview
This project implements a complete, physics-accurate **Autonomous Quadrotor Drone Simulation** in **MuJoCo 3.x** using Python 3.14. It faithfully implements the online adaptive neural controller and obstacle avoidance dynamics from **IEEE 8491889**, enhanced with realistic physical ground landings, aperture-based corridor sizing, multi-destination flight sequences, and auditory feedback.

---

## 2. Key Features Implemented

### A. Ground-to-Ground Flight Cycle
- **1st Start Point**: Drone starts firmly resting on the ground at the **Pure White Helipad** ($z \approx 0.072\text{ m}$, 4 landing skid contact points).
- **Vertical Climb**: Smooth vertical takeoff climb ($+0.85\text{ m/s}$, `cmd_vx = 0.0`) up to cruise altitude ($1.5\text{ m}$).
- **Sequential Intermediate End Points**: When reaching each intermediate ending point, the drone smoothly descends vertically ($-0.50\text{ m/s}$, `cmd_vx = 0.0`) down to ground level ($z \le 0.080\text{ m}$), touches down on the **Light Red Helipad**, dwells on the ground for $1.2\text{ s}$, then takes off vertically again for the next destination!
- **Final Landing & Motor Cutoff**: At the final destination helipad, the drone lands on the ground, shuts off all motor thrust (`ctrl[:] = 0.0`), disarms, and audibly speaks: **🔊 *"Task finished"***!

### B. Multiple Ending Points & Obstacles
- **1 Start Point**: Exactly 1 starting place (White).
- **Multiple Ending Points**: In Step 2, you can click on the map to add **as many ending points as you wish** (`END #1`, `END #2`, `END #3`, ..., `END #N (FINAL)`). In 3D MuJoCo, each ending point has its own visible **Light Red Helipad** on the ground.
- **Multiple Stick Obstacles**: In Step 3, you can click on the map to place slender stick obstacles along the flight path. Each obstacle has strictly **1 uniform colour** (`#784B27`).
- **Speed Setting**: In Step 4, enter your desired speed anywhere from $0.001\text{ m/s}$ to $1.0\text{ m/s}$ (with presets: `0.001`, `0.01`, `0.05`, `0.1`, `0.25`, `0.5`, `1.0`), then click **`[ 🚀 RUN FLIGHT ]`**!

### C. Obstacle Aperture Sizing vs. Physical Drone Dimensions (IEEE 8491889)
- **Physical Drone Dimensions**: Frame hub-to-hub wingspan is $0.32\text{ m}$ with $0.20\text{ m}$ propellers, giving a physical wingspan of $W_{\text{drone}} = 0.52\text{ m}$.
- **Aerodynamic Safety Margin**: Additional safety buffer $\Delta_{\text{margin}} = 0.16\text{ m}$.
- **Minimum Passable Width**:
  $$W_{\text{min}} = W_{\text{drone}} + \Delta_{\text{margin}} = 0.52\text{ m} + 0.16\text{ m} = 0.68\text{ m}$$
- **"Whole Packed" Blockage Protection**:
  - When obstacles in front leave no gap $\ge 0.68\text{ m}$ (whole packed), the LiDAR sensors and spatial analyzer detect that the drone cannot pass.
  - The drone **brakes forward flight to zero (`cmd_vx = 0.0`)**, holds a safe hover standoff in front of the barrier without crashing, and audibly announces: **🔊 *"Path blocked, cannot pass"***!
  - If a passable opening $\ge 0.68\text{ m}$ exists, the drone proceeds smoothly through the opening!

### D. Wing & Rotor Blade Physical Collision & Wide Evasion Clearance
- **Physical Collision Modeling**: All 4 rotor arms (`arm_fr`, `arm_fl`, `arm_rr`, `arm_rl`), motor bells, and spinning blade discs (`prop_col_fr`, `prop_col_fl`, `prop_col_rr`, `prop_col_rl`) have explicit active collision geoms enabled in MuJoCo physics (`contype="1" conaffinity="1"`).
- **Rear-Wing Corner-Cutting Prevention**: The bypass guidance corridor is maintained until $s_{\text{along}} > -0.45\text{ m}$, ensuring that the rear rotor blades (extending $0.34\text{ m}$ behind the drone center) completely fly past the obstacle before any turn towards the goal begins.
- **Speed-Regulated Smooth Evasion**: Forward speed dynamically adapts ($0.45\text{ m/s}$) during obstacle approach to give the yaw controller ample time to smoothly open up a wide $+33\text{ cm}$ visual safety buffer of clear air around the obstacle with zero contact events.

### E. Sensors & Visual Environment
- **LiDAR Sensors**: Strictly **2 pitch-stabilized forward LiDAR rangefinders** (offset $\pm 10^\circ$), rendering warm golden laser lights that turn red when obstacles enter safety zones.
- **Visuals**: Zero ground shadows (`castshadow="false"`), natural meadow grass earth, timber curbs, and rolling mountain horizon.

---

## 3. Quick Start (How to Run)

### Method 1: Double-Click
Simply double-click **`DOUBLE_CLICK_TO_RUN.bat`** in this folder!

### Method 2: Command Line
Open PowerShell or Command Prompt in this folder and run:
```powershell
python run_park_interactive.py
```

### Method 3: Run Automated Unit Tests (13 Tests)
Double-click **`RUN_UNIT_TESTS.bat`**, or run:
```powershell
python test_simulation.py
```
*(All 13 tests will run and report `OK` in under 9 seconds!)*

---

## 4. Suggested Demo Flow for Reviewers / Mam

1. **Step 1: Place 1 Start Point**:
   - Click anywhere on the map (e.g. `0.0, 0.0`). A White Helipad appears.
2. **Step 2: Place Multiple End Points**:
   - Click to add End Point 1 (e.g. `3.0, 1.0`).
   - Click to add End Point 2 (e.g. `6.5, -1.0`).
   - Click to add End Point 3 (e.g. `10.5, 0.0`).
   - Click **`[ ➔ Proceed to Step 3: Place Obstacles ]`**.
3. **Step 3: Place Obstacles**:
   - Click between the path segments to place slender 1-colour stick obstacles.
   - Click **`[ ➔ Proceed to Step 4: Speed & Run ]`**.
4. **Step 4: Select Speed & Launch**:
   - Choose or type your speed (e.g. `0.100 m/s`).
   - Click **`[ 🚀 RUN FLIGHT ]`**!
5. **Showcase Key Behaviors**:
   - Point out the vertical takeoff from ground ($z=0.072\text{m} \rightarrow 1.5\text{m}$).
   - Point out the 2 pitch-stabilized LiDAR beams evading obstacles.
   - Point out the drone descending to ground helipad #1, pausing, taking off again for helipad #2, descending, taking off for helipad #3!
   - Highlight the final landing on ground, motor shutoff (`ctrl[:] = 0.0`), and the audio voice announcing: **"Task finished"**!

---

## 5. Folder Contents & Architecture

| File / Folder | Purpose |
| :--- | :--- |
| **`DOUBLE_CLICK_TO_RUN.bat`** | 1-Click launcher for interactive mission commander |
| **`RUN_UNIT_TESTS.bat`** | 1-Click test runner verifying all 12 physics & neural unit tests |
| **`run_park_interactive.py`** | Main entry script launching GCS map and 3D simulation |
| **`test_simulation.py`** | 12 automated unit tests validating neural plasticity, passability, and multi-landings |
| **`src/park_mission_planner.py`** | Interactive Ground Control Station (GCS) GUI (Tkinter) |
| **`src/quadrotor_sim.py`** | MuJoCo quadrotor physics simulation engine & autopilot state machine |
| **`src/neural_controller.py`** | IEEE 8491889 Adaptive Neural Controller with online synaptic plasticity |
| **`src/telemetry_plotter.py`** | Telemetry recording and plotting utility |
| **`models/world_park_environment.xml`** | 3D MuJoCo scene: 0 shadows, white/red helipads pool, stick obstacles |
| **`results/`** | Pre-generated high-resolution telemetry graphs and validation plots |
| **`requirements.txt`** | Python dependencies (`mujoco`, `numpy`, `matplotlib`) |
