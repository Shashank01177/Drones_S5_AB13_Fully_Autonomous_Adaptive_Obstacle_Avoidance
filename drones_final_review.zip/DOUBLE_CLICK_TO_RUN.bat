@echo off
title Autonomous Drone Mission Commander (IEEE 8491889)
cd /d "%~dp0"
echo =====================================================================
echo  AUTONOMOUS DRONE NATURE MISSION COMMANDER (IEEE 8491889)
echo =====================================================================
echo  Starting interactive Ground Control Station and 3D MuJoCo Physics...
echo.
python run_park_interactive.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo An error occurred while running the simulation.
    pause
)
