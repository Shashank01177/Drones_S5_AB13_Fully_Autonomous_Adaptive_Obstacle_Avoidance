"""Unit tests for Scenario Library and Experiment Logger."""

import os
import json
import pytest
from simulation.scenarios import get_all_scenarios
from simulation.experiment_logger import ExperimentLogger, ExperimentTrialRecord


def test_scenario_library_completeness():
    """Verify all 13 scenarios are populated with valid obstacle definitions."""
    scenarios = get_all_scenarios()
    
    required_keys = [
        "front_obstacle",
        "right_obstacle",
        "left_obstacle",
        "rear_obstacle",
        "above_obstacle",
        "below_obstacle",
        "both_sides",
        "front_left",
        "front_right",
        "rear_diagonal",
        "multiple_obstacles",
        "paper_env2_maze",
        "clear_flight",
    ]

    for key in required_keys:
        assert key in scenarios, f"Missing scenario: {key}"
        sc = scenarios[key]
        assert sc.id == key
        assert len(sc.name) > 0
        assert len(sc.initial_drone_pos) == 3
        # Ensure obstacles serialize properly
        d = sc.to_dict()
        assert "obstacles" in d


def test_experiment_logger_csv_and_json(tmp_path):
    """Verify trial logging, metric computation, and CSV/JSON export."""
    log_dir = str(tmp_path / "logs")
    logger = ExperimentLogger(log_dir=log_dir)

    trial = ExperimentTrialRecord(
        trial_id="test_001",
        scenario_id="front_obstacle",
        scenario_name="Front Obstacle",
        timestamp=12.5,
        initial_pos=(0.0, -1.8, 1.0),
        trigger_sensor="lidar_left",
        trigger_distance_m=0.38,
        sensor_snapshot={"FORWARD": 0.38, "LEFT": 1.2, "RIGHT": 1.5},
        available_directions=["FORWARD", "LEFT", "RIGHT", "HOVER"],
        user_selected_direction="RIGHT",
        executed_maneuver="RIGHT",
        override_applied=False,
        final_pos=(0.8, -1.0, 1.0),
        has_collided=False,
        collision_object=None,
        response_time_sec=1.45,
        avoidance_duration_sec=3.2,
        min_clearance_m=0.35,
        result_status="SUCCESS",
    )

    logger.record_trial(trial)

    # Verify metrics
    metrics = logger.get_summary_metrics()
    assert metrics["total_trials"] == 1
    assert metrics["successful_avoidances"] == 1
    assert metrics["collisions"] == 0
    assert metrics["success_rate_percent"] == 100.0
    assert metrics["avg_response_time_sec"] == 1.45

    # Verify JSON export
    json_out = logger.export_json()
    parsed = json.loads(json_out)
    assert parsed["summary"]["total_trials"] == 1
    assert parsed["trials"][0]["trial_id"] == "test_001"

    # Verify CSV export
    csv_out = logger.export_csv()
    assert "test_001" in csv_out
    assert "front_obstacle" in csv_out
    assert "SUCCESS" in csv_out


def test_all_scenarios_autonomous_avoidance():
    """Programmatically steps through all 13 scenarios to ensure 0 collisions and clean avoidance."""
    from main import SimulationManager
    sim = SimulationManager()
    scenarios = list(sim.scenarios.keys())
    assert len(scenarios) == 13

    dt = 0.033
    for sc_id in scenarios:
        sim.load_scenario(sc_id)
        sim.start()
        for _ in range(120):
            sim.step(dt)
            if sim.physics.state.has_collided:
                break

        assert not sim.physics.state.has_collided, (
            f"Scenario '{sc_id}' suffered collision with '{sim.physics.state.collision_object_id}' "
            f"at pos ({sim.physics.state.x:.2f}, {sim.physics.state.y:.2f}, {sim.physics.state.z:.2f})"
        )
