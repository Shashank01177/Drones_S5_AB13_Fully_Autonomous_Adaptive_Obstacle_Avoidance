"""Unit tests for Quadcopter 6-DOF Physics and 3D Raycasting Sensor Suite."""

import math
import pytest
from sensors.lidar_sensor import (
    SensorSuite,
    CircleObstacle,
    BoxObstacle,
    MovingObstacle,
    ray_intersect_circle_2d,
    ray_intersect_box_2d,
)
from simulation.drone_physics import DronePhysics


def test_ray_circle_intersection():
    """Verify 2D ray intersection against circular pillar."""
    circle = CircleObstacle(id="c1", x=0.0, y=2.0, radius=0.5)

    # Ray from origin along +Y axis (towards center)
    hit = ray_intersect_circle_2d(0.0, 0.0, 0.0, 1.0, circle, max_dist=5.0)
    assert hit is not None
    # Distance should be 2.0 - 0.5 = 1.5m
    assert abs(hit - 1.5) < 1e-4

    # Ray pointing opposite (-Y)
    miss = ray_intersect_circle_2d(0.0, 0.0, 0.0, -1.0, circle, max_dist=5.0)
    assert miss is None


def test_ray_box_intersection():
    """Verify 2D ray intersection against oriented box."""
    box = BoxObstacle(id="b1", x=0.0, y=2.0, z=1.0, sx=1.0, sy=0.4, sz=2.0, yaw=0.0)

    # Ray from origin along +Y
    hit = ray_intersect_box_2d(0.0, 0.0, 0.0, 1.0, box, max_dist=5.0)
    assert hit is not None
    # Distance to box south face: 2.0 - 0.2 = 1.8m
    assert abs(hit - 1.8) < 1e-4


def test_quadcopter_translation():
    """Verify quadcopter moves in response to velocity commands."""
    physics = DronePhysics()
    physics.reset(0.0, 0.0, 1.0, yaw=math.radians(90))  # Facing +Y

    physics.set_directional_velocity("FORWARD", speed_scale=1.0)

    # Step physics for 0.5 seconds
    dt = 0.05
    for _ in range(10):
        physics.step(dt, obstacles=[])

    # Should have translated along +Y (forward relative to heading 90 deg)
    assert physics.state.y > 0.02


def test_collision_detection():
    """Verify collision flags when drone enters obstacle radius + Ld/2."""
    physics = DronePhysics(drone_width=0.34)  # radius = 0.17m
    physics.reset(0.0, 0.0, 1.0)

    # Place pillar within collision radius (0.17m + 0.25m = 0.42m)
    obstacle = CircleObstacle(id="colliding_pillar", x=0.0, y=0.30, radius=0.25, height=2.0)

    collided, obs_id = physics.check_collision([obstacle])
    assert collided
    assert obs_id == "colliding_pillar"
