"""Unit tests for the Adaptive Neural Controller and Decision Engine.

Validates the mathematical equations and logic from Devos et al. (2018)
and Pedersen & Manoonpong (2018).
"""

import math
import pytest
import numpy as np
from avoidance.neural_controller import AdaptiveNeuralController
from avoidance.decision_engine import DecisionEngine, FlightState, DirectionCategory
from sensors.lidar_sensor import RaycastResult


def test_lidar_normalization():
    """Verify distance normalization: 0.5m -> -1.0, 0.15m -> +1.0."""
    controller = AdaptiveNeuralController(lidar_min_range=0.15, lidar_max_range=0.50)
    
    assert controller.normalize_distance(0.55) == -1.0
    assert controller.normalize_distance(0.50) == -1.0
    assert controller.normalize_distance(0.15) == 1.0
    assert controller.normalize_distance(0.10) == 1.0

    # Midpoint: (0.50 + 0.15) / 2 = 0.325m -> 0.0
    mid_norm = controller.normalize_distance(0.325)
    assert abs(mid_norm - 0.0) < 1e-4


def test_neural_activation_bounds():
    """Verify discrete-time tanh neurons remain strictly bounded in (-1, 1)."""
    controller = AdaptiveNeuralController()
    
    for _ in range(50):
        yaw_rate, fwd_speed, telem = controller.step(0.20, 0.45, dt=0.033)
        assert -1.0 <= telem.o1 <= 1.0
        assert -1.0 <= telem.o2 <= 1.0
        assert 0.1 <= telem.b1 <= 8.0
        assert 0.1 <= telem.b2 <= 8.0
        assert 0.1 <= telem.q1 <= 10.0
        assert 0.1 <= telem.q2 <= 10.0


def test_steering_direction():
    """Verify obstacle on Left turns Right, obstacle on Right turns Left."""
    # Obstacle on Left (near=0.18m), Right clear (0.50m)
    controller_left = AdaptiveNeuralController()
    yaw_rate_l = 0.0
    for _ in range(5):
        yaw_rate_l, _, _ = controller_left.step(0.18, 0.50, dt=0.033)
    
    # In paper: positive yaw rate turns right to avoid left obstacle
    assert yaw_rate_l > 0.0

    # Obstacle on Right (near=0.18m), Left clear (0.50m)
    controller_right = AdaptiveNeuralController()
    yaw_rate_r = 0.0
    for _ in range(5):
        yaw_rate_r, _, _ = controller_right.step(0.50, 0.18, dt=0.033)
    
    # Negative yaw rate turns left to avoid right obstacle
    assert yaw_rate_r < 0.0


def test_synaptic_plasticity_adaptation():
    """Verify correlation plasticity adapts synaptic weights online."""
    controller = AdaptiveNeuralController()
    init_b = float(controller.b[0])
    init_q = float(controller.q[0])

    # Subject controller to persistent obstacle stimulus
    for _ in range(30):
        controller.step(0.22, 0.50, dt=0.033)

    # Weights must adapt (change from initial values)
    assert controller.b[0] != init_b or controller.q[0] != init_q


def test_decision_engine_hitl_workflow():
    """Verify Human-in-the-Loop workflow: detection pauses and holds for user when auto_avoid is off."""
    engine = DecisionEngine(detection_threshold=0.50, critical_turn_dist=0.23)
    engine.auto_avoid_safest_path = False
    engine.state = FlightState.CRUISING

    # Sensor mock with obstacle at 0.35m directly ahead
    mock_sensors = {
        "lidar_left": RaycastResult("lidar_left", 20.0, 0.35),
        "lidar_right": RaycastResult("lidar_right", -20.0, 0.40),
        "FORWARD": RaycastResult("FORWARD", 0.0, 0.35),
        "LEFT": RaycastResult("LEFT", 90.0, 1.8),
        "RIGHT": RaycastResult("RIGHT", -90.0, 2.0),
        "BACKWARD": RaycastResult("BACKWARD", 180.0, 2.5),
        "UP": RaycastResult("UP", 0.0, 1.5),
        "DOWN": RaycastResult("DOWN", 0.0, 1.0),
        "FORWARD_LEFT": RaycastResult("FORWARD_LEFT", 45.0, 0.8),
        "FORWARD_RIGHT": RaycastResult("FORWARD_RIGHT", -45.0, 0.9),
        "BACKWARD_LEFT": RaycastResult("BACKWARD_LEFT", 135.0, 2.0),
        "BACKWARD_RIGHT": RaycastResult("BACKWARD_RIGHT", -135.0, 2.0),
    }

    # 1. Detection trigger
    event = engine.check_detection_trigger(mock_sensors, (0, 0, 1), timestamp=1.0, paper_yaw_rate=0.5)
    assert event is not None
    assert engine.state == FlightState.WAITING_FOR_USER

    # 2. Blocked direction rejection
    mock_sensors["FORWARD"].distance = 0.18  # Less than critical distance 0.23m
    evals = engine.evaluate_all_directions(mock_sensors, paper_yaw_rate=0.5)
    engine.current_event.evaluations = evals

    accepted, msg, _ = engine.submit_user_decision("FORWARD", (0, 0, 1), timestamp=2.0)
    assert not accepted
    assert "REJECTED UNSAFE DIRECTION" in msg

    # 3. Override mode permits test
    engine.override_mode = True
    accepted_override, msg_override, _ = engine.submit_user_decision("FORWARD", (0, 0, 1), timestamp=2.1)
    assert accepted_override
    assert engine.state == FlightState.EXECUTING_AVOIDANCE


def test_decision_engine_auto_safest_avoidance():
    """Verify autonomous safest-path avoidance on obstacle detection without freezing."""
    engine = DecisionEngine(detection_threshold=0.50, critical_turn_dist=0.23)
    engine.auto_avoid_safest_path = True
    engine.state = FlightState.CRUISING

    mock_sensors = {
        "lidar_left": RaycastResult("lidar_left", 20.0, 0.35),
        "lidar_right": RaycastResult("lidar_right", -20.0, 0.40),
        "FORWARD": RaycastResult("FORWARD", 0.0, 0.35),
        "LEFT": RaycastResult("LEFT", 90.0, 1.8),
        "RIGHT": RaycastResult("RIGHT", -90.0, 2.5),
        "BACKWARD": RaycastResult("BACKWARD", 180.0, 2.5),
        "UP": RaycastResult("UP", 0.0, 1.5),
        "DOWN": RaycastResult("DOWN", 0.0, 1.0),
        "FORWARD_LEFT": RaycastResult("FORWARD_LEFT", 45.0, 0.8),
        "FORWARD_RIGHT": RaycastResult("FORWARD_RIGHT", -45.0, 1.5),
        "BACKWARD_LEFT": RaycastResult("BACKWARD_LEFT", 135.0, 2.0),
        "BACKWARD_RIGHT": RaycastResult("BACKWARD_RIGHT", -135.0, 2.0),
    }

    event = engine.check_detection_trigger(mock_sensors, (0, 0, 1), timestamp=1.0, paper_yaw_rate=0.5)
    assert event is not None
    assert engine.state == FlightState.EXECUTING_AVOIDANCE
    assert engine.active_maneuver in ("RIGHT", "FORWARD_RIGHT")

    # When drone completes evasive maneuver and clearance is restored
    completed = engine.update(dt=0.1, drone_pos=(0, 1.0, 1), min_current_dist=0.9, has_collided=False)
    assert completed is not None
    assert completed.outcome == "SUCCESS"
    assert engine.state == FlightState.CRUISING


def test_paper_equation_minimum_obstacle_width():
    """Verify Equation (1): W_obj >= 2 * tan(Theta/2) * (Lx + Ld/2)."""
    theta_deg = 40.0
    lx = 0.15  # 15 cm turning distance from paper
    ld = 0.34  # 34 cm drone width from paper

    half_theta_rad = math.radians(theta_deg / 2.0)  # 20 deg
    w_min = 2.0 * math.tan(half_theta_rad) * (lx + ld / 2.0)

    # 2 * tan(20 deg) * (0.15 + 0.17) = 2 * 0.36397 * 0.32 = 0.2329m ~ 24cm
    assert 0.23 <= w_min <= 0.24
    assert round(w_min * 100.0) == 23 or round(w_min * 100.0) == 24
