"""Scenario Library Package.

Exposes all 16 obstacle avoidance test scenarios and scenario definitions.
Includes JSON files for each scenario and Python dataclass definitions.
"""

from simulation.scenarios import (
    ScenarioDefinition,
    get_all_scenarios,
)

__all__ = ["ScenarioDefinition", "get_all_scenarios"]
