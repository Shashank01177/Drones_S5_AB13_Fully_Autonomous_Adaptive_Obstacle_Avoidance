"""LiDAR and Range Sensor Simulation.

Implements raycasting sensor models for:
1. Dual Front LiDARs at +/-20 deg (Theta = 40 deg, Garmin LIDAR-Lite v3 specification from Devos et al. 2018).
2. Omnidirectional 8-direction horizontal ring + vertical Up/Down sensors.
3. Realistic beam geometry, sensor saturation, and 3D ray-obstacle intersection.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Any, Union
import numpy as np


@dataclass
class CircleObstacle:
    """Cylinder/Pillar obstacle (circular cross-section in X-Y)."""
    id: str
    x: float
    y: float
    radius: float
    height: float = 2.0
    z_base: float = 0.0

    def contains_point(self, px: float, py: float, pz: float) -> bool:
        if not (self.z_base <= pz <= self.z_base + self.height):
            return False
        dx = px - self.x
        dy = py - self.y
        return (dx * dx + dy * dy) <= (self.radius * self.radius)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "cylinder",
            "id": self.id,
            "x": self.x,
            "y": self.y,
            "z": self.z_base + self.height / 2.0,
            "radius": self.radius,
            "height": self.height,
        }


@dataclass
class BoxObstacle:
    """Oriented 3D bounding box obstacle (walls, barriers, corridors, ceilings)."""
    id: str
    x: float
    y: float
    z: float
    sx: float  # Size along local X
    sy: float  # Size along local Y
    sz: float  # Size along local Z
    yaw: float = 0.0  # Rotation around Z axis (radians)

    def contains_point(self, px: float, py: float, pz: float) -> bool:
        if abs(pz - self.z) > self.sz / 2.0:
            return False
        # Transform to local frame
        c = math.cos(-self.yaw)
        s = math.sin(-self.yaw)
        dx = px - self.x
        dy = py - self.y
        lx = c * dx - s * dy
        ly = s * dx + c * dy
        return abs(lx) <= self.sx / 2.0 and abs(ly) <= self.sy / 2.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "box",
            "id": self.id,
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "sx": self.sx,
            "sy": self.sy,
            "sz": self.sz,
            "yaw": self.yaw,
        }


@dataclass
class MovingObstacle(BoxObstacle):
    """Dynamic obstacle oscillating back and forth."""
    vx: float = 0.3
    vy: float = 0.0
    x_min: float = -2.0
    x_max: float = 2.0
    direction: float = 1.0

    def update(self, dt: float) -> None:
        self.x += self.direction * self.vx * dt
        if self.x > self.x_max:
            self.x = self.x_max
            self.direction = -1.0
        elif self.x < self.x_min:
            self.x = self.x_min
            self.direction = 1.0

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d["type"] = "moving_box"
        return d


ObstacleType = Union[CircleObstacle, BoxObstacle, MovingObstacle]


def ray_intersect_circle_2d(
    ox: float, oy: float, dx: float, dy: float, circle: CircleObstacle, max_dist: float
) -> Optional[float]:
    """2D Ray-circle intersection test."""
    cx = ox - circle.x
    cy = oy - circle.y
    b = 2.0 * (cx * dx + cy * dy)
    c = cx * cx + cy * cy - circle.radius * circle.radius
    disc = b * b - 4.0 * c
    if disc < 0:
        return None
    sqrt_disc = math.sqrt(disc)
    t1 = (-b - sqrt_disc) / 2.0
    t2 = (-b + sqrt_disc) / 2.0
    hits = [t for t in (t1, t2) if 0.0 <= t <= max_dist]
    return min(hits) if hits else None


def ray_intersect_box_2d(
    ox: float, oy: float, dx: float, dy: float, box: BoxObstacle, max_dist: float
) -> Optional[float]:
    """Ray-oriented box intersection in X-Y plane."""
    c = math.cos(-box.yaw)
    s = math.sin(-box.yaw)
    rox = c * (ox - box.x) - s * (oy - box.y)
    roy = s * (ox - box.x) + c * (oy - box.y)
    rdx = c * dx - s * dy
    rdy = s * dx + c * dy

    half_x = box.sx / 2.0
    half_y = box.sy / 2.0
    tmin, tmax = 0.0, max_dist

    # Check X slab
    if abs(rdx) < 1e-9:
        if abs(rox) > half_x:
            return None
    else:
        inv = 1.0 / rdx
        t1 = (-half_x - rox) * inv
        t2 = (half_x - rox) * inv
        tmin = max(tmin, min(t1, t2))
        tmax = min(tmax, max(t1, t2))
        if tmin > tmax:
            return None

    # Check Y slab
    if abs(rdy) < 1e-9:
        if abs(roy) > half_y:
            return None
    else:
        inv = 1.0 / rdy
        t1 = (-half_y - roy) * inv
        t2 = (half_y - roy) * inv
        tmin = max(tmin, min(t1, t2))
        tmax = min(tmax, max(t1, t2))
        if tmin > tmax:
            return None

    return tmin if 0.0 <= tmin <= max_dist else None


def ray_intersect_arena_walls(
    ox: float, oy: float, dx: float, dy: float, arena_size: float, max_dist: float
) -> Optional[float]:
    """Intersection against enclosing boundary walls [-size/2, +size/2]."""
    half = arena_size / 2.0
    hits: List[float] = []

    # X walls (ox + t*dx = +/-half)
    if abs(dx) > 1e-9:
        for wall_x in (-half, half):
            t = (wall_x - ox) / dx
            if 0.0 <= t <= max_dist:
                y_hit = oy + t * dy
                if -half <= y_hit <= half:
                    hits.append(t)

    # Y walls (oy + t*dy = +/-half)
    if abs(dy) > 1e-9:
        for wall_y in (-half, half):
            t = (wall_y - oy) / dy
            if 0.0 <= t <= max_dist:
                x_hit = ox + t * dx
                if -half <= x_hit <= half:
                    hits.append(t)

    return min(hits) if hits else None


@dataclass
class RaycastResult:
    """Result of a directional sensor raycast."""
    direction_name: str
    relative_angle_deg: float
    distance: float
    hit_point: Optional[Tuple[float, float, float]] = None
    obstacle_id: Optional[str] = None
    is_saturated: bool = False


class SensorSuite:
    """Manages dual front LiDARs and full 3D spatial awareness suite."""

    def __init__(
        self,
        drone_radius: float = 0.17,  # Ld / 2 (Ld = 0.34m from paper)
        paper_theta_deg: float = 40.0,  # 40 deg total angle (+/- 20 deg)
        max_lidar_range: float = 2.0,   # Sensor hardware max range (paper triggers avoidance at <= 0.50m)
        max_aux_range: float = 3.0,     # 3.0 m max range for situational awareness
        arena_size: float = 10.0,
    ) -> None:
        self.drone_radius = drone_radius
        self.paper_theta_deg = paper_theta_deg
        self.max_lidar_range = max_lidar_range
        self.max_aux_range = max_aux_range
        self.arena_size = arena_size

    def cast_horizontal_ray(
        self,
        drone_x: float,
        drone_y: float,
        drone_z: float,
        angle_rad: float,
        max_range: float,
        obstacles: List[ObstacleType],
        origin_offset: float = 0.17,
    ) -> Tuple[float, Optional[Tuple[float, float, float]], Optional[str]]:
        """Casts a ray along angle_rad in X-Y plane at drone_z height."""
        dx = math.cos(angle_rad)
        dy = math.sin(angle_rad)
        ox = drone_x + dx * origin_offset
        oy = drone_y + dy * origin_offset

        closest_dist = max_range
        hit_pt: Optional[Tuple[float, float, float]] = None
        hit_id: Optional[str] = None

        # Check arena boundary
        wall_hit = ray_intersect_arena_walls(ox, oy, dx, dy, self.arena_size, max_range)
        if wall_hit is not None and wall_hit < closest_dist:
            closest_dist = wall_hit
            hit_pt = (ox + dx * wall_hit, oy + dy * wall_hit, drone_z)
            hit_id = "boundary_wall"

        # Check obstacles
        for obs in obstacles:
            if isinstance(obs, CircleObstacle):
                # Check Z overlap
                if not (obs.z_base <= drone_z <= obs.z_base + obs.height):
                    continue
                hit = ray_intersect_circle_2d(ox, oy, dx, dy, obs, closest_dist)
                if hit is not None and hit < closest_dist:
                    closest_dist = hit
                    hit_pt = (ox + dx * hit, oy + dy * hit, drone_z)
                    hit_id = obs.id
            elif isinstance(obs, (BoxObstacle, MovingObstacle)):
                if abs(drone_z - obs.z) > obs.sz / 2.0:
                    continue
                hit = ray_intersect_box_2d(ox, oy, dx, dy, obs, closest_dist)
                if hit is not None and hit < closest_dist:
                    closest_dist = hit
                    hit_pt = (ox + dx * hit, oy + dy * hit, drone_z)
                    hit_id = obs.id

        return closest_dist, hit_pt, hit_id

    def cast_vertical_ray(
        self,
        drone_x: float,
        drone_y: float,
        drone_z: float,
        direction_sign: float,  # +1.0 for UP, -1.0 for DOWN
        max_range: float,
        obstacles: List[ObstacleType],
    ) -> Tuple[float, Optional[Tuple[float, float, float]], Optional[str]]:
        """Casts vertical ray along Z axis."""
        closest_dist = max_range
        hit_pt: Optional[Tuple[float, float, float]] = None
        hit_id: Optional[str] = None

        # Ground plane at Z = 0
        if direction_sign < 0:
            ground_dist = drone_z
            if 0.0 <= ground_dist < closest_dist:
                closest_dist = ground_dist
                hit_pt = (drone_x, drone_y, 0.0)
                hit_id = "ground"

        # Ceiling at Z = 4.0
        ceiling_z = 4.0
        if direction_sign > 0:
            ceil_dist = ceiling_z - drone_z
            if 0.0 <= ceil_dist < closest_dist:
                closest_dist = ceil_dist
                hit_pt = (drone_x, drone_y, ceiling_z)
                hit_id = "ceiling"

        # Obstacle check
        for obs in obstacles:
            if obs.contains_point(drone_x, drone_y, drone_z):
                return 0.0, (drone_x, drone_y, drone_z), obs.id

            if isinstance(obs, BoxObstacle):
                # If within X-Y footprint
                c = math.cos(-obs.yaw)
                s = math.sin(-obs.yaw)
                dx = drone_x - obs.x
                dy = drone_y - obs.y
                lx = c * dx - s * dy
                ly = s * dx + c * dy
                if abs(lx) <= obs.sx / 2.0 and abs(ly) <= obs.sy / 2.0:
                    top_z = obs.z + obs.sz / 2.0
                    bot_z = obs.z - obs.sz / 2.0
                    if direction_sign > 0 and bot_z >= drone_z:
                        dist = bot_z - drone_z
                        if dist < closest_dist:
                            closest_dist = dist
                            hit_pt = (drone_x, drone_y, bot_z)
                            hit_id = obs.id
                    elif direction_sign < 0 and top_z <= drone_z:
                        dist = drone_z - top_z
                        if dist < closest_dist:
                            closest_dist = dist
                            hit_pt = (drone_x, drone_y, top_z)
                            hit_id = obs.id

        return closest_dist, hit_pt, hit_id

    def read_all(
        self,
        drone_x: float,
        drone_y: float,
        drone_z: float,
        drone_yaw: float,
        obstacles: List[ObstacleType],
    ) -> Dict[str, RaycastResult]:
        """Samples all sensors: Paper dual LiDARs + omnidirectional 3D suite."""
        results: Dict[str, RaycastResult] = {}

        # 1. Base Paper Dual LiDARs at +/-20 degrees (+/- Theta/2)
        half_theta = math.radians(self.paper_theta_deg / 2.0)  # 20 deg
        left_angle = drone_yaw + half_theta   # +20 deg (Left LiDAR beam)
        right_angle = drone_yaw - half_theta  # -20 deg (Right LiDAR beam)

        d_left, pt_l, id_l = self.cast_horizontal_ray(
            drone_x, drone_y, drone_z, left_angle, self.max_lidar_range, obstacles, self.drone_radius
        )
        d_right, pt_r, id_r = self.cast_horizontal_ray(
            drone_x, drone_y, drone_z, right_angle, self.max_lidar_range, obstacles, self.drone_radius
        )

        results["lidar_left"] = RaycastResult("lidar_left", +20.0, d_left, pt_l, id_l, d_left >= self.max_lidar_range)
        results["lidar_right"] = RaycastResult("lidar_right", -20.0, d_right, pt_r, id_r, d_right >= self.max_lidar_range)

        # 2. Omnidirectional horizontal radial ring (8 directions)
        directions = [
            ("FORWARD", 0.0),
            ("FORWARD_RIGHT", -45.0),
            ("RIGHT", -90.0),
            ("BACKWARD_RIGHT", -135.0),
            ("BACKWARD", 180.0),
            ("BACKWARD_LEFT", 135.0),
            ("LEFT", 90.0),
            ("FORWARD_LEFT", 45.0),
        ]

        for name, deg_offset in directions:
            ang = drone_yaw + math.radians(deg_offset)
            dist, pt, oid = self.cast_horizontal_ray(
                drone_x, drone_y, drone_z, ang, self.max_aux_range, obstacles, self.drone_radius
            )
            results[name] = RaycastResult(name, deg_offset, dist, pt, oid, dist >= self.max_aux_range)

        # 3. Vertical Sensors (UP / DOWN)
        d_up, pt_up, id_up = self.cast_vertical_ray(
            drone_x, drone_y, drone_z, +1.0, self.max_aux_range, obstacles
        )
        d_down, pt_down, id_down = self.cast_vertical_ray(
            drone_x, drone_y, drone_z, -1.0, self.max_aux_range, obstacles
        )

        results["UP"] = RaycastResult("UP", 0.0, d_up, pt_up, id_up, d_up >= self.max_aux_range)
        results["DOWN"] = RaycastResult("DOWN", 0.0, d_down, pt_down, id_down, d_down >= self.max_aux_range)

        return results
