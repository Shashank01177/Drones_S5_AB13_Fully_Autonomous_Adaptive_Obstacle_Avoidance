"""Human-in-the-Loop Decision and Safety Engine.

Enforces the user-driven obstacle avoidance workflow:
1. Pauses autonomous progression when an obstacle is detected within threshold.
2. Holds quadcopter in a safe hover state.
3. Evaluates all candidate directions against base paper clearance constraints:
   - W_obj >= 2 tan(Theta / 2) (Lx + Ld / 2)
   - Minimum clearance = Lm + Ld / 2 = 0.06 + 0.17 = 0.23 m
4. Validates user choice (Safe vs Unsafe with detailed hazard reasoning).
5. Provides research override mode for testing collisions.
6. Enforces configurable timeout with safe hover behavior.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, Any, List, Optional, Tuple
from sensors.lidar_sensor import RaycastResult


class FlightState(str, Enum):
    IDLE = "IDLE"
    CRUISING = "CRUISING"
    MANUAL_PILOT = "MANUAL_PILOT"
    OBSTACLE_DETECTED = "OBSTACLE_DETECTED"
    WAITING_FOR_USER = "WAITING_FOR_USER"
    EXECUTING_AVOIDANCE = "EXECUTING_AVOIDANCE"
    MANEUVER_COMPLETE = "MANEUVER_COMPLETE"
    COLLISION = "COLLISION"
    HOLD_POSITION = "HOLD_POSITION"
    EMERGENCY_STOPPED = "EMERGENCY_STOPPED"
    TIMEOUT_HOVER = "TIMEOUT_HOVER"


class DirectionCategory(str, Enum):
    RECOMMENDED = "RECOMMENDED"
    SAFE = "SAFE"
    CAUTION = "CAUTION"
    BLOCKED = "BLOCKED"


@dataclass
class DirectionEvaluation:
    name: str
    status: DirectionCategory
    distance: float
    clearance_margin: float
    reason: str
    is_paper_optimal: bool = False
    keyboard_key: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status.value,
            "distance": round(float(self.distance), 3),
            "clearance_margin": round(float(self.clearance_margin), 3),
            "reason": self.reason,
            "is_paper_optimal": bool(self.is_paper_optimal),
            "keyboard_key": self.keyboard_key,
        }


@dataclass
class AvoidanceDecisionEvent:
    event_id: str
    timestamp: float
    trigger_sensor: str
    trigger_distance: float
    drone_position: Tuple[float, float, float]
    evaluations: Dict[str, DirectionEvaluation]
    user_choice: Optional[str] = None
    override_applied: bool = False
    outcome: Optional[str] = None  # SUCCESS, COLLISION, TIMEOUT
    response_time_sec: float = 0.0
    avoidance_duration_sec: float = 0.0
    min_clearance_observed: float = 0.0


class DecisionEngine:
    """Evaluates flight safety and orchestrates human-in-the-loop avoidance."""

    def __init__(
        self,
        drone_width: float = 0.34,       # Ld from paper (34 cm)
        safety_margin: float = 0.06,     # Lm from paper (6 cm)
        detection_threshold: float = 0.50, # Ls from paper (50 cm)
        critical_turn_dist: float = 0.23,  # Turning distance + half width (15 cm + 17 cm = 32 cm or 23 cm radius)
        decision_timeout_sec: float = 15.0,
    ) -> None:
        self.drone_width = drone_width
        self.safety_margin = safety_margin
        self.detection_threshold = detection_threshold
        self.critical_dist = critical_turn_dist
        self.decision_timeout_sec = decision_timeout_sec

        self.state: FlightState = FlightState.IDLE
        self.override_mode: bool = False  # Allows testing unsafe choices deliberately
        self.auto_avoid_safest_path: bool = True  # Automatically executes safest avoidance path on obstacle detection

        self.current_event: Optional[AvoidanceDecisionEvent] = None
        self.wait_timer: float = 0.0
        self.active_maneuver: Optional[str] = None
        self.maneuver_progress: float = 0.0
        self.maneuver_target_distance: float = 0.55  # Distance traveled along evasion path before resuming cruise
        self.maneuver_start_pos: Tuple[float, float, float] = (0.0, 0.0, 0.0)

        # Minimum clearance recorded during active maneuver
        self.min_clearance_tracker: float = 999.0
        self.cooldown_timer: float = 0.0
        self.last_pos: Tuple[float, float, float] = (0.0, 0.0, 0.0)
        self.maneuver_time: float = 0.0

    def get_safest_direction(
        self,
        evals: Dict[str, DirectionEvaluation],
        trigger_sensor: str = "FORWARD",
    ) -> str:
        """Determines the safest path with maximum clearance margin, threat-aware."""
        # 1. Threat-specific candidate order
        if trigger_sensor == "UP":
            # Overhead threat -> descend DOWN if ground clearance allows
            if "DOWN" in evals and evals["DOWN"].distance >= self.critical_dist:
                return "DOWN"
            candidates = ["RIGHT", "LEFT", "FORWARD_RIGHT", "FORWARD_LEFT", "BACKWARD"]
        elif trigger_sensor == "DOWN":
            # Ground/platform threat -> climb UP if ceiling clearance allows
            if "UP" in evals and evals["UP"].distance >= self.critical_dist:
                return "UP"
            candidates = ["FORWARD", "RIGHT", "LEFT", "FORWARD_RIGHT", "FORWARD_LEFT"]
        elif trigger_sensor in ("BACKWARD", "BACKWARD_LEFT", "BACKWARD_RIGHT"):
            # Rear threat -> fly FORWARD away from hazard
            if "FORWARD" in evals and evals["FORWARD"].distance >= self.critical_dist:
                return "FORWARD"
            candidates = ["UP", "FORWARD_RIGHT", "FORWARD_LEFT", "RIGHT", "LEFT"]
        elif trigger_sensor in ("RIGHT", "FORWARD_RIGHT", "lidar_right"):
            # Threat on right -> evade to the LEFT
            candidates = ["LEFT", "FORWARD_LEFT", "UP", "FORWARD", "BACKWARD_LEFT"]
        elif trigger_sensor in ("LEFT", "FORWARD_LEFT", "lidar_left"):
            # Threat on left -> evade to the RIGHT
            candidates = ["RIGHT", "FORWARD_RIGHT", "UP", "FORWARD", "BACKWARD_RIGHT"]
        elif trigger_sensor == "both_sides":
            # Flanked on both sides -> proceed straight FORWARD through gap
            return "FORWARD"
        elif trigger_sensor == "corridor_dead_end":
            # Dead end ahead in narrow corridor -> reverse straight BACKWARD
            return "BACKWARD"
        else:
            # Frontal threat: evaluate all lateral and vertical escape vectors
            candidates = ["RIGHT", "LEFT", "FORWARD_RIGHT", "FORWARD_LEFT", "UP", "BACKWARD"]

        # Filter out BLOCKED directions
        valid_candidates = [c for c in candidates if c in evals and evals[c].status != DirectionCategory.BLOCKED]
        if not valid_candidates:
            valid_candidates = [c for c in candidates if c in evals]

        # Select candidate with MAXIMUM clearance distance
        best_dir = valid_candidates[0]
        max_dist = -1.0

        for c in valid_candidates:
            dist = evals[c].distance
            if dist > max_dist:
                max_dist = dist
                best_dir = c

        return best_dir

    def evaluate_all_directions(
        self,
        sensor_readings: Dict[str, RaycastResult],
        paper_yaw_rate: float,
        trigger_sensor: Optional[str] = None,
    ) -> Dict[str, DirectionEvaluation]:
        """Evaluates clearance and safety for each of the 10 directional options."""
        evals: Dict[str, DirectionEvaluation] = {}

        # Direction key mappings
        key_map = {
            "FORWARD": "W",
            "BACKWARD": "S",
            "LEFT": "A",
            "RIGHT": "D",
            "UP": "R",
            "DOWN": "F",
            "FORWARD_LEFT": "Q",
            "FORWARD_RIGHT": "E",
            "BACKWARD_LEFT": "Z",
            "BACKWARD_RIGHT": "C",
            "HOVER": "SPACE",
            "STOP": "ESC",
        }

        # Threat-aware recommended direction
        d_l = sensor_readings.get("lidar_left", RaycastResult("", 0, 99)).distance
        d_r = sensor_readings.get("lidar_right", RaycastResult("", 0, 99)).distance
        d_left_side = sensor_readings.get("LEFT", RaycastResult("", 0, 99)).distance
        d_right_side = sensor_readings.get("RIGHT", RaycastResult("", 0, 99)).distance

        if trigger_sensor == "UP":
            paper_recommended_dir = "DOWN"
        elif trigger_sensor == "DOWN":
            paper_recommended_dir = "UP"
        elif trigger_sensor in ("BACKWARD", "BACKWARD_LEFT", "BACKWARD_RIGHT"):
            paper_recommended_dir = "FORWARD"
        elif trigger_sensor in ("RIGHT", "FORWARD_RIGHT"):
            paper_recommended_dir = "LEFT"
        elif trigger_sensor in ("LEFT", "FORWARD_LEFT"):
            paper_recommended_dir = "RIGHT"
        elif trigger_sensor == "both_sides":
            paper_recommended_dir = "FORWARD"
        elif trigger_sensor == "corridor_dead_end":
            paper_recommended_dir = "BACKWARD"
        elif paper_yaw_rate > 0.05:
            paper_recommended_dir = "RIGHT"
        elif paper_yaw_rate < -0.05:
            paper_recommended_dir = "LEFT"
        elif d_l < d_r:
            paper_recommended_dir = "RIGHT"
        elif d_r < d_l:
            paper_recommended_dir = "LEFT"
        elif d_right_side >= d_left_side:
            paper_recommended_dir = "RIGHT"
        else:
            paper_recommended_dir = "LEFT"

        # Safe clearance threshold: Ld/2 + Lm = 0.17 + 0.06 = 0.23m
        min_safe = self.critical_dist
        caution_thresh = 0.50

        for name, key in key_map.items():
            if name in ("HOVER", "STOP"):
                evals[name] = DirectionEvaluation(
                    name=name,
                    status=DirectionCategory.SAFE,
                    distance=99.0,
                    clearance_margin=99.0,
                    reason="Maintains stable stationary hover in place.",
                    is_paper_optimal=False,
                    keyboard_key=key,
                )
                continue

            reading = sensor_readings.get(name)
            dist = reading.distance if reading is not None else 3.0
            margin = dist - min_safe

            if dist < min_safe:
                status = DirectionCategory.BLOCKED
                reason = f"Obstacle directly blocking path at {dist:.2f}m (less than critical clearance {min_safe:.2f}m)."
            elif dist < caution_thresh:
                status = DirectionCategory.CAUTION
                reason = f"Marginal clearance at {dist:.2f}m (caution: narrow passage or nearby barrier)."
            else:
                status = DirectionCategory.SAFE
                reason = f"Clear path ahead ({dist:.2f}m clearance available)."

            is_optimal = (name == paper_recommended_dir) and (status in (DirectionCategory.SAFE, DirectionCategory.CAUTION))
            if is_optimal:
                status = DirectionCategory.RECOMMENDED
                reason = f"OPTIMAL: Recommended by base-paper adaptive neural controller ({dist:.2f}m clearance)."

            evals[name] = DirectionEvaluation(
                name=name,
                status=status,
                distance=dist,
                clearance_margin=margin,
                reason=reason,
                is_paper_optimal=is_optimal,
                keyboard_key=key,
            )

        return evals

    def check_detection_trigger(
        self,
        sensor_readings: Dict[str, RaycastResult],
        drone_pos: Tuple[float, float, float],
        timestamp: float,
        paper_yaw_rate: float,
    ) -> Optional[AvoidanceDecisionEvent]:
        """Detects if an obstacle is within threshold across any sensor and initiates avoidance."""
        if self.state not in (FlightState.CRUISING, FlightState.IDLE):
            return None

        if self.cooldown_timer > 0.0:
            return None

        # Check all 3D spatial sectors with appropriate distance thresholds
        # 1. Front cone (detection threshold = 0.50m from paper)
        front_sensors = ["lidar_left", "lidar_right", "FORWARD", "FORWARD_LEFT", "FORWARD_RIGHT"]
        # 2. Vertical sensors (overhead beam / low floor)
        vertical_sensors = ["UP", "DOWN"]
        # 3. Flank and rear sensors (lateral / reverse threats)
        flank_sensors = ["LEFT", "RIGHT", "BACKWARD", "BACKWARD_LEFT", "BACKWARD_RIGHT"]

        threats: List[Tuple[float, str]] = []

        # Check bilateral flank pinch (corridor or both sides flanked)
        d_left = sensor_readings.get("LEFT", RaycastResult("", 0, 99)).distance
        d_right = sensor_readings.get("RIGHT", RaycastResult("", 0, 99)).distance
        d_fwd = sensor_readings.get("FORWARD", RaycastResult("", 0, 99)).distance

        bilateral_flanked = (d_left <= 0.38 and d_right <= 0.38)
        if bilateral_flanked:
            if d_fwd <= self.detection_threshold:
                # Dead end reached in corridor!
                threats.append((min(d_fwd, d_left, d_right) - 0.1, "corridor_dead_end"))
            else:
                # Flanked on both sides while cruising forward
                threats.append((min(d_left, d_right) - 0.05, "both_sides"))

        # Check front cone (skip front cone if dead end already captured)
        if not (bilateral_flanked and d_fwd <= self.detection_threshold):
            for sname in front_sensors:
                reading = sensor_readings.get(sname)
                if reading is not None and reading.distance <= self.detection_threshold:
                    threats.append((reading.distance, sname))

        # Check vertical sensors
        for sname in vertical_sensors:
            reading = sensor_readings.get(sname)
            if reading is not None and reading.distance <= 0.42:
                threats.append((reading.distance, sname))

        # Check flank and rear sensors (skip LEFT and RIGHT if bilateral flanked)
        for sname in flank_sensors:
            if bilateral_flanked and sname in ("LEFT", "RIGHT"):
                continue
            reading = sensor_readings.get(sname)
            if reading is not None and reading.distance <= 0.35:
                threats.append((reading.distance, sname))

        if not threats:
            return None

        # Sort by proximity to find primary threat
        threats.sort(key=lambda t: t[0])
        min_dist, trigger_sensor = threats[0]

        evals = self.evaluate_all_directions(sensor_readings, paper_yaw_rate, trigger_sensor)
        safest_dir = self.get_safest_direction(evals, trigger_sensor)

        event = AvoidanceDecisionEvent(
            event_id=f"evt_{int(timestamp * 1000)}",
            timestamp=timestamp,
            trigger_sensor=trigger_sensor,
            trigger_distance=min_dist,
            drone_position=drone_pos,
            evaluations=evals,
            user_choice=safest_dir,
        )

        self.current_event = event
        self.min_clearance_tracker = min_dist

        if self.auto_avoid_safest_path:
            self.active_maneuver = safest_dir
            self.maneuver_progress = 0.0
            self.maneuver_time = 0.0
            self.maneuver_start_pos = drone_pos
            self.last_pos = drone_pos
            self.maneuver_target_distance = 0.40
            self.state = FlightState.EXECUTING_AVOIDANCE
        else:
            self.state = FlightState.WAITING_FOR_USER
            self.wait_timer = 0.0

        return event

    def submit_user_decision(
        self,
        direction: str,
        drone_pos: Tuple[float, float, float],
        timestamp: float,
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """Processes user direction choice.

        Returns:
            Tuple of (accepted, status_message, event_details)
        """
        if self.state != FlightState.WAITING_FOR_USER or self.current_event is None:
            return False, "Drone is not currently waiting for an avoidance decision.", {}

        eval_info = self.current_event.evaluations.get(direction)
        if eval_info is None:
            return False, f"Unknown direction '{direction}'.", {}

        self.current_event.user_choice = direction
        self.current_event.response_time_sec = round(timestamp - self.current_event.timestamp, 3)

        if direction in ("HOVER", "STOP"):
            self.state = FlightState.HOLD_POSITION if direction == "HOVER" else FlightState.EMERGENCY_STOPPED
            self.current_event.outcome = "HELD"
            return True, f"Drone commanded to {direction}.", self.current_event.evaluations[direction].to_dict()

        # Check safety vs override mode
        if eval_info.status == DirectionCategory.BLOCKED and not self.override_mode:
            return (
                False,
                f"REJECTED UNSAFE DIRECTION '{direction}': {eval_info.reason}. "
                f"Please select a SAFE/RECOMMENDED direction or enable 'Override Unsafe' for crash testing.",
                {"reason": eval_info.reason, "suggested": [k for k, v in self.current_event.evaluations.items() if v.status in (DirectionCategory.RECOMMENDED, DirectionCategory.SAFE)]},
            )

        # Approved or overridden
        self.current_event.override_applied = self.override_mode and (eval_info.status == DirectionCategory.BLOCKED)
        self.active_maneuver = direction
        self.maneuver_progress = 0.0
        self.maneuver_time = 0.0
        self.maneuver_start_pos = drone_pos
        self.last_pos = drone_pos
        self.maneuver_target_distance = 0.40
        self.state = FlightState.EXECUTING_AVOIDANCE

        msg = f"Executing {direction} avoidance maneuver"
        if self.current_event.override_applied:
            msg += " [OVERRIDE ACTIVE - WARNING: COLLISION HAZARD]"

        return True, msg, eval_info.to_dict()

    def update(
        self,
        dt: float,
        drone_pos: Tuple[float, float, float],
        min_current_dist: float,
        has_collided: bool,
    ) -> Optional[AvoidanceDecisionEvent]:
        """Steps state machine logic each frame."""
        self.min_clearance_tracker = min(self.min_clearance_tracker, min_current_dist)
        if self.cooldown_timer > 0.0:
            self.cooldown_timer = max(0.0, self.cooldown_timer - dt)

        # Collision check
        if has_collided:
            self.state = FlightState.COLLISION
            if self.current_event is not None and self.current_event.outcome is None:
                self.current_event.outcome = "COLLISION"
                self.current_event.min_clearance_observed = 0.0
                evt = self.current_event
                self.current_event = None
                return evt
            return None

        # Timeout check during WAITING_FOR_USER
        if self.state == FlightState.WAITING_FOR_USER:
            self.wait_timer += dt
            if self.wait_timer >= self.decision_timeout_sec:
                self.state = FlightState.TIMEOUT_HOVER
                if self.current_event is not None:
                    self.current_event.outcome = "TIMEOUT"
                    self.current_event.user_choice = "TIMEOUT_HOVER"
                    self.current_event.response_time_sec = self.decision_timeout_sec
                    self.current_event.min_clearance_observed = self.min_clearance_tracker
                    evt = self.current_event
                    self.current_event = None
                    return evt

        # Progress active avoidance maneuver
        if self.state == FlightState.EXECUTING_AVOIDANCE and self.active_maneuver is not None:
            # Measure accumulated travel distance and elapsed avoidance time
            dx = drone_pos[0] - self.last_pos[0]
            dy = drone_pos[1] - self.last_pos[1]
            dz = drone_pos[2] - self.last_pos[2]
            step_dist = math.sqrt(dx * dx + dy * dy + dz * dz)
            self.maneuver_progress += step_dist
            self.maneuver_time += dt
            self.last_pos = drone_pos

            # Completion conditions:
            # 1. Traveled target distance (0.40m)
            # 2. Obstacle clearance achieved (min_current_dist >= detection_threshold + 0.15m)
            # 3. Maximum maneuver duration elapsed (2.0 seconds)
            if (
                self.maneuver_progress >= self.maneuver_target_distance
                or min_current_dist >= self.detection_threshold + 0.15
                or self.maneuver_time >= 2.0
            ):
                self.state = FlightState.CRUISING
                self.cooldown_timer = 0.8  # Hysteresis cooldown before next trigger
                if self.current_event is not None:
                    self.current_event.outcome = "SUCCESS"
                    self.current_event.avoidance_duration_sec = self.maneuver_time
                    self.current_event.min_clearance_observed = self.min_clearance_tracker
                    evt = self.current_event
                    self.current_event = None
                    self.active_maneuver = None
                    return evt

        return None

    def reset(self) -> None:
        self.state = FlightState.IDLE
        self.current_event = None
        self.wait_timer = 0.0
        self.active_maneuver = None
        self.maneuver_progress = 0.0
        self.maneuver_time = 0.0
        self.min_clearance_tracker = 999.0
        self.cooldown_timer = 0.0
        self.last_pos = (0.0, 0.0, 0.0)
