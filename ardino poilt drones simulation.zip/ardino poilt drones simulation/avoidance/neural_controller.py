"""Adaptive Neural Obstacle Avoidance Controller.

Faithfully implements the two-neuron recurrent neural network (RNN)
with correlation plasticity and short-term memory as described in:
- Devos, Ebeid, and Manoonpong (2018), "Development of Autonomous Drones for Adaptive
  Obstacle Avoidance in Real World Environments", IEEE DSD 2018.
- Pedersen and Manoonpong (2018), "Neural Control and Synaptic Plasticity for
  Adaptive Obstacle Avoidance of Autonomous Drones", LNAI.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Any, Tuple
import numpy as np


@dataclass
class NeuralTelemetry:
    """Telemetry data from the neural network controller."""
    o1: float = -1.0
    o2: float = -1.0
    o1_prev: float = -1.0
    o2_prev: float = -1.0
    b1: float = 2.4
    b2: float = 2.4
    q1: float = 3.5
    q2: float = 3.5
    c: float = -3.5
    s_left: float = -1.0
    s_right: float = -1.0
    raw_dist_left: float = 0.5
    raw_dist_right: float = 0.5
    steering: float = 0.0
    yaw_rate: float = 0.0
    forward_speed: float = 0.1
    plasticity_active: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "o1": round(float(self.o1), 4),
            "o2": round(float(self.o2), 4),
            "b1": round(float(self.b1), 4),
            "b2": round(float(self.b2), 4),
            "q1": round(float(self.q1), 4),
            "q2": round(float(self.q2), 4),
            "c": round(float(self.c), 4),
            "s_left": round(float(self.s_left), 4),
            "s_right": round(float(self.s_right), 4),
            "raw_dist_left": round(float(self.raw_dist_left), 4),
            "raw_dist_right": round(float(self.raw_dist_right), 4),
            "steering": round(float(self.steering), 4),
            "yaw_rate": round(float(self.yaw_rate), 4),
            "forward_speed": round(float(self.forward_speed), 4),
            "plasticity_active": bool(self.plasticity_active),
        }


class AdaptiveNeuralController:
    """Two-neuron recurrent controller with correlation-based plasticity.

    Neuron 1 (Left): Receives left LiDAR signal S_L.
    Neuron 2 (Right): Receives right LiDAR signal S_R.
    Self-excitatory weights b1, b2 provide short-term memory.
    Cross-inhibitory weights q1, q2 provide mutual inhibition.
    """

    def __init__(
        self,
        turn_gain: float = 1.35,
        input_gain: float = 4.7,
        initial_b: float = 2.4,
        initial_q: float = 3.5,
        lidar_min_range: float = 0.15,
        lidar_max_range: float = 0.50,
    ) -> None:
        self.turn_gain = float(turn_gain)
        self.input_gain = float(input_gain)
        self.lidar_min = float(lidar_min_range)
        self.lidar_max = float(lidar_max_range)

        # Recurrent self-feedback weights b = [b1, b2]
        self.b = np.array([initial_b, initial_b], dtype=np.float64)
        # Inhibitory coupling weights q = [q1, q2]
        self.q = np.array([initial_q, initial_q], dtype=np.float64)

        # Discrete-time non-spiking tanh neuron states
        self.output = np.array([-1.0, -1.0], dtype=np.float64)
        self.prev_output = self.output.copy()

        # Plasticity hyperparameters from Pedersen & Manoonpong (2018)
        self.mu_b: float = 0.0065
        self.mu_q: float = 0.015
        self.gamma_b: float = 0.0003
        self.gamma_q: float = 0.0003
        self.k: float = -0.01
        self.plasticity_scale: float = 27.0

        # Memory for deadlock persistence
        self.last_steering: float = -0.35

    def normalize_distance(self, dist_m: float) -> float:
        """Maps physical distance [min, max] to [-1, +1].

        -1 means clear (> max_range, e.g. 50 cm).
        +1 means imminent obstacle (<= min_range, e.g. 15-20 cm).
        """
        if dist_m >= self.lidar_max:
            return -1.0
        if dist_m <= self.lidar_min:
            return 1.0
        norm = 2.0 * (self.lidar_max - dist_m) / (self.lidar_max - self.lidar_min) - 1.0
        return float(np.clip(norm, -1.0, 1.0))

    def _network_step(self, inputs: np.ndarray) -> np.ndarray:
        """Computes next neuron state using recurrent tanh activation."""
        c = -0.5 * float(self.q[0] + self.q[1])
        activity = np.array(
            [
                self.b[0] * self.output[0] + c * self.output[1] + self.input_gain * inputs[0],
                self.b[1] * self.output[1] + c * self.output[0] + self.input_gain * inputs[1],
            ],
            dtype=np.float64,
        )
        return np.tanh(activity)

    def _plasticity_step(self, inputs: np.ndarray, dt: float) -> bool:
        """Online synaptic plasticity updating b and q."""
        scale = dt * self.plasticity_scale
        reflex = (inputs > -0.5).astype(np.float64)
        v = np.clip((self.output + 1.0) * 0.5, 0.0, 1.0)
        v_prev = np.clip((self.prev_output + 1.0) * 0.5, 0.0, 1.0)

        delta_b = scale * (
            self.mu_b * v_prev * v * reflex + self.gamma_b * (self.k - v) * self.b * self.b
        )
        delta_q = scale * (
            self.mu_q * v_prev * v * reflex + self.gamma_q * (self.k - v) * self.q * self.q
        )

        self.b += delta_b
        self.q += delta_q

        # Enforce biological and stability bounds
        self.b = np.clip(self.b, 0.1, 8.0)
        self.q = np.clip(self.q, 0.1, 10.0)

        return bool(np.any(reflex > 0.0))

    def compute_forward_speed(self, s_left: float, s_right: float) -> float:
        """Throttles forward speed during avoidance maneuvers as in paper."""
        if s_left > 0.70 and s_right > 0.70:
            # Extreme proximity: low speed to allow fast turning without stalling
            return 0.08
        proximity = max(s_left, s_right)
        if proximity > 0.35:
            return 0.12
        if proximity > 0.0:
            return 0.16
        return 0.22  # Nominal cruising speed

    def step(
        self,
        dist_left_m: float,
        dist_right_m: float,
        dt: float = 0.033,
    ) -> Tuple[float, float, NeuralTelemetry]:
        """Executes one control cycle.

        Args:
            dist_left_m: Left LiDAR distance measurement in meters.
            dist_right_m: Right LiDAR distance measurement in meters.
            dt: Time delta in seconds.

        Returns:
            Tuple of (yaw_rate_cmd, forward_speed_cmd, telemetry)
        """
        s_left = self.normalize_distance(dist_left_m)
        s_right = self.normalize_distance(dist_right_m)
        inputs = np.array([s_left, s_right], dtype=np.float64)

        self.prev_output = self.output.copy()
        self.output = self._network_step(inputs)
        plasticity_active = self._plasticity_step(inputs, dt)

        # Steering calculation from paper: 0.5 * (O1 - O2)
        steering = 0.5 * float(self.output[0] - self.output[1])

        # Deadlock / symmetric corner handling: break symmetry using last turn direction
        both_blocked = s_left > 0.05 and s_right > 0.05
        if both_blocked and abs(steering) < 0.08:
            steering = self.last_steering
        elif abs(steering) >= 0.08:
            self.last_steering = float(np.clip(steering, -1.0, 1.0))

        # Yaw rate command (rad/s): positive yaw turns right, negative yaw turns left
        yaw_rate = float(np.clip(self.turn_gain * steering, -1.35, 1.35))
        forward_speed = self.compute_forward_speed(s_left, s_right)

        c_val = -0.5 * float(self.q[0] + self.q[1])
        telem = NeuralTelemetry(
            o1=float(self.output[0]),
            o2=float(self.output[1]),
            o1_prev=float(self.prev_output[0]),
            o2_prev=float(self.prev_output[1]),
            b1=float(self.b[0]),
            b2=float(self.b[1]),
            q1=float(self.q[0]),
            q2=float(self.q[1]),
            c=c_val,
            s_left=s_left,
            s_right=s_right,
            raw_dist_left=dist_left_m,
            raw_dist_right=dist_right_m,
            steering=steering,
            yaw_rate=yaw_rate,
            forward_speed=forward_speed,
            plasticity_active=plasticity_active,
        )

        return yaw_rate, forward_speed, telem

    def reset(self) -> None:
        """Resets neural states and weights to baseline."""
        self.b = np.array([2.4, 2.4], dtype=np.float64)
        self.q = np.array([3.5, 3.5], dtype=np.float64)
        self.output = np.array([-1.0, -1.0], dtype=np.float64)
        self.prev_output = self.output.copy()
        self.last_steering = -0.35
