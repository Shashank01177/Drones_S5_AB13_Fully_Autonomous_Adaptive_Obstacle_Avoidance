"""Serial Communication Bridge for Arduino Flight Controller.

Enables Software-in-the-Loop (SITL) and Hardware-in-the-Loop (HITL) communication:
- Auto-detects connected Arduino boards (CH340, FTDI, ATmega32u4).
- Parses real hardware sensor telemetry ($TELEM).
- Transmits flight control commands ($CMD) and Emergency Stop ($ESTOP).
- Falls back transparently to software simulation when hardware is unplugged.
"""

from __future__ import annotations

import time
import threading
from typing import Optional, Callable, Dict, Any, List

try:
    import serial
    import serial.tools.list_ports
    HAS_SERIAL = True
except ImportError:
    HAS_SERIAL = False


class ArduinoSerialBridge:
    """Manages UART serial stream to Arduino flight controller."""

    def __init__(self, port: Optional[str] = None, baud_rate: int = 115200) -> None:
        self.port = port
        self.baud_rate = baud_rate
        self.serial_conn: Optional[Any] = None
        self.is_connected = False
        self.is_running = False
        self.read_thread: Optional[threading.Thread] = None

        # Telemetry cache
        self.latest_telemetry: Dict[str, Any] = {
            "connected": False,
            "port": "SIMULATED",
            "dist_left_cm": 50.0,
            "dist_right_cm": 50.0,
            "roll": 0.0,
            "pitch": 0.0,
            "yaw": 0.0,
            "armed": False,
            "estop": False,
        }

        self.on_telemetry_callback: Optional[Callable[[Dict[str, Any]], None]] = None

    @staticmethod
    def list_available_ports() -> List[Dict[str, str]]:
        if not HAS_SERIAL:
            return [{"port": "SIMULATED", "description": "Serial library not installed"}]
        ports = serial.tools.list_ports.comports()
        return [{"port": p.device, "description": p.description} for p in ports]

    def connect(self, port_override: Optional[str] = None) -> bool:
        if not HAS_SERIAL:
            print("[ArduinoBridge] PySerial not installed. Running in Software Simulation Mode.")
            return False

        target_port = port_override or self.port
        if not target_port:
            available = serial.tools.list_ports.comports()
            for p in available:
                if any(x in p.description.lower() for x in ("arduino", "ch340", "ftdi", "usb serial")):
                    target_port = p.device
                    break

        if not target_port:
            print("[ArduinoBridge] No physical Arduino detected. Operating in Simulated SITL Mode.")
            return False

        try:
            self.serial_conn = serial.Serial(target_port, self.baud_rate, timeout=0.1)
            self.is_connected = True
            self.port = target_port
            self.latest_telemetry["connected"] = True
            self.latest_telemetry["port"] = target_port
            print(f"[ArduinoBridge] Connected to physical Arduino on {target_port} @ {self.baud_rate} baud.")

            self.is_running = True
            self.read_thread = threading.Thread(target=self._read_loop, daemon=True)
            self.read_thread.start()
            return True
        except Exception as e:
            print(f"[ArduinoBridge] Connection to {target_port} failed: {e}. Falling back to simulation.")
            self.is_connected = False
            return False

    def _read_loop(self) -> None:
        while self.is_running and self.serial_conn and self.serial_conn.is_open:
            try:
                line = self.serial_conn.readline().decode("utf-8", errors="ignore").strip()
                if line.startswith("$TELEM"):
                    # $TELEM,DIST_L,DIST_R,ROLL,PITCH,YAW,ARMED,ESTOP
                    parts = line.split(",")
                    if len(parts) >= 8:
                        self.latest_telemetry = {
                            "connected": True,
                            "port": self.port,
                            "dist_left_cm": float(parts[1]),
                            "dist_right_cm": float(parts[2]),
                            "roll": float(parts[3]),
                            "pitch": float(parts[4]),
                            "yaw": float(parts[5]),
                            "armed": parts[6] == "1",
                            "estop": parts[7] == "1",
                        }
                        if self.on_telemetry_callback:
                            self.on_telemetry_callback(self.latest_telemetry)
            except Exception:
                time.sleep(0.05)

    def send_command(self, arm: bool, throttle: int, roll: float, pitch: float, yaw_rate: float) -> None:
        if not self.is_connected or not self.serial_conn:
            return
        cmd = f"$CMD,{1 if arm else 0},{throttle},{roll:.2f},{pitch:.2f},{yaw_rate:.2f}\n"
        try:
            self.serial_conn.write(cmd.encode("utf-8"))
        except Exception as e:
            print(f"[ArduinoBridge] Send error: {e}")

    def emergency_stop(self) -> None:
        if self.is_connected and self.serial_conn:
            try:
                self.serial_conn.write(b"$ESTOP\n")
            except Exception:
                pass

    def disconnect(self) -> None:
        self.is_running = False
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
        self.is_connected = False
        self.latest_telemetry["connected"] = False
