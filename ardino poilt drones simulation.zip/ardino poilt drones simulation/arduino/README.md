# Arduino Quadcopter Interface & Hardware Integration

This module provides the firmware, wiring guides, and communication bridge for interfacing physical Arduino microcontrollers with the simulation and autonomous avoidance dashboard.

---

## 1. Supported Microcontrollers
- **Arduino Mega 2560** (Recommended for multi-UART & high pin count)
- **Arduino Uno R3 / R4**
- **Arduino Nano Every**
- **ESP32 Dev Module** (3.3V logic level shifters required for 5V ultrasonic sensors)

---

## 2. Hardware Wiring & Pinout

| Subsystem | Arduino Mega 2560 Pin | Arduino Uno Pin | Component |
| :--- | :--- | :--- | :--- |
| **Motor 1 (Front-Right CCW)** | Digital Pin 9 (PWM) | Digital Pin 9 | ESC Signal 1 |
| **Motor 2 (Rear-Right CW)** | Digital Pin 10 (PWM) | Digital Pin 10 | ESC Signal 2 |
| **Motor 3 (Rear-Left CCW)** | Digital Pin 5 (PWM) | Digital Pin 5 | ESC Signal 3 |
| **Motor 4 (Front-Left CW)** | Digital Pin 6 (PWM) | Digital Pin 6 | ESC Signal 4 |
| **Left Sensor Trigger** | Digital Pin 11 | Digital Pin 11 | HC-SR04 Trig / LiDAR |
| **Left Sensor Echo** | Digital Pin 12 | Digital Pin 12 | HC-SR04 Echo |
| **Right Sensor Trigger** | Digital Pin 7 | Digital Pin 7 | HC-SR04 Trig / LiDAR |
| **Right Sensor Echo** | Digital Pin 8 | Digital Pin 8 | HC-SR04 Echo |
| **Status LED** | Digital Pin 13 | Digital Pin 13 | Onboard LED |
| **IMU (MPU6050 / Gyro)** | SDA (20), SCL (21) | A4 (SDA), A5 (SCL) | I2C Gyro/Accelerometer |

---

## 3. Communication Protocol

Communication operates over UART Serial at **115200 baud** using human-readable ASCII packets:

### Telemetry Packet (Arduino -> Host @ 20 Hz):
```
$TELEM,<DIST_L>,<DIST_R>,<ROLL>,<PITCH>,<YAW>,<ARMED>,<ESTOP>
```
*Example:* `$TELEM,34.2,48.1,0.5,-1.2,42.0,1,0`

### Control Command (Host -> Arduino @ 50 Hz):
```
$CMD,<ARM>,<THROTTLE>,<ROLL>,<PITCH>,<YAW_RATE>
```
*Example:* `$CMD,1,1350,0.0,-2.5,-0.65`

### Emergency Stop:
```
$ESTOP
```

---

## 4. Software-in-the-Loop (SITL) vs Hardware-in-the-Loop (HITL)

- When an Arduino is connected via USB, `arduino/serial_bridge.py` automatically detects the COM port and initiates live bidirectional telemetry and motor command streaming.
- If no physical board is plugged in, the system **transparently simulates virtual Arduino telemetry** using the mathematical flight dynamics and LiDAR raycasting model, allowing 100% of the simulation and dashboard to function without external hardware.
