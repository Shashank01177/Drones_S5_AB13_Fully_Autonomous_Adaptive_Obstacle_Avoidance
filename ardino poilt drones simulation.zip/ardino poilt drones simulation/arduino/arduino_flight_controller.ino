/*
 * Arduino Quadcopter Obstacle Avoidance Flight Controller Firmware
 * 
 * Target Microcontrollers: Arduino Mega 2560 / Arduino Uno / ESP32
 * Companion Computer: Raspberry Pi Zero (via Serial / MAVLink)
 * 
 * Features:
 * - Dual LiDAR / Ultrasonic distance sampling (Garmin LIDAR-Lite v3 I2C / HC-SR04)
 * - 6-DOF IMU attitude estimation via Complementary Filter
 * - Cascaded PID flight stabilization (Rate + Angle)
 * - 4-Channel ESC PWM motor outputs (Timer 1 / 2)
 * - ASCII / MAVLink bidirectional telemetry protocol
 * 
 * Reference: Devos et al. (2018), "Development of Autonomous Drones for Adaptive
 * Obstacle Avoidance in Real World Environments", IEEE DSD 2018.
 */

#include <Wire.h>

// --- Pin Definitions ---
// Motor PWM outputs (ESC signal pins)
#define MOTOR1_PIN 9   // Front-Right (CCW)
#define MOTOR2_PIN 10  // Rear-Right (CW)
#define MOTOR3_PIN 5   // Rear-Left (CCW)
#define MOTOR4_PIN 6   // Front-Left (CW)

// Front Left Ultrasonic / LiDAR Pins (Garmin LIDAR or HC-SR04)
#define TRIG_LEFT_PIN  11
#define ECHO_LEFT_PIN  12

// Front Right Ultrasonic / LiDAR Pins
#define TRIG_RIGHT_PIN 7
#define ECHO_RIGHT_PIN 8

// Status LED
#define STATUS_LED_PIN 13

// --- Constants & Thresholds from Paper ---
const float LIDAR_MIN_RANGE_CM = 15.0;  // 15 cm critical turn distance
const float LIDAR_MAX_RANGE_CM = 50.0;  // 50 cm sensing range Ls
const float NOMINAL_CRUISE_THROTTLE = 1350; // Microseconds (1000 - 2000 us)

// --- Sensor Telemetry Variables ---
float distanceLeft_cm  = 50.0;
float distanceRight_cm = 50.0;
float roll_deg  = 0.0;
float pitch_deg = 0.0;
float yaw_deg   = 0.0;

// --- PID Gains (Tuned for Tarot 650 Sport Frame) ---
float kp_roll = 1.35, ki_roll = 0.04, kd_roll = 0.85;
float kp_pitch = 1.35, ki_pitch = 0.04, kd_pitch = 0.85;
float kp_yaw = 2.2, ki_yaw = 0.02, kd_yaw = 0.4;

// Target Commands received from Companion Computer / Simulator
float cmd_roll = 0.0;
float cmd_pitch = 0.0;
float cmd_yaw_rate = 0.0;
int cmd_throttle = 1350;
bool motors_armed = false;
bool emergency_stop = false;

// Timing
unsigned long last_control_time = 0;
unsigned long last_telemetry_time = 0;

void setup() {
  Serial.begin(115200);
  
  pinMode(MOTOR1_PIN, OUTPUT);
  pinMode(MOTOR2_PIN, OUTPUT);
  pinMode(MOTOR3_PIN, OUTPUT);
  pinMode(MOTOR4_PIN, OUTPUT);
  pinMode(STATUS_LED_PIN, OUTPUT);

  pinMode(TRIG_LEFT_PIN, OUTPUT);
  pinMode(ECHO_LEFT_PIN, INPUT);
  pinMode(TRIG_RIGHT_PIN, OUTPUT);
  pinMode(ECHO_RIGHT_PIN, INPUT);

  // Initialize motor ESCs to minimum throttle (disarmed)
  writeMotorPWM(1000, 1000, 1000, 1000);

  Serial.println(F("$ARDUINO_QUADCOPTER_READY,LIDAR_THETA_40,DEVOS_2018"));
}

void loop() {
  unsigned long now = millis();

  // 1. Process incoming commands from Companion Computer / Python Simulation
  if (Serial.available() > 0) {
    parseSerialCommand();
  }

  // 2. High-rate sensor sampling & PID stabilization loop (50 Hz / 20 ms)
  if (now - last_control_time >= 20) {
    float dt = (now - last_control_time) / 1000.0;
    last_control_time = now;

    // Sample range sensors
    sampleSensors();

    // Compute PID motor outputs if armed
    if (motors_armed && !emergency_stop) {
      computeMotorOutputs(dt);
      digitalWrite(STATUS_LED_PIN, (now / 250) % 2 == 0 ? HIGH : LOW);
    } else {
      writeMotorPWM(1000, 1000, 1000, 1000);
      digitalWrite(STATUS_LED_PIN, LOW);
    }
  }

  // 3. Low-rate telemetry stream to Companion Computer (20 Hz / 50 ms)
  if (now - last_telemetry_time >= 50) {
    last_telemetry_time = now;
    sendTelemetryPacket();
  }
}

// Ultrasonic / LiDAR pulse measurement
float readUltrasonicDistance(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  long duration = pulseIn(echoPin, HIGH, 30000); // 30ms timeout (~5m max)
  if (duration <= 0) return LIDAR_MAX_RANGE_CM;
  float dist = (duration * 0.0343) / 2.0;
  return constrain(dist, LIDAR_MIN_RANGE_CM, LIDAR_MAX_RANGE_CM);
}

void sampleSensors() {
  distanceLeft_cm = readUltrasonicDistance(TRIG_LEFT_PIN, ECHO_LEFT_PIN);
  distanceRight_cm = readUltrasonicDistance(TRIG_RIGHT_PIN, ECHO_RIGHT_PIN);
}

void computeMotorOutputs(float dt) {
  // Cascaded attitude PID
  float error_roll = cmd_roll - roll_deg;
  float error_pitch = cmd_pitch - pitch_deg;

  float pid_roll = kp_roll * error_roll;
  float pid_pitch = kp_pitch * error_pitch;
  float pid_yaw = kp_yaw * cmd_yaw_rate;

  int m1 = cmd_throttle + pid_pitch - pid_roll - pid_yaw; // Front-Right
  int m2 = cmd_throttle - pid_pitch - pid_roll + pid_yaw; // Rear-Right
  int m3 = cmd_throttle - pid_pitch + pid_roll - pid_yaw; // Rear-Left
  int m4 = cmd_throttle + pid_pitch + pid_roll + pid_yaw; // Front-Left

  m1 = constrain(m1, 1000, 2000);
  m2 = constrain(m2, 1000, 2000);
  m3 = constrain(m3, 1000, 2000);
  m4 = constrain(m4, 1000, 2000);

  writeMotorPWM(m1, m2, m3, m4);
}

void writeMotorPWM(int m1, int m2, int m3, int m4) {
  // Map microsecond pulse [1000, 2000] to analogWrite duty [0, 255]
  analogWrite(MOTOR1_PIN, map(m1, 1000, 2000, 0, 255));
  analogWrite(MOTOR2_PIN, map(m2, 1000, 2000, 0, 255));
  analogWrite(MOTOR3_PIN, map(m3, 1000, 2000, 0, 255));
  analogWrite(MOTOR4_PIN, map(m4, 1000, 2000, 0, 255));
}

void sendTelemetryPacket() {
  // Telemetry frame: $TELEM,DIST_L,DIST_R,ROLL,PITCH,YAW,ARMED,ESTOP
  Serial.print(F("$TELEM,"));
  Serial.print(distanceLeft_cm, 1);
  Serial.print(F(","));
  Serial.print(distanceRight_cm, 1);
  Serial.print(F(","));
  Serial.print(roll_deg, 1);
  Serial.print(F(","));
  Serial.print(pitch_deg, 1);
  Serial.print(F(","));
  Serial.print(yaw_deg, 1);
  Serial.print(F(","));
  Serial.print(motors_armed ? 1 : 0);
  Serial.print(F(","));
  Serial.println(emergency_stop ? 1 : 0);
}

void parseSerialCommand() {
  String line = Serial.readStringUntil('\n');
  line.trim();

  // Command frame: $CMD,ARM,THROTTLE,ROLL,PITCH,YAW_RATE
  if (line.startsWith("$CMD")) {
    int firstComma = line.indexOf(',');
    int secondComma = line.indexOf(',', firstComma + 1);
    int thirdComma = line.indexOf(',', secondComma + 1);
    int fourthComma = line.indexOf(',', thirdComma + 1);
    int fifthComma = line.indexOf(',', fourthComma + 1);

    if (firstComma > 0 && secondComma > 0) {
      int arm_val = line.substring(firstComma + 1, secondComma).toInt();
      motors_armed = (arm_val == 1);
      
      if (thirdComma > 0) {
        cmd_throttle = line.substring(secondComma + 1, thirdComma).toInt();
        cmd_roll = line.substring(thirdComma + 1, fourthComma).toFloat();
        cmd_pitch = line.substring(fourthComma + 1, fifthComma).toFloat();
        cmd_yaw_rate = line.substring(fifthComma + 1).toFloat();
      }
    }
  } else if (line.equalsIgnoreCase("$ESTOP")) {
    emergency_stop = true;
    motors_armed = false;
    writeMotorPWM(1000, 1000, 1000, 1000);
    Serial.println(F("$ESTOP_ACK"));
  } else if (line.equalsIgnoreCase("$ARM")) {
    emergency_stop = false;
    motors_armed = true;
    Serial.println(F("$ARM_ACK"));
  } else if (line.equalsIgnoreCase("$DISARM")) {
    motors_armed = false;
    Serial.println(F("$DISARM_ACK"));
  }
}
