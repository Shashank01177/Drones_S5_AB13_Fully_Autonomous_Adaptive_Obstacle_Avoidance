/**
 * AERODRONE AI - Web Dashboard Application Logic
 * Handles WebSocket communication, UI telemetry updates, human-in-the-loop decision
 * workflow, keyboard hotkeys, and experiment data export.
 */

class DashboardApp {
  constructor() {
    this.ws = null;
    this.sim = null;
    this.currentScenarioId = 'front_obstacle';
    this.flightState = 'IDLE';
    this.pendingDecision = null;
    this.overrideUnsafe = false;
    this.simSpeed = 1.0;
    this.metrics = {};

    this.initElements();
    this.initSimulator();
    this.initWebSocket();
    this.initEventListeners();
    this.initKeyboardControls();
  }

  initElements() {
    // HUD & Badges
    this.wsStatusBadge = document.getElementById('ws-status-badge');
    this.flightStateBadge = document.getElementById('flight-state-badge');
    this.hudAlt = document.getElementById('hud-alt');
    this.hudSpeed = document.getElementById('hud-speed');
    this.hudHeading = document.getElementById('hud-heading');
    this.hudClearance = document.getElementById('hud-clearance');

    // Alert Banner
    this.hudAlert = document.getElementById('hud-alert');
    this.alertTitle = document.getElementById('alert-title');
    this.alertDesc = document.getElementById('alert-desc');
    this.alertPrompt = document.getElementById('alert-prompt');

    // Direction Buttons
    this.dirButtons = document.querySelectorAll('.btn-dir');
    this.safetyExplanation = document.getElementById('safety-explanation');
    this.overrideCheckbox = document.getElementById('override-checkbox');
    this.autoAvoidCheckbox = document.getElementById('auto-avoid-checkbox');

    // Pilot Modes ('AUTONOMOUS' vs 'MANUAL')
    this.flightMode = 'AUTONOMOUS';
    this.collisionAssist = true;
    this.pressedKeys = new Set();
    this.manualLoopInterval = null;

    this.btnModeAuto = document.getElementById('btn-mode-auto');
    this.btnModeManual = document.getElementById('btn-mode-manual');
    this.btnQuickSwitchMode = document.getElementById('btn-quick-switch-mode');
    this.currentModeLabel = document.getElementById('current-mode-label');
    this.modeDescText = document.getElementById('mode-desc-text');
    this.assistCheckbox = document.getElementById('assist-checkbox');

    // Controls
    this.btnStart = document.getElementById('btn-start');
    this.btnPause = document.getElementById('btn-pause');
    this.btnReset = document.getElementById('btn-reset');
    this.btnEstop = document.getElementById('btn-estop');

    // Scenarios
    this.scenarioSelect = document.getElementById('scenario-select');
    this.scenarioDesc = document.getElementById('scenario-desc');

    // Sensors & LiDAR
    this.lidarLeftVal = document.getElementById('lidar-left-val');
    this.lidarRightVal = document.getElementById('lidar-right-val');
    this.radarMeters = document.getElementById('radar-meters');

    // Neural Controller
    this.neuralO1 = document.getElementById('neural-o1');
    this.neuralO2 = document.getElementById('neural-o2');
    this.neuralB1 = document.getElementById('neural-b1');
    this.neuralB2 = document.getElementById('neural-b2');
    this.neuralQ1 = document.getElementById('neural-q1');
    this.neuralQ2 = document.getElementById('neural-q2');
    this.neuralSteer = document.getElementById('neural-steer');
    this.neuralPlasticity = document.getElementById('neural-plasticity');

    // Metrics & Logs
    this.statTrials = document.getElementById('stat-trials');
    this.statSuccess = document.getElementById('stat-success');
    this.statRate = document.getElementById('stat-rate');
    this.statResponse = document.getElementById('stat-response');
    this.logTableBody = document.getElementById('log-table-body');
  }

  initSimulator() {
    this.sim = new Drone3DSimulator('viewport-container');
  }

  initWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    this.ws = new WebSocket(wsUrl);

    this.ws.onopen = () => {
      this.wsStatusBadge.className = 'status-badge live';
      this.wsStatusBadge.querySelector('.badge-text').textContent = 'CONNECTED';
      this.sendMsg({ type: 'get_scenarios' });
      this.sendMsg({ type: 'get_history' });
    };

    this.ws.onclose = () => {
      this.wsStatusBadge.className = 'status-badge danger';
      this.wsStatusBadge.querySelector('.badge-text').textContent = 'DISCONNECTED';
      setTimeout(() => this.initWebSocket(), 2000);
    };

    this.ws.onerror = (err) => {
      console.error('WebSocket Error:', err);
    };

    this.ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        this.handleServerMessage(msg);
      } catch (e) {
        console.error('Failed to parse WS msg:', e);
      }
    };
  }

  sendMsg(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  handleServerMessage(msg) {
    switch (msg.type) {
      case 'state_update':
        this.updateState(msg.data);
        break;

      case 'scenarios_list':
        this.populateScenarios(msg.data);
        break;

      case 'scenario_loaded':
        this.onScenarioLoaded(msg.data);
        break;

      case 'obstacle_detected':
        this.onObstacleDetected(msg.data);
        break;

      case 'decision_accepted':
        this.onDecisionAccepted(msg.data);
        break;

      case 'decision_rejected':
        this.onDecisionRejected(msg.data);
        break;

      case 'trial_completed':
        this.onTrialCompleted(msg.data);
        break;

      case 'history_data':
        this.populateHistory(msg.data);
        break;
    }
  }

  updateState(data) {
    const drone = data.drone;
    const sensors = data.sensors;
    const neural = data.neural;
    const decision = data.decision;

    this.flightState = decision.state;
    this.updateFlightStateBadge(decision.state);

    // Update 3D Viewport
    this.sim.updateDroneState(drone, decision.state);
    this.sim.updateTrajectory(data.trajectory);
    this.sim.updateSensors(sensors, drone.x, drone.y, drone.z);

    // Update Top Telemetry Card
    this.hudAlt.textContent = `${drone.z.toFixed(2)} m`;
    this.hudSpeed.textContent = `${drone.speed.toFixed(2)} m/s`;
    this.hudHeading.textContent = `${drone.yaw.toFixed(0)}°`;

    // Min clearance calculation
    let minD = 99.0;
    Object.values(sensors).forEach(s => {
      if (s.distance < minD) minD = s.distance;
    });
    this.hudClearance.textContent = minD < 10.0 ? `${minD.toFixed(2)} m` : '> 3.0 m';
    this.hudClearance.style.color = minD <= 0.23 ? 'var(--accent-rose)' : (minD <= 0.5 ? 'var(--accent-amber)' : 'var(--accent-cyan)');

    // Dual Front LiDARs (Base Paper Devos 2018)
    const dLeft = sensors.lidar_left ? sensors.lidar_left.distance : 0.5;
    const dRight = sensors.lidar_right ? sensors.lidar_right.distance : 0.5;
    this.lidarLeftVal.textContent = `${(dLeft * 100).toFixed(1)} cm`;
    this.lidarRightVal.textContent = `${(dRight * 100).toFixed(1)} cm`;
    this.lidarLeftVal.style.color = dLeft <= 0.23 ? 'var(--accent-rose)' : (dLeft <= 0.5 ? 'var(--accent-amber)' : 'var(--accent-cyan)');
    this.lidarRightVal.style.color = dRight <= 0.23 ? 'var(--accent-rose)' : (dRight <= 0.5 ? 'var(--accent-amber)' : 'var(--accent-cyan)');

    // Neural Controller Telemetry
    if (neural) {
      this.neuralO1.textContent = neural.o1.toFixed(3);
      this.neuralO2.textContent = neural.o2.toFixed(3);
      this.neuralB1.textContent = neural.b1.toFixed(3);
      this.neuralB2.textContent = neural.b2.toFixed(3);
      this.neuralQ1.textContent = neural.q1.toFixed(3);
      this.neuralQ2.textContent = neural.q2.toFixed(3);
      this.neuralSteer.textContent = `${neural.steering.toFixed(3)} (${neural.yaw_rate > 0 ? 'Right' : 'Left'})`;
      this.neuralPlasticity.textContent = neural.plasticity_active ? 'ACTIVE' : 'IDLE';
      this.neuralPlasticity.style.color = neural.plasticity_active ? 'var(--accent-purple)' : 'var(--text-dim)';
    }

    // Dynamic Sensor Radar Meters
    this.updateRadarMeters(sensors);
  }

  updateRadarMeters(sensors) {
    if (!sensors) return;
    const radarKeys = ['FORWARD', 'LEFT', 'RIGHT', 'BACKWARD', 'FORWARD_LEFT', 'FORWARD_RIGHT', 'UP', 'DOWN'];
    radarKeys.forEach(k => {
      const reading = sensors[k];
      if (!reading) return;
      const bar = document.getElementById(`meter-fill-${k.toLowerCase()}`);
      const val = document.getElementById(`meter-val-${k.toLowerCase()}`);
      if (bar && val) {
        const d = reading.distance;
        val.textContent = d < 5.0 ? `${d.toFixed(2)}m` : '> 3m';
        const pct = Math.min(100, Math.max(5, (d / 2.5) * 100));
        bar.style.width = `${pct}%`;
        bar.className = 'meter-bar-fill ' + (d <= 0.23 ? 'fill-danger' : (d <= 0.5 ? 'fill-caution' : 'fill-safe'));
      }
    });
  }

  updateFlightStateBadge(state) {
    if (state === 'WAITING_FOR_USER') {
      this.flightStateBadge.querySelector('.badge-text').textContent = 'DECISION REQUIRED';
      this.flightStateBadge.className = 'status-badge waiting';
    } else if (state === 'COLLISION') {
      this.flightStateBadge.querySelector('.badge-text').textContent = 'COLLISION';
      this.flightStateBadge.className = 'status-badge danger';
    } else if (state === 'EXECUTING_AVOIDANCE') {
      this.flightStateBadge.querySelector('.badge-text').textContent = 'AVOIDING OBSTACLE';
      this.flightStateBadge.className = 'status-badge live';
    } else if (state === 'CRUISING') {
      this.flightStateBadge.querySelector('.badge-text').textContent = 'CRUISING';
      this.flightStateBadge.className = 'status-badge live';
    } else {
      this.flightStateBadge.querySelector('.badge-text').textContent = state;
      this.flightStateBadge.className = 'status-badge';
    }

    if (state === 'CRUISING' && this.hudAlert.classList.contains('visible')) {
      this.hudAlert.classList.remove('visible');
    }
  }

  onObstacleDetected(event) {
    this.pendingDecision = event;
    const safest = event.safest_path || this.findPaperOptimal(event.evaluations);

    // Show warning alert banner
    this.hudAlert.classList.add('visible');

    if (event.auto_avoid) {
      this.alertTitle.innerHTML = `⚠️ OBSTACLE DETECTED ➜ AUTONOMOUS AVOIDANCE`;
      this.alertDesc.textContent = `Distance: ${(event.trigger_distance * 100).toFixed(1)} cm. Executing safest path: ${safest}.`;
      this.alertPrompt.innerHTML = `Auto-Steering around obstacle: <strong style="color:var(--accent-cyan)">${safest}</strong>`;
      this.safetyExplanation.innerHTML = `<span style="color:var(--accent-cyan); font-weight:700">🚀 AUTONOMOUS AVOIDANCE ACTIVE [${safest}]</span>: Navigating around obstacle along safest path.`;
      
      // Auto-hide alert banner after 3 seconds so 3D view remains clear
      setTimeout(() => {
        if (this.flightState !== 'WAITING_FOR_USER') {
          this.hudAlert.classList.remove('visible');
        }
      }, 3000);
    } else {
      this.alertTitle.innerHTML = `⚠️ OBSTACLE DETECTED [${event.trigger_sensor.toUpperCase()}]`;
      this.alertDesc.textContent = `Distance: ${(event.trigger_distance * 100).toFixed(1)} cm. Safe hover engaged. Decision required.`;
      this.alertPrompt.innerHTML = `Select safe avoidance direction (Recommended: <strong>${safest}</strong>)`;
    }

    // Update direction buttons with safety badges
    this.updateDirectionButtons(event.evaluations, safest);
  }

  findPaperOptimal(evaluations) {
    for (const [dir, info] of Object.entries(evaluations)) {
      if (info.is_paper_optimal || info.status === 'RECOMMENDED') {
        return dir;
      }
    }
    return 'RIGHT';
  }

  updateDirectionButtons(evaluations, activeSafestDir = null) {
    this.dirButtons.forEach(btn => {
      const dir = btn.dataset.direction;
      const evalInfo = evaluations[dir];

      // Reset classes
      btn.className = 'btn-dir';

      if (evalInfo) {
        if (evalInfo.status === 'RECOMMENDED') {
          btn.classList.add('status-recommended');
        } else if (evalInfo.status === 'SAFE') {
          btn.classList.add('status-safe');
        } else if (evalInfo.status === 'CAUTION') {
          btn.classList.add('status-caution');
        } else if (evalInfo.status === 'BLOCKED') {
          btn.classList.add('status-blocked');
        }
      }

      if (activeSafestDir && dir === activeSafestDir) {
        btn.style.boxShadow = '0 0 16px rgba(6, 182, 212, 0.8)';
        btn.style.borderColor = 'var(--accent-cyan)';
      } else {
        btn.style.boxShadow = '';
        btn.style.borderColor = '';
      }
    });

    const optimalDir = activeSafestDir || this.findPaperOptimal(evaluations);
    const optEval = evaluations[optimalDir];
    if (optEval) {
      this.safetyExplanation.innerHTML = `<strong>${optimalDir}</strong>: ${optEval.reason}`;
    }
  }

  onDecisionAccepted(data) {
    this.hudAlert.classList.remove('visible');
    this.safetyExplanation.innerHTML = `<span style="color:var(--accent-emerald)">✓ ${data.message}</span>`;
  }

  onDecisionRejected(data) {
    this.safetyExplanation.innerHTML = `<span style="color:var(--accent-rose)">❌ ${data.message}</span>`;
  }

  onTrialCompleted(trial) {
    this.addLogRow(trial);
    this.sendMsg({ type: 'get_history' });
  }

  populateScenarios(scenarios) {
    this.scenarioSelect.innerHTML = '';
    Object.values(scenarios).forEach(sc => {
      const opt = document.createElement('option');
      opt.value = sc.id;
      opt.textContent = sc.name;
      this.scenarioSelect.appendChild(opt);
    });
    this.scenarioSelect.value = this.currentScenarioId;
  }

  onScenarioLoaded(sc) {
    this.currentScenarioId = sc.id;
    this.scenarioDesc.textContent = sc.description;
    this.sim.syncObstacles(sc.obstacles);
    this.safetyExplanation.textContent = `Scenario loaded: ${sc.name}. Press START or SPACE to begin.`;

    // Clear direction badges
    this.dirButtons.forEach(btn => btn.className = 'btn-dir');
  }

  populateHistory(data) {
    this.metrics = data.summary;
    this.statTrials.textContent = data.summary.total_trials;
    this.statSuccess.textContent = data.summary.successful_avoidances;
    this.statRate.textContent = `${data.summary.success_rate_percent}%`;
    this.statResponse.textContent = `${data.summary.avg_response_time_sec}s`;

    this.logTableBody.innerHTML = '';
    data.trials.slice(-10).reverse().forEach(t => this.addLogRow(t));
  }

  addLogRow(trial) {
    const tr = document.createElement('tr');
    const isSuccess = trial.result_status === 'SUCCESS';
    const isCollision = trial.result_status === 'COLLISION';

    tr.innerHTML = `
      <td>${trial.trial_id.slice(-6)}</td>
      <td>${trial.scenario_id}</td>
      <td><strong>${trial.user_selected_direction}</strong></td>
      <td>${trial.response_time_sec.toFixed(1)}s</td>
      <td>${trial.min_clearance_m.toFixed(2)}m</td>
      <td class="${isSuccess ? 'badge-success' : (isCollision ? 'badge-collision' : 'badge-held')}">
        ${trial.result_status}
      </td>
    `;
    this.logTableBody.insertBefore(tr, this.logTableBody.firstChild);
  }

  initEventListeners() {
    // Start / Pause / Reset / E-Stop
    this.btnStart.addEventListener('click', () => this.sendMsg({ type: 'start_sim' }));
    this.btnPause.addEventListener('click', () => this.sendMsg({ type: 'pause_sim' }));
    this.btnReset.addEventListener('click', () => this.sendMsg({ type: 'reset_sim' }));
    this.btnEstop.addEventListener('click', () => this.sendMsg({ type: 'emergency_stop' }));

    // Scenario Select
    this.scenarioSelect.addEventListener('change', (e) => {
      this.sendMsg({ type: 'load_scenario', scenario_id: e.target.value });
    });

    // Speed Selector Buttons
    document.querySelectorAll('.speed-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.speed-btn').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        const spd = parseFloat(e.target.dataset.speed) || 1.0;
        this.simSpeed = spd;
        this.sendMsg({ type: 'set_speed', speed: spd });
      });
    });
    // Flight Mode Toggles
    if (this.btnModeAuto) {
      this.btnModeAuto.addEventListener('click', () => this.setFlightMode('AUTONOMOUS'));
    }
    if (this.btnModeManual) {
      this.btnModeManual.addEventListener('click', () => this.setFlightMode('MANUAL'));
    }
    if (this.btnQuickSwitchMode) {
      this.btnQuickSwitchMode.addEventListener('click', () => {
        this.setFlightMode(this.flightMode === 'AUTONOMOUS' ? 'MANUAL' : 'AUTONOMOUS');
      });
    }
    if (this.assistCheckbox) {
      this.assistCheckbox.addEventListener('change', (e) => {
        this.collisionAssist = e.target.checked;
        this.sendMsg({ type: 'set_collision_assist', enabled: this.collisionAssist });
      });
    }

    // Direction Buttons Click & Hold (supports both autonomous decision and manual flying)
    const dirToKey = {
      'FORWARD': 'W',
      'BACKWARD': 'S',
      'LEFT': 'A',
      'RIGHT': 'D',
      'UP': 'R',
      'DOWN': 'F',
      'FORWARD_LEFT': 'Q',
      'FORWARD_RIGHT': 'E',
      'HOVER': ' ',
    };

    this.dirButtons.forEach(btn => {
      const dir = btn.dataset.direction;

      // Click for autonomous decision
      btn.addEventListener('click', () => {
        if (this.flightMode === 'AUTONOMOUS') {
          this.sendMsg({ type: 'user_decision', direction: dir });
        }
      });

      // Mouse/Touch hold for continuous manual flight
      const startManualHold = (e) => {
        if (this.flightMode === 'MANUAL') {
          e.preventDefault();
          const k = dirToKey[dir];
          if (k) this.pressedKeys.add(k);
          btn.style.transform = 'scale(0.95)';
        }
      };

      const stopManualHold = () => {
        if (this.flightMode === 'MANUAL') {
          const k = dirToKey[dir];
          if (k) this.pressedKeys.delete(k);
          btn.style.transform = '';
        }
      };

      btn.addEventListener('mousedown', startManualHold);
      btn.addEventListener('mouseup', stopManualHold);
      btn.addEventListener('mouseleave', stopManualHold);
      btn.addEventListener('touchstart', startManualHold, { passive: false });
      btn.addEventListener('touchend', stopManualHold);

      btn.addEventListener('mouseenter', () => {
        if (this.pendingDecision && this.pendingDecision.evaluations[btn.dataset.direction]) {
          const info = this.pendingDecision.evaluations[btn.dataset.direction];
          this.safetyExplanation.innerHTML = `<strong>${info.name}</strong> [${info.status}]: ${info.reason}`;
        }
      });
    });

    // Camera Buttons
    document.querySelectorAll('.btn-cam').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.btn-cam').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.sim.setCameraMode(e.target.dataset.cam);
      });
    });

    // Auto Avoid Checkbox
    if (this.autoAvoidCheckbox) {
      this.autoAvoidCheckbox.addEventListener('change', (e) => {
        this.sendMsg({ type: 'set_auto_avoid', enabled: e.target.checked });
        if (e.target.checked) {
          this.safetyExplanation.innerHTML = '<span style="color:var(--accent-cyan)">Auto Safest-Path Avoidance active: Drone automatically navigates around obstacles.</span>';
        } else {
          this.safetyExplanation.textContent = 'Interactive HITL Mode active: Drone holds hover upon obstacle detection and waits for user decision.';
        }
      });
    }

    // Override Checkbox
    this.overrideCheckbox.addEventListener('change', (e) => {
      this.overrideUnsafe = e.target.checked;
      this.sendMsg({ type: 'set_override_mode', enabled: this.overrideUnsafe });
      if (this.overrideUnsafe) {
        this.safetyExplanation.innerHTML = '<span style="color:var(--accent-rose)">⚠️ Override Mode ENABLED: Unsafe choices will execute to test collisions!</span>';
      } else {
        this.safetyExplanation.textContent = 'Override Mode disabled. Safety validation active.';
      }
    });

    // CSV & JSON Exports
    document.getElementById('btn-export-csv').addEventListener('click', () => {
      window.open('/api/logs/csv', '_blank');
    });

    document.getElementById('btn-export-json').addEventListener('click', () => {
      window.open('/api/logs/json', '_blank');
    });
  }

  setFlightMode(mode) {
    this.flightMode = mode;
    this.sendMsg({ type: 'set_flight_mode', mode: mode });

    if (mode === 'MANUAL') {
      if (this.btnModeManual) {
        this.btnModeManual.className = 'btn-mode manual-active';
        this.btnModeAuto.className = 'btn-mode';
      }
      if (this.currentModeLabel) this.currentModeLabel.textContent = '[MANUAL PILOT]';
      if (this.modeDescText) this.modeDescText.textContent = '🎮 Manual Pilot active. Hold WASD / Arrows to fly freely.';
      if (this.btnQuickSwitchMode) this.btnQuickSwitchMode.textContent = 'SWITCH TO AUTO [M]';
      this.safetyExplanation.innerHTML = '<span style="color:var(--accent-purple); font-weight:700">🎮 MANUAL PILOT ACTIVE</span>: Hold W/A/S/D or Arrows to pitch & roll, R/F to climb & descend, Q/E to rotate, SPACE to hover.';

      // Start continuous 40 Hz manual velocity streaming
      if (!this.manualLoopInterval) {
        this.manualLoopInterval = setInterval(() => this.stepManualFlight(), 25);
      }
    } else {
      if (this.btnModeAuto) {
        this.btnModeAuto.className = 'btn-mode active';
        this.btnModeManual.className = 'btn-mode';
      }
      if (this.currentModeLabel) this.currentModeLabel.textContent = '[AUTONOMOUS]';
      if (this.modeDescText) this.modeDescText.textContent = '🤖 Autonomous Devos (2018) neural loop';
      if (this.btnQuickSwitchMode) this.btnQuickSwitchMode.textContent = 'SWITCH TO MANUAL [M]';
      this.safetyExplanation.textContent = 'Autonomous research mode active. Drone runs neural controller and pauses at obstacles for user decisions.';

      if (this.manualLoopInterval) {
        clearInterval(this.manualLoopInterval);
        this.manualLoopInterval = null;
      }
      this.pressedKeys.clear();
    }
  }

  stepManualFlight() {
    if (this.flightMode !== 'MANUAL') return;

    let vx = 0.0;
    let vy = 0.0;
    let vz = 0.0;
    let yaw_rate = 0.0;

    const cruiseSpeed = 0.35;
    const climbSpeed = 0.30;
    const yawSpeed = 1.0;

    // Pitch Forward / Backward
    if (this.pressedKeys.has('W') || this.pressedKeys.has('ARROWUP')) vx += cruiseSpeed;
    if (this.pressedKeys.has('S') || this.pressedKeys.has('ARROWDOWN')) vx -= cruiseSpeed;

    // Roll Left / Right (Strafe)
    if (this.pressedKeys.has('A') || this.pressedKeys.has('ARROWLEFT')) vy += cruiseSpeed;
    if (this.pressedKeys.has('D') || this.pressedKeys.has('ARROWRIGHT')) vy -= cruiseSpeed;

    // Climb / Descend
    if (this.pressedKeys.has('R') || this.pressedKeys.has('SHIFT') || this.pressedKeys.has('PAGEUP')) vz += climbSpeed;
    if (this.pressedKeys.has('F') || this.pressedKeys.has('CONTROL') || this.pressedKeys.has('PAGEDOWN')) vz -= climbSpeed;

    // Yaw rotation
    if (this.pressedKeys.has('Q')) yaw_rate += yawSpeed;
    if (this.pressedKeys.has('E')) yaw_rate -= yawSpeed;

    // Brake / Hover
    if (this.pressedKeys.has(' ')) {
      vx = 0.0;
      vy = 0.0;
      vz = 0.0;
      yaw_rate = 0.0;
    }

    this.sendMsg({
      type: 'manual_velocity',
      vx: vx,
      vy: vy,
      vz: vz,
      yaw_rate: yaw_rate,
    });
  }

  initKeyboardControls() {
    window.addEventListener('keydown', (e) => {
      // Prevent keyboard interaction if user is focused inside input or select
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
        return;
      }

      const key = e.key.toUpperCase();

      // M key toggles between Autonomous and Manual Pilot modes
      if (key === 'M') {
        e.preventDefault();
        this.setFlightMode(this.flightMode === 'AUTONOMOUS' ? 'MANUAL' : 'AUTONOMOUS');
        return;
      }

      // Track pressed keys for continuous manual flying
      this.pressedKeys.add(key);

      // Handle Autonomous Mode single-press actions
      if (this.flightMode === 'AUTONOMOUS') {
        const keyMap = {
          'W': 'FORWARD',
          'S': 'BACKWARD',
          'A': 'LEFT',
          'D': 'RIGHT',
          'R': 'UP',
          'F': 'DOWN',
          'Q': 'FORWARD_LEFT',
          'E': 'FORWARD_RIGHT',
          'Z': 'BACKWARD_LEFT',
          'C': 'BACKWARD_RIGHT',
        };

        if (key === ' ') {
          e.preventDefault();
          if (this.flightState === 'CRUISING') {
            this.sendMsg({ type: 'pause_sim' });
          } else if (this.flightState === 'WAITING_FOR_USER') {
            this.sendMsg({ type: 'user_decision', direction: 'HOVER' });
          } else {
            this.sendMsg({ type: 'start_sim' });
          }
        } else if (key === 'ENTER') {
          e.preventDefault();
          if (this.flightState === 'WAITING_FOR_USER' && this.pendingDecision) {
            const optimal = this.findPaperOptimal(this.pendingDecision.evaluations);
            this.sendMsg({ type: 'user_decision', direction: optimal });
          }
        } else if (key === 'ESCAPE') {
          e.preventDefault();
          this.sendMsg({ type: 'emergency_stop' });
        } else if (keyMap[key]) {
          e.preventDefault();
          const dir = keyMap[key];
          const btn = document.querySelector(`.btn-dir[data-direction="${dir}"]`);
          if (btn) {
            btn.style.transform = 'scale(0.95)';
            setTimeout(() => btn.style.transform = '', 150);
          }
          this.sendMsg({ type: 'user_decision', direction: dir });
        }
      }
    });

    window.addEventListener('keyup', (e) => {
      const key = e.key.toUpperCase();
      this.pressedKeys.delete(key);
    });
  }
}

// Instantiate upon DOM load
window.addEventListener('DOMContentLoaded', () => {
  window.app = new DashboardApp();
});
