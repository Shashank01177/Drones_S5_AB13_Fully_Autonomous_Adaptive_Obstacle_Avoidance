/**
 * 3D Quadcopter and Environment Simulation Renderer (Three.js)
 * 
 * Features:
 * - High-fidelity Tarot 650 quadcopter 3D model with spinning rotors & status LEDs.
 * - Dual front LiDAR laser beams (at +/-20 deg, Theta = 40 deg from Devos et al. 2018).
 * - Multi-directional range visualization beams with hit impact markers.
 * - Dynamic 3D obstacle rendering (cylinders, walls, moving barriers).
 * - Real-time 3D flight trajectory ribbon.
 * - 4 Camera modes: Free Orbit, Chase Drone, Top-Down Tactical, and FPV Nose Cam.
 */

class Drone3DSimulator {
  constructor(containerId) {
    this.container = document.getElementById(containerId);
    this.width = this.container.clientWidth || 800;
    this.height = this.container.clientHeight || 600;

    this.cameraMode = 'chase'; // 'chase', 'orbit', 'top', 'fpv'
    this.obstacleMeshes = new Map();
    this.propellers = [];
    this.laserLines = new Map();

    this.initScene();
    this.buildQuadcopterModel();
    this.buildEnvironmentGrid();
    this.initTrajectory();

    window.addEventListener('resize', () => this.onWindowResize());
    this.animate();
  }

  initScene() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x050811);
    this.scene.fog = new THREE.FogExp2(0x050811, 0.04);

    this.camera = new THREE.PerspectiveCamera(60, this.width / this.height, 0.05, 100);
    this.camera.position.set(0, -3.5, 2.5);

    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(this.width, this.height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.container.appendChild(this.renderer.domElement);

    // Controls
    if (typeof THREE.OrbitControls !== 'undefined') {
      this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.05;
      this.controls.maxPolarAngle = Math.PI / 2 - 0.02; // Don't go below floor
    }

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
    this.scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 0.8);
    dirLight.position.set(5, 5, 8);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 1024;
    dirLight.shadow.mapSize.height = 1024;
    dirLight.shadow.camera.near = 0.5;
    dirLight.shadow.camera.far = 25;
    const d = 6;
    dirLight.shadow.camera.left = -d;
    dirLight.shadow.camera.right = d;
    dirLight.shadow.camera.top = d;
    dirLight.shadow.camera.bottom = -d;
    this.scene.add(dirLight);

    const pointCyan = new THREE.PointLight(0x06b6d4, 1.2, 8);
    pointCyan.position.set(0, 0, 3);
    this.scene.add(pointCyan);
  }

  buildEnvironmentGrid() {
    // Cyberpunk floor grid
    const gridHelper = new THREE.GridHelper(10, 20, 0x06b6d4, 0x1e293b);
    gridHelper.rotation.x = Math.PI / 2;
    gridHelper.position.z = 0;
    this.scene.add(gridHelper);

    // Floor receiver plane for soft shadows
    const floorGeo = new THREE.PlaneGeometry(10, 10);
    const floorMat = new THREE.MeshStandardMaterial({
      color: 0x090d16,
      roughness: 0.85,
      metalness: 0.15,
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.receiveShadow = true;
    this.scene.add(floor);

    // Arena boundary wireframe box
    const wallGeo = new THREE.BoxGeometry(10, 10, 3.5);
    const wireframe = new THREE.WireframeGeometry(wallGeo);
    const lineMat = new THREE.LineBasicMaterial({ color: 0x334155, linewidth: 1, transparent: true, opacity: 0.35 });
    const wallLine = new THREE.LineSegments(wireframe, lineMat);
    wallLine.position.z = 1.75;
    this.scene.add(wallLine);
  }

  buildQuadcopterModel() {
    this.droneGroup = new THREE.Group();
    this.droneGroup.position.set(0, 0, 1.0);

    // Materials
    const carbonMat = new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.4,
      metalness: 0.8,
    });
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      roughness: 0.3,
      metalness: 0.9,
    });
    const propMat = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      roughness: 0.2,
      metalness: 0.5,
      transparent: true,
      opacity: 0.85,
    });

    // Central body hub (Pixhawk / Arduino enclosure)
    const bodyGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.04, 16);
    const bodyMesh = new THREE.Mesh(bodyGeo, carbonMat);
    bodyMesh.rotation.x = Math.PI / 2;
    bodyMesh.castShadow = true;
    this.droneGroup.add(bodyMesh);

    // Arduino / Pixhawk top plate
    const plateGeo = new THREE.BoxGeometry(0.07, 0.09, 0.02);
    const plateMat = new THREE.MeshStandardMaterial({ color: 0x0f766e, roughness: 0.5 });
    const plateMesh = new THREE.Mesh(plateGeo, plateMat);
    plateMesh.position.z = 0.025;
    plateMesh.castShadow = true;
    this.droneGroup.add(plateMesh);

    // Status LED (changes color based on flight state)
    const ledGeo = new THREE.SphereGeometry(0.015, 8, 8);
    this.statusLedMat = new THREE.MeshBasicMaterial({ color: 0x10b981 });
    const statusLed = new THREE.Mesh(ledGeo, this.statusLedMat);
    statusLed.position.set(0, 0, 0.04);
    this.droneGroup.add(statusLed);

    // 4 Carbon fiber arms (X configuration, span Ld = 0.34m, arm radius = 0.17m)
    const armLength = 0.17;
    const armAngles = [Math.PI / 4, 3 * Math.PI / 4, 5 * Math.PI / 4, 7 * Math.PI / 4];

    this.propellers = [];

    armAngles.forEach((ang, idx) => {
      const armGroup = new THREE.Group();
      armGroup.rotation.z = ang;

      const armRodGeo = new THREE.CylinderGeometry(0.008, 0.008, armLength, 8);
      const armRod = new THREE.Mesh(armRodGeo, carbonMat);
      armRod.position.y = armLength / 2;
      armRod.castShadow = true;
      armGroup.add(armRod);

      // Motor bell at tip
      const motorGeo = new THREE.CylinderGeometry(0.018, 0.018, 0.025, 12);
      const motor = new THREE.Mesh(motorGeo, goldMat);
      motor.position.y = armLength;
      motor.rotation.x = Math.PI / 2;
      motor.castShadow = true;
      armGroup.add(motor);

      // Propeller (14" representation)
      const propGroup = new THREE.Group();
      propGroup.position.set(0, armLength, 0.02);

      const bladeGeo = new THREE.BoxGeometry(0.16, 0.014, 0.002);
      const blade = new THREE.Mesh(bladeGeo, propMat);
      blade.castShadow = true;
      propGroup.add(blade);

      const propCap = new THREE.Mesh(new THREE.ConeGeometry(0.008, 0.015, 8), goldMat);
      propCap.rotation.x = Math.PI / 2;
      propCap.position.z = 0.008;
      propGroup.add(propCap);

      this.droneGroup.add(armGroup);
      this.droneGroup.add(propGroup);

      // Motor direction: 0 & 2 CCW, 1 & 3 CW
      this.propellers.push({
        group: propGroup,
        direction: (idx % 2 === 0) ? 1 : -1,
      });
    });

    // Dual Front LiDAR Sensors (Devos et al. 2018: Garmin LIDAR-Lite v3 mounted at +/-20 deg)
    const lidarGeo = new THREE.BoxGeometry(0.025, 0.02, 0.015);
    const lidarMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7 });

    const leftLidar = new THREE.Mesh(lidarGeo, lidarMat);
    leftLidar.position.set(-0.04, 0.08, 0.0);
    leftLidar.rotation.z = Math.radians ? Math.radians(20) : (20 * Math.PI / 180);
    this.droneGroup.add(leftLidar);

    const rightLidar = new THREE.Mesh(lidarGeo, lidarMat);
    rightLidar.position.set(0.04, 0.08, 0.0);
    rightLidar.rotation.z = Math.radians ? Math.radians(-20) : (-20 * Math.PI / 180);
    this.droneGroup.add(rightLidar);

    // Heading arrow (forward direction)
    const arrowGeo = new THREE.ConeGeometry(0.02, 0.06, 8);
    const arrowMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4 });
    const arrow = new THREE.Mesh(arrowGeo, arrowMat);
    arrow.position.set(0, 0.12, 0.01);
    arrow.rotation.x = Math.PI / 2;
    this.droneGroup.add(arrow);

    this.scene.add(this.droneGroup);
  }

  initTrajectory() {
    const maxPoints = 500;
    this.trajectoryPositions = new Float32Array(maxPoints * 3);
    this.trajectoryColors = new Float32Array(maxPoints * 3);

    this.trajectoryGeo = new THREE.BufferGeometry();
    this.trajectoryGeo.setAttribute('position', new THREE.BufferAttribute(this.trajectoryPositions, 3));
    this.trajectoryGeo.setAttribute('color', new THREE.BufferAttribute(this.trajectoryColors, 3));

    const lineMat = new THREE.LineBasicMaterial({
      vertexColors: true,
      linewidth: 2,
      transparent: true,
      opacity: 0.85,
    });

    this.trajectoryLine = new THREE.Line(this.trajectoryGeo, lineMat);
    this.scene.add(this.trajectoryLine);
    this.trajectoryCount = 0;
  }

  updateTrajectory(history) {
    if (!history || history.length === 0) return;
    const len = Math.min(history.length, 500);

    for (let i = 0; i < len; i++) {
      const pt = history[i];
      this.trajectoryPositions[i * 3] = pt[0];
      this.trajectoryPositions[i * 3 + 1] = pt[1];
      this.trajectoryPositions[i * 3 + 2] = pt[2];

      // Cyan to purple gradient over path
      const alpha = i / len;
      this.trajectoryColors[i * 3] = 0.02 + 0.5 * alpha;     // R
      this.trajectoryColors[i * 3 + 1] = 0.7 + 0.3 * (1 - alpha); // G
      this.trajectoryColors[i * 3 + 2] = 0.85;                // B
    }

    this.trajectoryGeo.setDrawRange(0, len);
    this.trajectoryGeo.attributes.position.needsUpdate = true;
    this.trajectoryGeo.attributes.color.needsUpdate = true;
  }

  syncObstacles(obstacleList) {
    if (!obstacleList) return;
    const currentIds = new Set(obstacleList.map(o => o.id));

    // Remove obsolete
    for (const [id, mesh] of this.obstacleMeshes.entries()) {
      if (!currentIds.has(id)) {
        this.scene.remove(mesh);
        this.obstacleMeshes.delete(id);
      }
    }

    // Add or update
    obstacleList.forEach(obs => {
      let mesh = this.obstacleMeshes.get(obs.id);
      if (!mesh) {
        mesh = this.createObstacleMesh(obs);
        this.scene.add(mesh);
        this.obstacleMeshes.set(obs.id, mesh);
      }

      // Update position
      mesh.position.set(obs.x, obs.y, obs.z);
      if (obs.yaw !== undefined) {
        mesh.rotation.z = obs.yaw;
      }
    });
  }

  createObstacleMesh(obs) {
    if (obs.type === 'cylinder') {
      const geo = new THREE.CylinderGeometry(obs.radius, obs.radius, obs.height, 24);
      const mat = new THREE.MeshStandardMaterial({
        color: 0xf59e0b,
        roughness: 0.4,
        metalness: 0.3,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.rotation.x = Math.PI / 2; // Z-up in three.js coordinate convention
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      return mesh;
    } else {
      // Box or moving box
      const geo = new THREE.BoxGeometry(obs.sx, obs.sy, obs.sz);
      const mat = new THREE.MeshStandardMaterial({
        color: obs.type === 'moving_box' ? 0xef4444 : 0x475569,
        roughness: 0.5,
        metalness: 0.2,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      return mesh;
    }
  }

  updateSensors(sensorData, droneX, droneY, droneZ) {
    if (!sensorData) return;

    // Laser rays for dual front LiDARs and key directions
    const rayKeys = ['lidar_left', 'lidar_right', 'FORWARD', 'LEFT', 'RIGHT', 'BACKWARD', 'UP', 'DOWN'];

    rayKeys.forEach(key => {
      const reading = sensorData[key];
      if (!reading) return;

      let line = this.laserLines.get(key);
      if (!line) {
        const geo = new THREE.BufferGeometry();
        const pos = new Float32Array(6);
        geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        const mat = new THREE.LineBasicMaterial({
          color: 0x10b981,
          linewidth: 2,
          transparent: true,
          opacity: 0.65,
        });
        line = new THREE.Line(geo, mat);
        this.scene.add(line);
        this.laserLines.set(key, line);
      }

      const hit = reading.hit_point || [
        droneX + Math.cos(this.droneGroup.rotation.z + (reading.relative_angle_deg * Math.PI / 180)) * reading.distance,
        droneY + Math.sin(this.droneGroup.rotation.z + (reading.relative_angle_deg * Math.PI / 180)) * reading.distance,
        droneZ
      ];

      const posAttr = line.geometry.attributes.position;
      posAttr.setXYZ(0, droneX, droneY, droneZ);
      posAttr.setXYZ(1, hit[0], hit[1], hit[2]);
      posAttr.needsUpdate = true;

      // Color coding based on distance
      if (reading.distance <= 0.23) {
        line.material.color.setHex(0xef4444); // Danger Red
        line.material.opacity = 0.95;
      } else if (reading.distance <= 0.50) {
        line.material.color.setHex(0xf59e0b); // Warning Amber
        line.material.opacity = 0.8;
      } else {
        line.material.color.setHex(0x10b981); // Safe Green
        line.material.opacity = 0.35;
      }
    });
  }

  updateDroneState(state, flightStatus) {
    if (!state) return;

    // Update drone pose
    this.droneGroup.position.set(state.x, state.y, state.z);
    this.droneGroup.rotation.set(state.roll * (Math.PI / 180), state.pitch * (Math.PI / 180), state.yaw_rad || 0);

    // Update status LED
    if (this.statusLedMat) {
      if (flightStatus === 'COLLISION') {
        this.statusLedMat.color.setHex(0xef4444);
      } else if (flightStatus === 'WAITING_FOR_USER') {
        this.statusLedMat.color.setHex(0xf59e0b);
      } else if (flightStatus === 'CRUISING' || flightStatus === 'EXECUTING_AVOIDANCE') {
        this.statusLedMat.color.setHex(0x06b6d4);
      } else {
        this.statusLedMat.color.setHex(0x10b981);
      }
    }

    // Spin propellers
    const rpm = state.speed > 0.01 ? 40 : 15;
    this.propellers.forEach(p => {
      p.group.rotation.z += p.direction * rpm * 0.016;
    });

    // Camera following
    this.updateCamera(state);
  }

  setCameraMode(mode) {
    this.cameraMode = mode;
  }

  updateCamera(droneState) {
    if (this.cameraMode === 'chase') {
      const yaw = droneState.yaw_rad || 0;
      const dist = 2.4;
      const height = 1.2;
      const targetCamX = droneState.x - Math.cos(yaw) * dist;
      const targetCamY = droneState.y - Math.sin(yaw) * dist;
      const targetCamZ = droneState.z + height;

      this.camera.position.lerp(new THREE.Vector3(targetCamX, targetCamY, targetCamZ), 0.08);
      this.camera.lookAt(droneState.x, droneState.y, droneState.z + 0.2);
    } else if (this.cameraMode === 'top') {
      this.camera.position.set(droneState.x, droneState.y, 7.5);
      this.camera.lookAt(droneState.x, droneState.y, 0);
    } else if (this.cameraMode === 'fpv') {
      const yaw = droneState.yaw_rad || 0;
      this.camera.position.set(droneState.x, droneState.y, droneState.z + 0.05);
      const lookDist = 5.0;
      this.camera.lookAt(
        droneState.x + Math.cos(yaw) * lookDist,
        droneState.y + Math.sin(yaw) * lookDist,
        droneState.z + 0.05
      );
    } else if (this.cameraMode === 'orbit') {
      if (this.controls) this.controls.update();
    }
  }

  onWindowResize() {
    this.width = this.container.clientWidth;
    this.height = this.container.clientHeight;
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(this.width, this.height);
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    this.renderer.render(this.scene, this.camera);
  }
}
