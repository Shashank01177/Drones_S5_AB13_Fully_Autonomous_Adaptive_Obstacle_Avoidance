"""6-DOF Quadcopter Flight Dynamics and Physics Simulation.

Simulates rigid-body quadcopter dynamics including:
- 3D translational and rotational dynamics (Roll, Pitch, Yaw).
- Closed-loop PID attitude and altitude stabilization (Pixhawk / ArduPilot / MultiWii model).
- Rotor thrust and drag forces.
- Collision detection against 3D obstacles with paper drone width Ld = 0.34m.
- Trajectory tracking and breadcrumb history.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional
import numpy as np
from sensors.lidar_sensor import ObstacleType, CircleObstacle, BoxObstacle, MovingObstacle


@dataclass
class DroneState:
    x: float = 0.0
    y: float = 0.0
    z: float = 1.0  # Initial hover altitude (1.0 meter)
    vx: float = 0.0
    vy: float = 0.0
    vz: float = 0.0
    roll: float = 0.0
    pitch: float = 0.0
    yaw: float = 0.0
    p: float = 0.0  # Roll rate
    q: float = 0.0  # Pitch rate
    r: float = 0.0  # Yaw rate
    motor_speeds: Tuple[float, float, float, float] = (1000.0, 1000.0, 1000.0, 1000.0)
    has_collided: bool = False
    collision_object_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        speed = math.sqrt(self.vx * self.vx + self.vy * self.vy + self.vz * self.vz)
        return {
            "x": round(self.x, 3),
            "y": round(self.y, 3),
            "z": round(self.z, 3),
            "vx": round(self.vx, 3),
            "vy": round(self.vy, 3),
            "vz": round(self.vz, 3),
            "speed": round(speed, 3),
            "roll": round(math.degrees(self.roll), 2),
            "pitch": round(math.degrees(self.pitch), 2),
            "yaw": round(math.degrees(self.yaw), 2),
            "yaw_rad": round(self.yaw, 4),
            "p": round(self.p, 3),
            "q": round(self.q, 3),
            "r": round(self.r, 3),
            "motor_speeds": [round(m, 1) for m in self.motor_speeds],
            "has_collided": self.has_collided,
            "collision_object_id": self.collision_object_id,
        }


class DronePhysics:
    """Rigid-body quadcopter dynamics and stabilization controller."""

    def __init__(
        self,
        drone_width: float = 0.34,  # Ld from paper (34 cm)
        mass_kg: float = 1.25,      # Tarot 650 with battery
        nominal_speed: float = 0.22, # Tuned for responsive real-time visualization & smooth evasion
    ) -> None:
        self.drone_width = drone_width
        self.drone_radius = drone_width / 2.0  # 0.17 m
        self.mass = mass_kg
        self.nominal_speed = nominal_speed
        self.gravity = 9.81

        self.state = DroneState()
        self.trajectory_history: List[Tuple[float, float, float]] = []
        self.max_trajectory_points = 500

        # PID controller gains for velocity and attitude tracking
        self.kp_vel = 2.5
        self.kd_vel = 1.2
        self.kp_att = 6.0
        self.kd_att = 2.0
        self.kp_z = 3.0
        self.kd_z = 1.8

        # Target command states
        self.cmd_vx_body = 0.0
        self.cmd_vy_body = 0.0
        self.cmd_vz = 0.0
        self.cmd_yaw_rate = 0.0

        # Linear drag coefficient
        self.drag_coeff = 0.35

    def reset(self, x: float = 0.0, y: float = 0.0, z: float = 1.0, yaw: float = 0.0) -> None:
        self.state = DroneState(x=x, y=y, z=z, yaw=yaw)
        self.cmd_vx_body = 0.0
        self.cmd_vy_body = 0.0
        self.cmd_vz = 0.0
        self.cmd_yaw_rate = 0.0
        self.trajectory_history = [(x, y, z)]

    def set_directional_velocity(self, direction_name: str, speed_scale: float = 1.0) -> None:
        """Sets body-frame target velocity and yaw rate for realistic 3D evasion."""
        speed = self.nominal_speed * speed_scale
        diag_speed = speed * 0.7071

        # Body-frame: (Vx_fwd, Vy_left, Vz_up, Yaw_rate_rad_s)
        # Quadcopter banks for lateral evasion with gentle yaw steering
        mapping = {
            "FORWARD": (speed, 0.0, 0.0, 0.0),
            "BACKWARD": (-speed * 0.85, 0.0, 0.0, 0.0),
            "LEFT": (speed * 0.45, speed * 1.2, 0.0, 0.35),
            "RIGHT": (speed * 0.45, -speed * 1.2, 0.0, -0.35),
            "UP": (speed * 0.5, 0.0, speed * 1.4, 0.0),
            "DOWN": (speed * 0.5, 0.0, -speed * 1.4, 0.0),
            "FORWARD_LEFT": (speed * 0.85, speed * 0.7, 0.0, 0.2),
            "FORWARD_RIGHT": (speed * 0.85, -speed * 0.7, 0.0, -0.2),
            "BACKWARD_LEFT": (-diag_speed, diag_speed, 0.0, 0.2),
            "BACKWARD_RIGHT": (-diag_speed, -diag_speed, 0.0, -0.2),
            "HOVER": (0.0, 0.0, 0.0, 0.0),
            "STOP": (0.0, 0.0, 0.0, 0.0),
        }

        cmd = mapping.get(direction_name, (0.0, 0.0, 0.0, 0.0))
        self.cmd_vx_body = cmd[0]
        self.cmd_vy_body = cmd[1]
        self.cmd_vz = cmd[2]
        self.cmd_yaw_rate = cmd[3]

    def set_autonomous_control(self, forward_speed: float, yaw_rate: float) -> None:
        """Applies neural controller commands (forward velocity + yaw rate)."""
        self.cmd_vx_body = forward_speed
        self.cmd_vy_body = 0.0
        self.cmd_vz = 0.0
        self.cmd_yaw_rate = yaw_rate

    def set_manual_control(self, vx: float, vy: float, vz: float, yaw_rate: float) -> None:
        """Applies continuous manual flight inputs (pitch, roll, climb, yaw)."""
        self.cmd_vx_body = float(np.clip(vx, -0.8, 0.8))
        self.cmd_vy_body = float(np.clip(vy, -0.8, 0.8))
        self.cmd_vz = float(np.clip(vz, -0.6, 0.6))
        self.cmd_yaw_rate = float(np.clip(yaw_rate, -1.8, 1.8))

    def check_collision(self, obstacles: List[ObstacleType], arena_size: float = 10.0) -> Tuple[bool, Optional[str]]:
        """Evaluates whether the drone's physical radius collides with any object."""
        px, py, pz = self.state.x, self.state.y, self.state.z
        r = self.drone_radius  # 0.17 m

        # Check ground plane and ceiling
        if pz <= 0.08:
            return True, "ground"
        if pz >= 3.9:
            return True, "ceiling"

        # Check arena boundaries
        half = arena_size / 2.0
        if abs(px) >= half - r or abs(py) >= half - r:
            return True, "boundary_wall"

        # Check obstacles
        for obs in obstacles:
            if isinstance(obs, CircleObstacle):
                # Check height overlap
                if obs.z_base <= pz <= obs.z_base + obs.height:
                    dx = px - obs.x
                    dy = py - obs.y
                    dist_sq = dx * dx + dy * dy
                    min_dist = obs.radius + r
                    if dist_sq <= min_dist * min_dist:
                        return True, obs.id
            elif isinstance(obs, (BoxObstacle, MovingObstacle)):
                # Check Z overlap
                if abs(pz - obs.z) <= (obs.sz / 2.0 + 0.08):
                    # Local coordinates
                    c = math.cos(-obs.yaw)
                    s = math.sin(-obs.yaw)
                    dx = px - obs.x
                    dy = py - obs.y
                    lx = c * dx - s * dy
                    ly = s * dx + c * dy
                    if (abs(lx) <= obs.sx / 2.0 + r) and (abs(ly) <= obs.sy / 2.0 + r):
                        return True, obs.id

        return False, None

    def step(self, dt: float, obstacles: List[ObstacleType], arena_size: float = 10.0) -> DroneState:
        """Integrates 6-DOF physics over time interval dt."""
        if self.state.has_collided:
            return self.state

        # Update dynamic obstacles first
        for obs in obstacles:
            if isinstance(obs, MovingObstacle):
                obs.update(dt)

        # 1. Transform body target velocities to world frame
        yaw = self.state.yaw
        cos_y = math.cos(yaw)
        sin_y = math.sin(yaw)

        # Body to world transformation:
        # Vx_world = cos(yaw) * Vx_body - sin(yaw) * Vy_body
        # Vy_world = sin(yaw) * Vx_body + cos(yaw) * Vy_body
        cmd_vx_world = cos_y * self.cmd_vx_body - sin_y * self.cmd_vy_body
        cmd_vy_world = sin_y * self.cmd_vx_body + cos_y * self.cmd_vy_body

        # 2. Closed-loop acceleration with drag and inertia
        ax = self.kp_vel * (cmd_vx_world - self.state.vx) - self.drag_coeff * self.state.vx
        ay = self.kp_vel * (cmd_vy_world - self.state.vy) - self.drag_coeff * self.state.vy
        az = self.kp_z * (self.cmd_vz - self.state.vz) - self.drag_coeff * self.state.vz

        # Integrate velocity
        self.state.vx += ax * dt
        self.state.vy += ay * dt
        self.state.vz += az * dt

        # Integrate position
        self.state.x += self.state.vx * dt
        self.state.y += self.state.vy * dt
        self.state.z += self.state.vz * dt

        # Altitude clamping (keep above ground)
        if self.state.z < 0.1:
            self.state.z = 0.1
            self.state.vz = 0.0

        # 3. Attitude dynamics (Roll and Pitch tilt to create horizontal force)
        # In a quadcopter, forward accel requires pitch tilt, lateral accel requires roll tilt
        target_pitch = float(np.clip(-self.cmd_vx_body * 1.5, -math.radians(25), math.radians(25)))
        target_roll = float(np.clip(self.cmd_vy_body * 1.5, -math.radians(25), math.radians(25)))

        self.state.pitch += (target_pitch - self.state.pitch) * min(1.0, self.kp_att * dt)
        self.state.roll += (target_roll - self.state.roll) * min(1.0, self.kp_att * dt)

        # Yaw rate integration
        self.state.yaw += self.cmd_yaw_rate * dt
        # Normalize yaw to [-pi, pi]
        self.state.yaw = (self.state.yaw + math.pi) % (2.0 * math.pi) - math.pi

        # Rotor speed visualization model (nominal 1000 RPM modulated by thrust and torques)
        base_rpm = 1000.0 + self.state.vz * 200.0
        pitch_diff = self.state.pitch * 250.0
        roll_diff = self.state.roll * 250.0
        yaw_diff = self.cmd_yaw_rate * 150.0

        m1 = base_rpm + pitch_diff - roll_diff - yaw_diff
        m2 = base_rpm - pitch_diff - roll_diff + yaw_diff
        m3 = base_rpm - pitch_diff + roll_diff - yaw_diff
        m4 = base_rpm + pitch_diff + roll_diff + yaw_diff
        self.state.motor_speeds = (m1, m2, m3, m4)

        # Record trajectory
        if len(self.trajectory_history) == 0 or np.linalg.norm(
            np.array([self.state.x, self.state.y, self.state.z]) - np.array(self.trajectory_history[-1])
        ) > 0.05:
            self.trajectory_history.append((self.state.x, self.state.y, self.state.z))
            if len(self.trajectory_history) > self.max_trajectory_points:
                self.trajectory_history.pop(0)

        # 4. Collision check
        collided, obs_id = self.check_collision(obstacles, arena_size)
        if collided:
            self.state.has_collided = True
            self.state.collision_object_id = obs_id
            self.state.vx = 0.0
            self.state.vy = 0.0
            self.state.vz = 0.0

        return self.state
