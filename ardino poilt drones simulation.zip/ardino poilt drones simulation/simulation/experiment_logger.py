"""Experiment Logging and Evaluation System.

Records every simulation trial, user decision event, telemetry history,
and evaluation metrics. Supports instant export to CSV and JSON formats.
"""

from __future__ import annotations

import csv
import io
import json
import os
import time
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Optional, Tuple


@dataclass
class ExperimentTrialRecord:
    trial_id: str
    scenario_id: str
    scenario_name: str
    timestamp: float
    initial_pos: Tuple[float, float, float]
    trigger_sensor: str
    trigger_distance_m: float
    sensor_snapshot: Dict[str, float]
    available_directions: List[str]
    user_selected_direction: str
    executed_maneuver: str
    override_applied: bool
    final_pos: Tuple[float, float, float]
    has_collided: bool
    collision_object: Optional[str]
    response_time_sec: float
    avoidance_duration_sec: float
    min_clearance_m: float
    result_status: str  # SUCCESS, COLLISION, TIMEOUT, HELD

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trial_id": self.trial_id,
            "scenario_id": self.scenario_id,
            "scenario_name": self.scenario_name,
            "timestamp": round(self.timestamp, 2),
            "initial_pos": [round(p, 3) for p in self.initial_pos],
            "trigger_sensor": self.trigger_sensor,
            "trigger_distance_m": round(self.trigger_distance_m, 3),
            "sensor_snapshot": {k: round(v, 3) for k, v in self.sensor_snapshot.items()},
            "available_directions": self.available_directions,
            "user_selected_direction": self.user_selected_direction,
            "executed_maneuver": self.executed_maneuver,
            "override_applied": self.override_applied,
            "final_pos": [round(p, 3) for p in self.final_pos],
            "has_collided": self.has_collided,
            "collision_object": self.collision_object or "none",
            "response_time_sec": round(self.response_time_sec, 2),
            "avoidance_duration_sec": round(self.avoidance_duration_sec, 2),
            "min_clearance_m": round(self.min_clearance_m, 3),
            "result_status": self.result_status,
        }


class ExperimentLogger:
    """Manages trial history, persistence, and metrics computation."""

    def __init__(self, log_dir: str = "logs") -> None:
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)
        self.trials: List[ExperimentTrialRecord] = []

        # Load or seed initial trials if present
        self.json_log_path = os.path.join(self.log_dir, "experiment_history.json")
        self.csv_log_path = os.path.join(self.log_dir, "experiment_history.csv")

    def record_trial(self, trial: ExperimentTrialRecord) -> None:
        self.trials.append(trial)
        self.save_to_disk()

    def get_summary_metrics(self) -> Dict[str, Any]:
        total = len(self.trials)
        if total == 0:
            return {
                "total_trials": 0,
                "successful_avoidances": 0,
                "collisions": 0,
                "success_rate_percent": 0.0,
                "collision_rate_percent": 0.0,
                "avg_response_time_sec": 0.0,
                "avg_min_clearance_m": 0.0,
            }

        successes = sum(1 for t in self.trials if t.result_status == "SUCCESS")
        collisions = sum(1 for t in self.trials if t.has_collided or t.result_status == "COLLISION")
        avg_resp = sum(t.response_time_sec for t in self.trials) / total
        avg_clear = sum(t.min_clearance_m for t in self.trials if t.min_clearance_m < 50.0) / max(1, total)

        return {
            "total_trials": total,
            "successful_avoidances": successes,
            "collisions": collisions,
            "success_rate_percent": round((successes / total) * 100.0, 1),
            "collision_rate_percent": round((collisions / total) * 100.0, 1),
            "avg_response_time_sec": round(avg_resp, 2),
            "avg_min_clearance_m": round(avg_clear, 3),
        }

    def export_json(self) -> str:
        data = {
            "summary": self.get_summary_metrics(),
            "trials": [t.to_dict() for t in self.trials],
        }
        return json.dumps(data, indent=2)

    def export_csv(self) -> str:
        output = io.StringIO()
        fieldnames = [
            "trial_id",
            "scenario_id",
            "scenario_name",
            "timestamp",
            "trigger_sensor",
            "trigger_distance_m",
            "user_selected_direction",
            "executed_maneuver",
            "override_applied",
            "has_collided",
            "collision_object",
            "response_time_sec",
            "avoidance_duration_sec",
            "min_clearance_m",
            "result_status",
        ]
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        for t in self.trials:
            d = t.to_dict()
            writer.writerow({k: d[k] for k in fieldnames})
        return output.getvalue()

    def save_to_disk(self) -> None:
        try:
            with open(self.json_log_path, "w", encoding="utf-8") as f:
                f.write(self.export_json())
            with open(self.csv_log_path, "w", encoding="utf-8") as f:
                f.write(self.export_csv())
        except Exception as e:
            print(f"Error saving logs to disk: {e}")
