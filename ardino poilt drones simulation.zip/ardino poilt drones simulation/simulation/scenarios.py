"""Comprehensive Obstacle Avoidance Scenario Library.

Implements required scenarios:
1. Front Obstacle
2. Right Obstacle
3. Left Obstacle
4. Rear Obstacle
5. Above Obstacle (low ceiling / overhead beam)
6. Below Obstacle (elevated ground platform)
7. Both Sides Flanked (bifurcated obstacle)
8. Front-Left Diagonal
9. Front-Right Diagonal
10. Rear Diagonals (Rear-Left & Rear-Right)
11. Multiple Clustered Obstacles
12. Base Paper Environment 2: Maze with Deadlocks (Devos et al. Fig 5b)
13. Free Open Flight
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Dict, Tuple, Any
from sensors.lidar_sensor import CircleObstacle, BoxObstacle, MovingObstacle, ObstacleType


@dataclass
class ScenarioDefinition:
    id: str
    name: str
    description: str
    initial_drone_pos: Tuple[float, float, float]
    initial_drone_yaw: float
    obstacles: List[ObstacleType]
    arena_size: float = 10.0
    recommended_avoidance: str = "RIGHT"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "initial_drone_pos": [round(x, 2) for x in self.initial_drone_pos],
            "initial_drone_yaw": round(math.degrees(self.initial_drone_yaw), 1),
            "recommended_avoidance": self.recommended_avoidance,
            "obstacle_count": len(self.obstacles),
            "obstacles": [obs.to_dict() for obs in self.obstacles],
        }


def get_all_scenarios() -> Dict[str, ScenarioDefinition]:
    scenarios: Dict[str, ScenarioDefinition] = {}

    # 1. Obstacle Directly Ahead
    scenarios["front_obstacle"] = ScenarioDefinition(
        id="front_obstacle",
        name="Front Obstacle (Direct Ahead)",
        description="A solid cylindrical pillar directly in the forward flight path. Test left or right lateral avoidance.",
        initial_drone_pos=(0.0, -1.8, 1.0),
        initial_drone_yaw=math.radians(90),  # Facing +Y
        obstacles=[
            CircleObstacle(id="pillar_front", x=0.0, y=-0.8, radius=0.25, height=2.2, z_base=0.0),
        ],
        recommended_avoidance="RIGHT",
    )

    # 2. Obstacle on the Right
    scenarios["right_obstacle"] = ScenarioDefinition(
        id="right_obstacle",
        name="Right Flank Obstacle",
        description="A wall barrier on the right side of the drone. Demonstrates leftward avoidance or forward clear flight.",
        initial_drone_pos=(0.0, -1.0, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            BoxObstacle(id="wall_right", x=0.48, y=-0.2, z=1.0, sx=0.20, sy=1.6, sz=2.0, yaw=0.0),
        ],
        recommended_avoidance="LEFT",
    )

    # 3. Obstacle on the Left
    scenarios["left_obstacle"] = ScenarioDefinition(
        id="left_obstacle",
        name="Left Flank Obstacle",
        description="A pillar barrier on the left side. Demonstrates rightward avoidance.",
        initial_drone_pos=(0.0, -1.0, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            BoxObstacle(id="wall_left", x=-0.48, y=-0.2, z=1.0, sx=0.20, sy=1.6, sz=2.0, yaw=0.0),
        ],
        recommended_avoidance="RIGHT",
    )

    # 4. Obstacle Behind
    scenarios["rear_obstacle"] = ScenarioDefinition(
        id="rear_obstacle",
        name="Rear Obstacle (Reverse Threat)",
        description="Obstacle positioned directly behind the quadcopter to test rear sensor detection during reverse flight.",
        initial_drone_pos=(0.0, 0.0, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            BoxObstacle(id="barrier_rear", x=0.0, y=-0.40, z=1.0, sx=1.5, sy=0.3, sz=2.0, yaw=0.0),
        ],
        recommended_avoidance="FORWARD",
    )

    # 5. Obstacle Above (Vertical Avoidance)
    scenarios["above_obstacle"] = ScenarioDefinition(
        id="above_obstacle",
        name="Above Obstacle (Overhead Bridge)",
        description="A low overhead beam located 30 cm above current flight altitude. Demonstrates downward or lateral escape.",
        initial_drone_pos=(0.0, -1.2, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            BoxObstacle(id="overhead_bridge", x=0.0, y=-0.4, z=1.35, sx=3.0, sy=0.8, sz=0.2, yaw=0.0),
        ],
        recommended_avoidance="DOWN",
    )

    # 6. Obstacle Below (Raised Platform)
    scenarios["below_obstacle"] = ScenarioDefinition(
        id="below_obstacle",
        name="Below Obstacle (Raised Platform)",
        description="An elevated ground obstacle directly beneath the flight path. Demonstrates upward vertical climb.",
        initial_drone_pos=(0.0, -1.2, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            BoxObstacle(id="raised_platform", x=0.0, y=-0.4, z=0.4, sx=1.8, sy=1.0, sz=0.6, yaw=0.0),
        ],
        recommended_avoidance="UP",
    )

    # 7. Obstacles on Both Sides (Flanked)
    scenarios["both_sides"] = ScenarioDefinition(
        id="both_sides",
        name="Both Sides Flanked (Lateral Pinch)",
        description="Obstacles flanking both left and right simultaneously. Lateral escape blocked; requires forward, vertical, or reverse.",
        initial_drone_pos=(0.0, 0.0, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            BoxObstacle(id="flank_left", x=-0.44, y=0.0, z=1.0, sx=0.20, sy=1.4, sz=2.0, yaw=0.0),
            BoxObstacle(id="flank_right", x=0.44, y=0.0, z=1.0, sx=0.20, sy=1.4, sz=2.0, yaw=0.0),
        ],
        recommended_avoidance="FORWARD",
    )

    # 8. Front-Left Diagonal
    scenarios["front_left"] = ScenarioDefinition(
        id="front_left",
        name="Front-Left Diagonal Obstacle",
        description="Obstacle positioned 45 degrees ahead to the left. Test front-right or rightward turn response.",
        initial_drone_pos=(0.0, -1.5, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            CircleObstacle(id="pillar_fl", x=-0.35, y=-0.7, radius=0.24, height=2.0, z_base=0.0),
        ],
        recommended_avoidance="FORWARD_RIGHT",
    )

    # 9. Front-Right Diagonal
    scenarios["front_right"] = ScenarioDefinition(
        id="front_right",
        name="Front-Right Diagonal Obstacle",
        description="Obstacle positioned 45 degrees ahead to the right. Test front-left or leftward turn response.",
        initial_drone_pos=(0.0, -1.5, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            CircleObstacle(id="pillar_fr", x=0.35, y=-0.7, radius=0.24, height=2.0, z_base=0.0),
        ],
        recommended_avoidance="FORWARD_LEFT",
    )

    # 10. Rear Diagonals
    scenarios["rear_diagonal"] = ScenarioDefinition(
        id="rear_diagonal",
        name="Rear Diagonal Obstacles",
        description="Barriers placed at rear-left and rear-right quadrants.",
        initial_drone_pos=(0.0, 0.0, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            CircleObstacle(id="pillar_rl", x=-0.40, y=-0.35, radius=0.22, height=2.0, z_base=0.0),
            CircleObstacle(id="pillar_rr", x=0.40, y=-0.35, radius=0.22, height=2.0, z_base=0.0),
        ],
        recommended_avoidance="FORWARD",
    )

    # 11. Multiple Clustered Obstacles
    scenarios["multiple_obstacles"] = ScenarioDefinition(
        id="multiple_obstacles",
        name="Multiple Clustered Obstacles (Dense Field)",
        description="Dense field of pillars and boxes evaluating multi-direction spatial awareness and safe path selection.",
        initial_drone_pos=(0.0, -1.8, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            CircleObstacle(id="clust_1", x=-0.9, y=-1.3, radius=0.22, height=2.0),
            CircleObstacle(id="clust_2", x=0.0, y=-0.9, radius=0.22, height=2.0),
            CircleObstacle(id="clust_3", x=0.9, y=-1.3, radius=0.22, height=2.0),
            CircleObstacle(id="clust_4", x=-1.2, y=0.3, radius=0.22, height=2.0),
            CircleObstacle(id="clust_5", x=0.7, y=0.2, radius=0.25, height=2.0),
            BoxObstacle(id="box_clust_1", x=-0.3, y=1.2, z=1.0, sx=0.6, sy=0.6, sz=2.0),
            BoxObstacle(id="box_clust_2", x=1.1, y=1.5, z=1.0, sx=0.5, sy=0.8, sz=2.0),
        ],
        recommended_avoidance="RIGHT",
    )

    # 15. Base Paper Environment 2: Complex Maze & Deadlocks (Figure 5b from Devos et al. 2018)
    scenarios["paper_env2_maze"] = ScenarioDefinition(
        id="paper_env2_maze",
        name="Base Paper Env 2: Maze & Deadlocks (Devos 2018)",
        description="Reconstruction of Environment 2 from Figure 5(b) of Devos et al. (2018): Sharp corners, tight walls, and deadlocks.",
        initial_drone_pos=(0.0, 1.2, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[
            BoxObstacle("m1", -4.9, 1.2, 1.0, 0.32, 6.7, 2.0, math.radians(90)),
            BoxObstacle("m2", -2.95, 3.85, 1.0, 0.38, 1.9, 2.0, 0.0),
            BoxObstacle("m3", -3.05, -1.3, 1.0, 0.38, 3.0, 2.0, 0.0),
            BoxObstacle("m4", -0.55, -2.45, 1.0, 0.40, 6.2, 2.0, math.radians(90)),
            BoxObstacle("m5", 1.45, 0.2, 1.0, 0.42, 3.1, 2.0, 0.0),
            BoxObstacle("m6", 4.35, 1.2, 1.0, 0.38, 1.8, 2.0, math.radians(90)),
            BoxObstacle("m7", -0.95, 2.85, 1.0, 0.75, 0.75, 2.0, math.radians(20)),
            BoxObstacle("m8", 3.85, 3.75, 1.0, 0.78, 0.78, 2.0, math.radians(20)),
            BoxObstacle("m9", -4.55, -3.95, 1.0, 0.38, 1.35, 2.0, math.radians(30)),
            BoxObstacle("m10", -1.85, -4.2, 1.0, 0.75, 0.75, 2.0, 0.0),
            BoxObstacle("m11", 1.1, -4.05, 1.0, 0.65, 0.8, 2.0, math.radians(18)),
        ],
        recommended_avoidance="LEFT",
    )

    # 16. Clear Flight
    scenarios["clear_flight"] = ScenarioDefinition(
        id="clear_flight",
        name="Clear Flight (No Obstacles)",
        description="Empty flight test arena without obstacles. Used to verify baseline flight dynamics, hover, and keyboard controls.",
        initial_drone_pos=(0.0, 0.0, 1.0),
        initial_drone_yaw=math.radians(90),
        obstacles=[],
        recommended_avoidance="FORWARD",
    )

    return scenarios
