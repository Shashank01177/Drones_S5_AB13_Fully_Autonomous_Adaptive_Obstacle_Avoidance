# AERODRONE AI — Interactive Arduino Quadcopter Obstacle Avoidance Simulation

A high-fidelity, interactive 3D simulation and telemetry dashboard of an Arduino-controlled quadcopter navigating unknown obstacle-dense environments.

This simulation implements the methodology, equations, and adaptive neural control architecture from:
> **Base Paper:**  
> Arne Devos, Emad Ebeid, Poramate Manoonpong (2018), *"Development of Autonomous Drones for Adaptive Obstacle Avoidance in Real World Environments"*, IEEE 21st Euromicro Conference on Digital System Design (DSD), pp. 707–710.  
> DOI: [10.1109/DSD.2018.00114](https://ieeexplore.ieee.org/document/8491889)

---

## 1. Key Features

- **Base Paper Dual LiDAR Sensor Model:** Front-mounted dual LiDARs oriented at $\pm 20^\circ$ ($\Theta = 40^\circ$), sensing range $L_s = 50\text{ cm}$, safety margin $L_m = 6\text{ cm}$, and drone width $L_d = 34\text{ cm}$.
- **Adaptive Neural Controller (RNN):** 2-neuron discrete-time recurrent network with self-excitatory synapses ($b_1, b_2$), mutual inhibitory coupling ($q_1, q_2$), and online correlation synaptic plasticity with homeostatic scaling.
- **Human-in-the-Loop (HITL) Decision Workflow:** Automatically detects obstacles within $50\text{ cm}$, halts forward progression, engages a safe hover state, displays a clear warning HUD with safety status for all 10 candidate directions, and waits for user decision before maneuvering.
- **Research Override Mode:** Toggleable research switch allowing users to deliberately test unsafe decisions to study collision geometry and impact telemetry.
- **Interactive Direction Controls:** 10 flight directions (Forward, Backward, Left, Right, Up, Down, Front-Left, Front-Right, Rear-Left, Rear-Right) + Hover + Emergency Stop via UI buttons and keyboard hotkeys.
- **16 Rich Obstacle Scenarios:** Including Front, Right, Left, Behind, Overhead Ceiling, Ground Pedestal, Lateral Flanking, Diagonals, Narrow Corridor, Dense Cluster, Moving Obstacle, and full reconstructions of Base Paper Environment 1 (Circles room) and Environment 2 (Maze with deadlocks).
- **3D Three.js WebGL Visualization:** Real-time 3D model with spinning rotors, carbon fiber X-frame, dynamic laser beams with distance color-coding, trajectory ribbon, and 4 camera modes (Chase, Free Orbit, Tactical Top-Down, FPV Nose Cam).
- **Full Arduino Integration:** Complete Arduino C++ firmware (`arduino_flight_controller.ino`) for Arduino Mega/Uno/ESP32, cascaded PID attitude/altitude stabilization, HC-SR04/Garmin LiDAR sampling, and a serial bridge supporting SITL (Software-in-the-Loop) and HITL (Hardware-in-the-Loop).
- **Experiment Logging & Analytics:** Automatic logging of trial metrics (response time, min clearance, collision status, duration) with one-click export to CSV and JSON.

---

## 2. Mathematical Equations from Base Paper

### 2.1 Minimum Detectable Obstacle Width
$$W_{\text{obj}} \ge 2 \tan\left(\frac{\Theta}{2}\right) \left(L_x + \frac{L_d}{2}\right)$$
For $\Theta = 40^\circ$, $L_x = 0.15\text{ m}$, $L_d = 0.34\text{ m}$:
$$W_{\text{obj}} \ge 2 \times \tan(20^\circ) \times (0.15 + 0.17) = 2 \times 0.36397 \times 0.32 \approx 0.233\text{ m} \approx 24\text{ cm}$$

### 2.2 Distance Normalization
$$S_i = \text{clip}\left( \frac{2 \times (d_{\text{max}} - d_i)}{d_{\text{max}} - d_{\text{min}}} - 1.0, -1.0, 1.0 \right)$$
where $d_{\text{max}} = 0.50\text{ m}$, $d_{\text{min}} = 0.15\text{ m}$.

### 2.3 Recurrent Neural Network
$$\begin{aligned}
O_1(t) &= \tanh\left( b_1(t) O_1(t-1) + c(t) O_2(t-1) + I_g S_L(t) \right) \\
O_2(t) &= \tanh\left( b_2(t) O_2(t-1) + c(t) O_1(t-1) + I_g S_R(t) \right)
\end{aligned}$$
where $c(t) = -0.5(q_1(t) + q_2(t))$, input gain $I_g = 4.7$.

### 2.4 Correlation Synaptic Plasticity
$$\Delta b_i(t) = \kappa \cdot \Delta t \left[ \mu_b \cdot v_i(t-1) \cdot v_i(t) \cdot \text{reflex}_i(t) + \gamma_b \cdot (k - v_i(t)) \cdot b_i(t)^2 \right]$$
$$\Delta q_i(t) = \kappa \cdot \Delta t \left[ \mu_q \cdot v_i(t-1) \cdot v_i(t) \cdot \text{reflex}_i(t) + \gamma_q \cdot (k - v_i(t)) \cdot q_i(t)^2 \right]$$

### 2.5 Yaw Steering Command
$$\text{steering}(t) = 0.5 (O_1(t) - O_2(t))$$
$$\dot{\psi}_{\text{cmd}}(t) = k_{\text{turn}} \cdot \text{steering}(t) \quad (k_{\text{turn}} = 1.35\text{ rad/s})$$

---

## 3. Directory Layout

```
arduino_quadcopter_simulation/
├── README.md                          # Documentation and user manual
├── METHODOLOGY.md                     # Base paper mathematical analysis
├── requirements.txt                   # Python dependencies
├── main.py                            # Async server (aiohttp + WebSocket)
├── simulation/
│   ├── drone_physics.py               # 6-DOF flight dynamics & collision check
│   ├── scenarios.py                   # 16 obstacle avoidance scenarios
│   └── experiment_logger.py           # Logging and CSV/JSON exporter
├── avoidance/
│   ├── neural_controller.py           # Devos et al. 2-neuron RNN + plasticity
│   └── decision_engine.py             # Direction safety evaluator & HITL FSM
├── sensors/
│   └── lidar_sensor.py                # Dual front LiDAR + 3D raycasting
├── dashboard/
│   ├── index.html                     # 3D Cyber Telemetry Web Dashboard
│   ├── css/style.css                  # Aerospace glassmorphism stylesheet
│   └── js/
│       ├── three_sim.js               # Three.js 3D quadcopter renderer
│       ├── app.js                     # Bidirectional WS telemetry client
│       └── vendor/                    # Offline copies of Three.js & Controls
├── arduino/
│   ├── arduino_flight_controller.ino  # Full C++ firmware for Arduino
│   ├── serial_bridge.py               # Hardware-in-the-loop serial bridge
│   └── README.md                      # Wiring pinouts and serial protocol
├── logs/                              # CSV and JSON trial logs
└── tests/                             # Automated pytest unit test suite
```

---

## 4. Quick Start & Launch Instructions

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run Automated Tests
```bash
python -m pytest tests/
```

### Step 3: Start Simulation Server
```bash
python main.py
```

### Step 4: Open Interactive Web Dashboard
Navigate your web browser to:
```
http://localhost:8080
```

---

## 5. Keyboard Control Reference

| Key | Action | Context |
| :---: | :---: | :--- |
| **`W`** | Forward | Move forward / Select Forward avoidance |
| **`S`** | Backward | Move reverse / Select Backward avoidance |
| **`A`** | Left | Strafe left / Select Left avoidance |
| **`D`** | Right | Strafe right / Select Right avoidance |
| **`R`** | Climb (Up) | Increase altitude / Vertical climb |
| **`F`** | Descend (Down) | Decrease altitude / Vertical descent |
| **`Q`** | Forward-Left | 45° diagonal escape |
| **`E`** | Forward-Right | 45° diagonal escape |
| **`Z`** | Rear-Left | 135° diagonal escape |
| **`C`** | Rear-Right | 135° diagonal escape |
| **`SPACE`** | Start / Pause / Hover | Start trial, pause cruise, or command safe hover |
| **`ENTER`** | Confirm Optimal | Confirms base-paper recommended avoidance direction |
| **`ESC`** | Emergency Stop | Halts all motors immediately |

*Note: Keyboard hotkeys automatically deactivate when typing in dropdowns or form fields.*
