#!/usr/bin/env python3
"""
Launcher for Interactive Drone Mission Planner & Live Autonomous Flight.
Supports:
  1st: Give STARTING PLACE
  2nd: Give END PLACE
  3rd: Give SINGLE STICK OBSTACLE PLACE

Features:
1. Bounded Rectangular Arena (X: -1.5m to 13.5m, Y: -2.5m to 2.5m) — Drone cannot exit.
2. ONLY ONE Single Thin Stick Obstacle (radius 0.04m, height 2.6m) on the flight path.
3. IEEE 8491889 Adaptive Neural Controller with online plasticity and speed braking.
4. Photorealistic nature landscape with rolling mountains, blue sky, and F450 quadrotor.
5. 10-Second Touchdown Hold at destination with option to START NEW FLIGHT AGAIN.
"""

import os
import sys
import argparse

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.park_mission_planner import launch_planner


def parse_coord(s):
    if not s:
        return None
    raw = s.replace(",", " ").split()
    return (float(raw[0]), float(raw[1]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Autonomous Drone Mission Commander (IEEE 8491889)")
    parser.add_argument("--start", type=str, default=None, help="1st Starting coordinates 'X, Y' (e.g. '0.0, 0.0')")
    parser.add_argument("--end", "--goal", dest="end", type=str, default=None, help="2nd End coordinates 'X, Y' (e.g. '12.0, 0.0')")
    parser.add_argument("--stick", "--obs", dest="stick", type=str, default=None, help="3rd Stick Obstacle 'X, Y' (e.g. '5.0, 0.0')")
    parser.add_argument("--speed", type=float, default=0.10, help="Initial forward cruise speed in range 0.001 to 1.0 m/s (e.g. 0.001, 0.01, 0.1, 0.5, 1.0 m/s)")
    parser.add_argument("--direct", "--instant", "--auto", action="store_true", help="Instantly launch the 3D MuJoCo window directly without clicking")
    args = parser.parse_args()

    s_pt = parse_coord(args.start)
    e_pt = parse_coord(args.end)
    st_pt = parse_coord(args.stick)

    print("\n" + "=" * 80)
    print("   [MISSION] AUTONOMOUS DRONE FLIGHT COMMANDER (IEEE 8491889)")
    print("=" * 80)
    print("  Input Sequence:")
    print("    1st: Choose STARTING PLACE (White helipad on ground)")
    print("    2nd: Choose END PLACE (Light Red helipad on ground)")
    print("    3rd: Place OBSTACLES AS YOUR WISH (slender stick poles)")
    print(f"  Speed: Configurable starting speed (Current: {args.speed:.3f} m/s, range 0.001 to 1.0 m/s)")
    print("  Arena Bounds: 3D Earth Box X: [-1.5, 13.5]m | Y: [-2.5, 2.5]m | Z: 2.8m (Drone confined)")
    print("  Sensors: 5-LiDAR Sensor Suite (80° Panoramic: Far-Left, Mid-Left, Center, Mid-Right, Far-Right)")
    print("  Destination: Lands on ground, shuts off motors, and speaks 'Task finished'")
    print("=" * 80 + "\n")
    launch_planner(start=s_pt, goal=e_pt, stick=st_pt, speed=args.speed, auto_launch=args.direct)
