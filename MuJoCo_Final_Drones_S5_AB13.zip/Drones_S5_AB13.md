# Drones_S5_AB13: Autonomous Drone with Adaptive Neural Control & 5-LiDAR Collision Evasion

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Physics](https://img.shields.io/badge/Physics-MuJoCo%203.2%2B-brightgreen.svg)](https://mujoco.org/)
[![IEEE Paper](https://img.shields.io/badge/IEEE-8491889-orange.svg)](https://ieeexplore.ieee.org/document/8491889)
[![Tests](https://img.shields.io/badge/Tests-13%2F13%20Passing-success.svg)](test_simulation.py)

**Course / Project Identifier:** `Drones_S5_AB13`  
**Core Reference:** IEEE 8491889 — *Development of Autonomous Drones for Adaptive Obstacle Avoidance in Real World Environments* (Devos, Ebeid, Manoonpong 2018).

---

## Table of Contents
1. [Project Overview & Key Contributions](#1-project-overview--key-contributions)
2. [Physical Drone Architecture & Blueprint](#2-physical-drone-architecture--blueprint)
3. [5-LiDAR Sensor Array Architecture](#3-5-lidar-sensor-array-architecture)
4. [Complete Mathematical Formulations (LaTeX)](#4-complete-mathematical-formulations-latex)
5. [System & Control Flow Architecture](#5-system--control-flow-architecture)
6. [Obstacle Evasion Sequence & Motion Workflow](#6-obstacle-evasion-sequence--motion-workflow)
7. [Experimental Results & Telemetry Plots](#7-experimental-results--telemetry-plots)
8. [MATLAB Notes & MLX Live Script Verification](#8-matlab-notes--mlx-live-script-verification)
9. [Installation & Execution Guide](#9-installation--execution-guide)
10. [Automated Verification & Unit Testing](#10-automated-verification--unit-testing)
11. [Complete Academic References](#11-complete-academic-references)

---

## 1. Project Overview & Key Contributions

Autonomous drone navigation in cluttered GPS-denied environments traditionally relies on computationally heavy SLAM or expensive Model Predictive Control (MPC). This project implements a **bio-inspired 2-neuron Minimal Recurrent Controller (MRC) with online synaptic plasticity and homeostatic scaling** coupled to a 6-DOF physics engine in MuJoCo.

### Key Innovations in this Project:
1. **5-LiDAR Focused Array ($-18^\circ, -9^\circ, 0^\circ, +9^\circ, +18^\circ$)**:
   - Replaces sparse 2-sensor setups to eliminate blind spots and front symmetry deadlocks.
   - Provides an active $36^\circ$ forward defense cone up to $3.5\text{m}$.
2. **Strict Physical Aperture Fitting ($0.84\text{m}$ Rule)**:
   - Evaluates whether the drone's wingspan ($0.52\text{m}$) plus aerodynamic safety margin ($2 \times 0.16\text{m} = 0.32\text{m}$) physically fits in the gap between obstacles and perimeter walls.
   - Triggers **Whole Packed** detection and safe hover standoff if gaps are impassable.
3. **Cascaded Autopilot with Aerodynamic Tilt Compensation**:
   - Outer velocity loop converts speed commands into forward pitch tilt ($\theta_{\text{des}}$) and roll bank ($\phi_{\text{des}}$).
   - Inner attitude loop computes roll, pitch, and yaw torques ($\tau_x, \tau_y, \tau_z$).
   - Compensates for thrust vector tilting so the drone maintains a rock-solid $1.5\text{m}$ altitude during maneuvers.
4. **4-Corner & Perimeter Boundary Containment**:
   - Active repulsion zone ($d_{\text{corner}} < 1.40\text{m}$) brakes speed down to crawl ($0.02-0.08\text{m/s}$) and steers inward toward the arena center.
5. **Interactive Nature Park Mission Commander**:
   - Interactive GUI with real-time waypoint management, custom starting/ending points, and multi-journey autonomous navigation without closing the 3D window.

<p align="center">
  <img src="assets/reference_drone_nature_scene.jpg" width="700" alt="Photorealistic MuJoCo Nature Park Simulation" />
  <br>
  <em>Figure 1: Photorealistic MuJoCo 3D Simulation Environment featuring F450 Multirotor, Dynamic Helipads, and Slender Obstacles</em>
</p>

---

## 2. Physical Drone Architecture & Blueprint

<p align="center">
  <img src="assets/drone_hand_sketch_lidar.jpg" width="600" alt="Drone Design & 5-LiDAR Array Hand Sketch" />
  <br>
  <em>Figure 2: Engineering Schematic of F450 Quadrotor Frame & 5-LiDAR Front Defense Array</em>
</p>

```
                              ▲ Front (+X)
             ◄────────────────── 550 mm ──────────────────►
             
      Front-Left [FL]                             Front-Right [FR]
      (Motor 2 - CW)                              (Motor 1 - CCW)
            \                                           /
             \            5 LiDAR Sensors              /
              \      [-18°, -9°, 0°, +9°, +18°]       /
               \                 │││││               /
                \        ┌───────────────────┐      /
                 \       │                   │     /
                  \      │   F450 Airframe   │    /
         ──────────┼─────│   Mass: 1.32 kg   │───┼──────────  ▲
                  /      │                   │    \           │
                 /       └───────────────────┘     \          │ 550 mm
                /                                   \         │ (Wingspan)
               /                                     \        │
              /                                       \       │
             /                                         \      │
            /                                           \     ▼
      Rear-Left [RL]                              Rear-Right [RR]
      (Motor 4 - CCW)                             (Motor 3 - CW)
                              ▼ Rear (-X)
                              
             ◄────────── Wheelbase: 450 mm ──────────────►
```

### Drone Specifications Table

| Parameter | Value in Simulation | Physical Definition |
|---|:---:|---|
| **Airframe Class** | **DJI Flamewheel F450** | Standard composite multirotor frame |
| **Total Takeoff Mass ($m$)** | **$1.32\text{ kg}$ ($1320\text{ g}$)** | Chassis, motors, avionics, battery, and sensors |
| **Diagonal Wheelbase** | **$450\text{ mm}$ ($0.45\text{ m}$)** | Motor shaft to opposite diagonal motor shaft |
| **Physical Wingspan** | **$550\text{ mm}$ ($0.55\text{ m}$)** | Outer propeller tip-to-tip span (X and Y axes) |
| **Frame Safety Envelope** | **$0.52\text{ m} - 0.68\text{ m}$** | Wingspan buffer used in aperture calculations |
| **Fuselage Dimensions** | **$240 \times 180 \times 140\text{ mm}$** | Length $\times$ Width $\times$ Height |
| **Ground Landing Clearance** | **$72\text{ mm}$ ($0.072\text{ m}$)** | Air gap under belly when resting on skids |
| **Motor Arm Radius ($d$)** | **$160\text{ mm}$ ($0.16\text{ m}$)** | Center of mass to each motor axle at $45^\circ$ |
| **Propeller Dimensions** | **$230\text{ mm}$ ($9.0\text{ in}$)** | 9045 Composite Propeller (Radius $r = 115\text{ mm}$) |
| **Actuator Limits** | **$[0.0\text{ N}, 16.0\text{ N}]$** | Saturated thrust per brushless DC motor |
| **Hover Thrust Total** | **$12.95\text{ N}$** | $m \cdot g = 1.32 \times 9.81\text{ N}$ ($3.24\text{ N}$ per motor) |
| **Thrust-to-Weight Ratio** | **$4.9 : 1$** | Control headroom for rapid disturbance rejection |

---

## 3. 5-LiDAR Sensor Array Architecture

The forward perception suite consists of 5 rangefinder beams positioned across an active $36^\circ$ sector:

<p align="center">
  <img src="assets/lidar_5_beam_array_diagram.png" width="750" alt="5-LiDAR Sensor Array Architecture" />
</p>

### Beam Layout & Angular ISO 8855 Coordinate Standards

```
                            [Center LiDAR: 0°]
                         (Dead-Center Nose Defense)
                                     │
       [Mid-Left: +9°]               │               [Mid-Right: -9°]
     (Forward-Left Sector)           │             (Forward-Right Sector)
               \                     │                     /
                \                    │                    /
[Far-Left: +18°] \                   │                   / [Far-Right: -18°]
(Left Flank Wing) \                  │                  /  (Right Flank Wing)
                   \                 │                 /
                    \                │                /
                 +===================+===================+
                 |  [FL]    [ML]    [C]    [MR]    [FR]  | <-- 5 Optical Lenses
                 |             F450 QUADROTOR            |
                 +=======================================+
```

| Sensor Beam | Relative Body Angle | 360° Compass Equivalent | Role in Collision Avoidance |
|---|:---:|:---:|---|
| **Center Beam [C]** | **$0^\circ$** | **$0^\circ$ / $360^\circ$** | **Dead-Center Defense**: Eliminates symmetry deadlocks; initiates emergency braking ($0.15\text{m/s}$) and standoff. |
| **Mid-Left Beam [ML]** | **$+9^\circ$** | **$9^\circ$** | **Forward-Left Sector**: Drives Neuron 1 depolarization, commanding rightward yaw steering. |
| **Far-Left Beam [FL]** | **$+18^\circ$** | **$18^\circ$** | **Left Flank Defense**: Guards outer left wingtip during right turns and corridor bypasses. |
| **Mid-Right Beam [MR]** | **$-9^\circ$** | **$351^\circ$** | **Forward-Right Sector**: Drives Neuron 2 depolarization, commanding leftward yaw steering. |
| **Far-Right Beam [FR]** | **$-18^\circ$** | **$342^\circ$** | **Right Flank Defense**: Guards outer right wingtip during left turns and corridor bypasses. |

---

## 4. Complete Mathematical Formulations (LaTeX)

### A. Sensory Normalization & Reflex Detection
Each raw distance measurement $d_i(t) \in [0, \infty)$ is mapped into a normalized bipolar neural input $I_i(t) \in [-1.0, +1.0]$:

$$I_i(t) = 1.0 - 2.0 \cdot \left(\frac{\text{clamp}(d_i(t), \, d_{\min}, \, d_{\max}) - d_{\min}}{d_{\max} - d_{\min}}\right)$$

* $d_{\max} = 3.5\text{ m} \implies I_i = -1.0$ (Clear horizon / resting state).
* $d_{\min} = 0.25\text{ m} \implies I_i = +1.0$ (Imminent collision zone).

The binary reflex signal $T_i(t)$ triggers online learning when inside the safety threshold:

$$T_i(t) = \begin{cases} 1.0, & 0 < d_i(t) < d_{\text{reflex}} \\ 0.0, & \text{otherwise} \end{cases} \quad \text{where } d_{\text{reflex}} = 0.85\text{ m}$$

---

### B. Two-Neuron Minimal Recurrent Controller (MRC)
Directional sensory drives combine mid-sector and flank beams with a dead-center symmetry-breaking bias:

$$\text{Drive}_1(t) = \max\big(I_{\text{ML}}, \, 0.75 \cdot I_{\text{FL}}\big) + \max(0, \, I_{\text{C}})$$

$$\text{Drive}_2(t) = \max\big(I_{\text{MR}}, \, 0.75 \cdot I_{\text{FR}}\big) + \max(0, \, I_{\text{C}})$$

Membrane potential states $a_1(t), a_2(t)$ evolve according to:

$$a_1(t) = b_1(t) \cdot O_1(t-1) + c(t) \cdot O_2(t-1) + a_1^{\text{syn}} \cdot \text{Drive}_1(t)$$

$$a_2(t) = b_2(t) \cdot O_2(t-1) + c(t) \cdot O_1(t-1) + a_1^{\text{syn}} \cdot \text{Drive}_2(t)$$

Where:
* $a_1^{\text{syn}} = 4.7$ (Input synaptic weight)
* $b_1, b_2$ (Self-excitatory recurrent weights, initial $b_{\text{init}} = 2.4$)
* $c(t) = -\frac{q_1(t) + q_2(t)}{2}$ (Symmetric mutual inhibition, initial $q_{\text{init}} = 3.5$)

Neuronal activation outputs $O_1(t), O_2(t) \in [-1.0, +1.0]$:

$$O_1(t) = \tanh(a_1(t)), \quad O_2(t) = \tanh(a_2(t))$$

Normalized positive firing rates $v_i(t) \in [0.0, 1.0]$:

$$v_1(t) = \frac{O_1(t) + 1.0}{2.0}, \quad v_2(t) = \frac{O_2(t) + 1.0}{2.0}$$

---

### C. Differential Hebbian Synaptic Plasticity & Homeostatic Scaling
During entrapment ($T_i = 1$), weights adapt online to expand turning hysteresis:

$$\dot{b}_i(t) = \mu_b \cdot v_i(t) \cdot T_i(t) - \gamma_b \cdot \big(b_i(t) - b_{\text{init}}\big)$$

$$\dot{q}_i(t) = \mu_q \cdot v_i(t) \cdot T_i(t) - \gamma_q \cdot \big(q_i(t) - q_{\text{init}}\big)$$

* $\mu_b = 0.08, \mu_q = 0.12$ (Plasticity learning rates driving weight growth).
* $\gamma_b = \gamma_q = 0.005$ (Homeostatic decay returning weights to baseline in clear air).

---

### D. Kinematic Guidance: Steering & Speed Regulation
The neural steering rate $\dot{\psi}_{\text{avoid}}$ is proportional to the activation difference:

$$\dot{\psi}_{\text{avoid}}(t) = -k_{\text{yaw}} \cdot \big(O_1(t) - O_2(t)\big) \quad (k_{\text{yaw}} = 0.40)$$

Under waypoint guidance with heading error $e_\psi = (\psi_{\text{target}} - \psi + \pi) \pmod{2\pi} - \pi$:

$$\dot{\psi}_{\text{cmd}} = \text{clamp}\big(0.75 \cdot e_\psi, \, -0.35, \, +0.35\big)\text{ rad/s}$$

Forward speed is regulated by a 5-tier safety envelope:

$$v_{x,\text{cmd}} = \min\big(v_{\text{cruise}}, \, v_{\text{goal}}, \, v_{\text{turn}}, \, v_{\text{obs}}, \, v_{\text{corner}}\big)$$

* $v_{\text{cruise}} = 0.60\text{ m/s}$ (Configurable $0.001 - 1.0\text{ m/s}$).
* $v_{\text{goal}} = 0.85 \cdot d_{\text{goal}}$ (Ramps to $0.0\text{ m/s}$ on touchdown).
* $v_{\text{turn}} = v_{\text{cruise}} \cdot \left(1.0 - 0.75 \cdot \frac{|e_\psi|}{\pi}\right)$ for $|e_\psi| > 25^\circ$.
* $v_{\text{obs}}$: Drops from $0.45\text{ m/s} \to 0.30\text{ m/s} \to 0.15\text{ m/s} \to 0.02\text{ m/s}$ based on proximity.

---

### E. Physical Aperture Fitting & Boundary Geometry
* **Passability Criterion ($0.84\text{m}$ Rule)**:
  $$W_{\text{min\_passable}} = W_d + 2 \cdot \delta_{\text{safe}} = 0.52 + 2(0.16) = \mathbf{0.84\text{ m}}$$
  If $W_{\text{gap}} < 0.84\text{m}$, the drone halts forward velocity ($v_{x,\text{cmd}} = 0$) and holds safe $1.2\text{m}$ hover standoff.
* **Single-Obstacle Radial Clearance ($0.58\text{m}$)**:
  $$d_{\text{obs\_center}} \ge r_{\text{drone}} + r_{\text{obs}} + \delta_{\text{blade}} = 0.27 + 0.04 + 0.27 = \mathbf{0.58\text{ m}}$$
  Guarantees $> 27\text{cm}$ clear air gap from rotating blade tips.
* **Safe Flight Envelope**:
  $$X \in [-0.80\text{ m}, \, 12.80\text{ m}], \quad Y \in [-1.88\text{ m}, \, +1.88\text{ m}]$$

---

### F. Cascaded Autopilot: Velocity & Attitude Control
**1. Altitude PID with Geometric Tilt Compensation:**

$$F_z = \frac{m \cdot g + K_{p,z} (z_{\text{target}} - z) - K_{d,z} \dot{z} + K_{i,z} \int (z_{\text{target}} - z) dt}{\cos(\phi) \cdot \cos(\theta)}$$

* $m \cdot g = 12.95\text{ N}, \quad K_{p,z} = 28.0, \quad K_{d,z} = 12.0, \quad K_{i,z} = 2.0$.

**2. Horizontal Velocity to Desired Tilt Angles:**

$$\theta_{\text{des}} = \text{clamp}\big(K_{p,vx} (v_{x,\text{cmd}} - v_{x,B}) + K_{i,vx} \int e_{vx} dt - K_{d,vx} v_{x,B}, \, -0.18, \, +0.18\big)$$

$$\phi_{\text{des}} = \text{clamp}\big(-\big(K_{p,vy} (0 - v_{y,B}) - K_{d,vy} v_{y,B}\big), \, -0.18, \, +0.18\big)$$

**3. Attitude PD to 3D Rotational Torques:**

$$\tau_x = K_{p,\text{att}} (\phi_{\text{des}} - \phi) - K_{d,\text{att}} \omega_x \quad \text{(Roll Moment)}$$

$$\tau_y = K_{p,\text{att}} (\theta_{\text{des}} - \theta) - K_{d,\text{att}} \omega_y \quad \text{(Pitch Moment)}$$

$$\tau_z = K_{d,\text{yaw}} (\dot{\psi}_{\text{cmd}} - \omega_z) \quad \text{(Yaw Moment)}$$

* $K_{p,\text{att}} = 1.80, \quad K_{d,\text{att}} = 0.28, \quad K_{d,\text{yaw}} = 0.25$.

---

### G. Linear Control Allocation (Motor Mixer Matrix)
For motor arm length $d = 0.16\text{m}$ and propeller aerodynamic drag constant $c_\tau = 0.02$:

$$\begin{bmatrix} u_{\text{FR}} \\ u_{\text{FL}} \\ u_{\text{RR}} \\ u_{\text{RL}} \end{bmatrix} = \begin{bmatrix} \frac{1}{4} & -\frac{1}{4d} & -\frac{1}{4d} & -\frac{1}{4c_\tau} \\[8pt] \frac{1}{4} & +\frac{1}{4d} & -\frac{1}{4d} & +\frac{1}{4c_\tau} \\[8pt] \frac{1}{4} & -\frac{1}{4d} & +\frac{1}{4d} & +\frac{1}{4c_\tau} \\[8pt] \frac{1}{4} & +\frac{1}{4d} & +\frac{1}{4d} & -\frac{1}{4c_\tau} \end{bmatrix} \begin{bmatrix} F_z \\ \tau_x \\ \tau_y \\ \tau_z \end{bmatrix}$$

Individual rotor saturation: $u_i = \text{clamp}(u_i, 0.0\text{ N}, 16.0\text{ N})$.

---

## 5. System & Control Flow Architecture

```mermaid
flowchart TD
    subgraph SENSORS["1. Sensory Layer (50 Hz)"]
        LIDAR["5 LiDAR Rangefinders<br>(-18°, -9°, 0°, +9°, +18°)<br>Max Range: 3.5m"]
        IMU["6-DOF IMU<br>Gyro + Accelerometer"]
    end

    subgraph NEURAL["2. Adaptive Neural Core (IEEE 8491889)"]
        N1["Neuron 1 (Left Hemisphere)"]
        N2["Neuron 2 (Right Hemisphere)"]
        PLAST["Online Synaptic Plasticity<br>b_i, q_i Adaptation"]
        N1 <-->|Inhibition c| N2
        PLAST -.->|Modulates Weights| N1
        PLAST -.->|Modulates Weights| N2
    end

    subgraph SAFETY["3. Safety & Aperture Engine"]
        APERTURE["Aperture Passability Check<br>0.84m Wingspan Clearance"]
        CORNER["4-Corner & Wall Shield<br>d < 1.4m Repulsion"]
        REAR["Rear-Wing Shield<br>Locks Yaw into Obstacle"]
    end

    subgraph AUTOPILOT["4. Cascaded Autopilot"]
        ALT["Altitude PID<br>Vertical Thrust Fz with Tilt Factor"]
        VEL["Outer Loop: Velocity PD<br>Pitch θ_des, Roll φ_des"]
        ATT["Inner Loop: Attitude PD<br>Torques τx, τy, τz"]
    end

    subgraph MIXER["5. Linear Mixer Matrix"]
        ALLOC["4x4 Control Allocation Matrix<br>u_FR, u_FL, u_RR, u_RL"]
    end

    subgraph PHYSICS["6. MuJoCo 6-DOF Engine"]
        WORLD["Rigid Body Flight Dynamics<br>Newton-Euler Integration"]
    end

    LIDAR --> N1
    LIDAR --> N2
    N1 --> APERTURE
    N2 --> APERTURE
    APERTURE --> VEL
    APERTURE --> ATT
    CORNER --> VEL
    REAR --> ATT
    ALT --> ALLOC
    VEL --> ATT
    ATT --> ALLOC
    ALLOC --> WORLD
    WORLD -.->|New Raycast Distances| LIDAR
    WORLD -.->|Attitude & Position Feedback| IMU
```

---

## 6. Obstacle Evasion Sequence & Motion Workflow

```mermaid
sequenceDiagram
    autonumber
    actor Drone as F450 Quadrotor
    participant Sensor as 5-LiDAR Array
    participant Brain as Two-Neuron MRC
    participant Autopilot as Cascaded Autopilot & Mixer
    participant Physics as MuJoCo 6-DOF Engine

    Note over Drone,Physics: Phase 1: Nominal Cruise (v = 0.60 m/s, Altitude = 1.50 m)
    Drone->>Physics: Cruising along flight corridor toward destination helipad

    Note over Drone,Physics: Phase 2: Obstacle Detection (Obstacle on Left at d < 1.3 m)
    Sensor->>Brain: +9° and +18° beams detect obstacle
    Brain->>Brain: Neuron 1 fires (O1 = +0.95), Neuron 2 rests (O2 = -0.95)
    Brain->>Autopilot: Evasive yaw rate commanded: ψ̇ = -k_yaw · (O1 - O2) = -0.35 rad/s (Turn Right)

    Note over Drone,Physics: Phase 3: Proactive Braking & Aperture Verification
    Sensor->>Autopilot: Speed cuts to 0.15 m/s to tighten turning radius
    Autopilot->>Autopilot: Aperture check verifies right gap > 0.84m safe clearance
    Autopilot->>Autopilot: Generates safe bypass waypoint inside boundary envelope

    Note over Drone,Physics: Phase 4: Motor Allocation & Turning Execution
    Autopilot->>Physics: Mixer boosts CCW motors (FR, RL) & reduces CW motors (FL, RR)
    Physics->>Physics: Drone yaws smoothly right without dropping altitude

    Note over Drone,Physics: Phase 5: Corridor Bypass & Rear-Wing Shield
    Physics->>Physics: Drone flies along obstacle maintaining > 0.58m center clearance
    Note over Drone,Physics: Rear-wing shield forbids turning left until tail clears obstacle

    Note over Drone,Physics: Phase 6: Goal Realignment & Helipad Touchdown
    Sensor->>Brain: LiDAR rays clear (d > 3.5 m)
    Autopilot->>Physics: Realigns heading toward Destination Helipad
    Physics->>Physics: Vertical descent to ground (1.50 m -> 0.072 m touchdown)
```

---

## 7. Experimental Results & Telemetry Plots

All scenarios were rigorously verified through high-resolution physics telemetry:

<p align="center">
  <img src="assets/telemetry_corner_boundary_aperture_shield.png" width="900" alt="Telemetry Verification Plot" />
</p>

### Verification Benchmark Summary

| Test Scenario | Obstacle Placement | Controller Decision | Minimum Obstacle Clearance | Boundary Limits | Status |
|---|---|---|---|---|:---:|
| **Scenario 1: North Wall Obstacle** | $(5.0, 1.8)\text{ m}$ | Refused North ($0.08\text{m}$), Detoured South | $0.75\text{ m}$ ($> 0.35\text{m}$ threshold) | $Y_{\max} = 1.17\text{ m} < 1.88\text{ m}$ | **PASSED** |
| **Scenario 2: South Wall Obstacle** | $(5.0, -1.8)\text{ m}$ | Refused South ($0.08\text{m}$), Detoured North | $1.80\text{ m}$ ($> 0.35\text{m}$ threshold) | $Y_{\min} = 0.00\text{ m} > -1.88\text{ m}$ | **PASSED** |
| **Scenario 3: NE Corner Obstacle** | $(10.5, 1.8)\text{ m}$ | Corner repulsion active; steered to center | $0.77\text{ m}$ ($> 0.35\text{m}$ threshold) | Zero wall/corner contact | **PASSED** |
| **Scenario 4: Whole Packed Barrier** | 9 poles across corridor | Blockage detected; held safe hover standoff | $1.64\text{ m}$ standoff ($> 1.20\text{m}$) | Zero collision; $v_x = 0\text{ m/s}$ | **PASSED** |
| **Full Unit Test Suite** | 13 integration tests | Comprehensive dynamics coverage | All passed in $10.8\text{ s}$ | All passed | **13/13 PASSED** |

---

## 8. MATLAB Notes & MLX Live Script Verification

As required for the course evaluation (`Drones_S5_AB13`), the complete theoretical derivation and laboratory live scripts are preserved and verified under the [`matlab_notes_mlx/`](matlab_notes_mlx/) directory:

| MATLAB File (`.mlx`) | Mathematical Topic & Coursework Scope |
|---|---|
| [`matlab_notes_mlx/taylorSeriesDrones.mlx`](matlab_notes_mlx/taylorSeriesDrones.mlx) | **Nonlinear Taylor Series Linearization** of quadrotor rotational equations around hover equilibrium. |
| [`matlab_notes_mlx/BSplineDrones.mlx`](matlab_notes_mlx/BSplineDrones.mlx) | **B-Spline Trajectory Generation**: Smooth curvature-continuous waypoint curves for drone path planning. |
| [`matlab_notes_mlx/Lotka-VolterraDrones.mlx`](matlab_notes_mlx/Lotka-VolterraDrones.mlx) | **Competitive Neural Dynamics**: Analysis of mutual inhibition and phase portraits in 2-neuron networks. |
| [`matlab_notes_mlx/fractionalBrownianMotionDrones.mlx`](matlab_notes_mlx/fractionalBrownianMotionDrones.mlx) | **Fractional Brownian Motion (fBm)**: Stochastic modeling of non-Markovian wind gust perturbations. |
| [`matlab_notes_mlx/5_9_26Drones_.mlx`](matlab_notes_mlx/5_9_26Drones_.mlx) | Laboratory Session 1: State-space formulation and cascaded altitude/attitude stability. |
| [`matlab_notes_mlx/7_9_26Drones.mlx`](matlab_notes_mlx/7_9_26Drones.mlx) | Laboratory Session 2: Sensor modeling, Gaussian noise injection, and rangefinder discretization. |
| [`matlab_notes_mlx/Aug3rdDrones.mlx`](matlab_notes_mlx/Aug3rdDrones.mlx) | Laboratory Session 3: Control allocation matrices, actuator saturation, and propeller gyroscopic effects. |
| [`matlab_notes_mlx/Drones.mlx`](matlab_notes_mlx/Drones.mlx) | Quadrotor kinematics, quaternion rotations, and Euler angle coordinate frames. |
| [`matlab_notes_mlx/Drones4thAug.mlx`](matlab_notes_mlx/Drones4thAug.mlx) | Hebbian synaptic learning rate bounds and Lyapunov stability verification. |

---

## 9. Installation & Execution Guide

### Prerequisites
* **Operating System**: Windows 10/11, Ubuntu 20.04+, or macOS
* **Python**: Version `3.10` or higher
* **C++ Compiler**: Standard system runtime (for MuJoCo physics)

### Step 1: Clone Repository
```bash
git clone https://github.com/YourUsername/Drones_S5_AB13.git
cd Drones_S5_AB13
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

*Required packages in `requirements.txt`:*
```
mujoco>=3.2.0
numpy>=1.24.0
matplotlib>=3.7.0
scipy>=1.10.0
pyttsx3>=2.90
```

---

### Step 3: Run Interactive Mission Planner & Live Flight
Run the interactive commander with full 3D visual graphics:

```bash
python run_park_interactive.py
```
*(Or simply double-click [`DOUBLE_CLICK_TO_RUN.bat`](DOUBLE_CLICK_TO_RUN.bat) on Windows).*

**Mission Planner Controls**:
1. **1st Click**: Set **Starting Location** (Pure White helipad).
2. **2nd Click**: Set **Destination Goal** (Light Red helipad).
3. **3rd Click(s)**: Place slender stick obstacles anywhere in the park!
4. **Speed Selector**: Set initial forward cruise speed from $0.001\text{ m/s}$ to $1.0\text{ m/s}$.
5. **Launch Mission**: Drone takes off, tracks waypoints, avoids obstacles, lands gently on ground, and speaks *"Task finished"*.

---

## 10. Automated Verification & Unit Testing

Execute the comprehensive test suite to verify all controller modules, 5-LiDAR raycasts, and 6-DOF flight stability:

```bash
python test_simulation.py
```

Expected output:
```
.............
----------------------------------------------------------------------
Ran 13 tests in 10.814s

OK
```

All 13 test cases cover:
- Neural weight adaptation and differential Hebbian learning
- 5-LiDAR sensory normalization and reflex triggers
- Cascaded altitude PID and tilt compensation
- Aperture passability and Whole Packed detection
- 4-corner repulsion and perimeter containment
- Ground takeoff, cruise, and precision touchdown landing

---

## 11. Complete Academic References

1. **Devos, A., Ebeid, E. S. M., & Manoonpong, P.** (2018). *Development of Autonomous Drones for Adaptive Obstacle Avoidance in Real World Environments.* In **2018 21st Euromicro Conference on Digital System Design (DSD)** (pp. 645–652). IEEE. DOI: [10.1109/DSD.2018.00112](https://doi.org/10.1109/DSD.2018.00112).
2. **Pedersen, M. V., & Manoonpong, P.** (2018). *Neural Control for Obstacle Avoidance with Synaptic Plasticity in Autonomous Multirotors.* **Frontiers in Neurorobotics**, 12, 58. DOI: [10.3389/fnbot.2018.00058](https://doi.org/10.3389/fnbot.2018.00058).
3. **Grinke, E., Tetzlaff, C., Wörgötter, F., & Manoonpong, P.** (2015). *Synaptic Plasticity in a Recurrent Neural Network for Versatile and Adaptive Behaviors of a Walking Robot.* **Frontiers in Neurorobotics**, 9, 11. DOI: [10.3389/fnbot.2015.00011](https://doi.org/10.3389/fnbot.2015.00011).
4. **Jaiton, P., Thor, M., & Manoonpong, P.** (2022). *Bio-Inspired Neural Control and Online Learning for Adaptive Obstacle Avoidance in Mobile Robots.* **IEEE Transactions on Neural Networks and Learning Systems**, 34(10), 7890–7903.
5. **Todorov, E., Erez, T., & Tassa, Y.** (2012). *MuJoCo: A physics engine for model-based control.* In **2012 IEEE/RSJ International Conference on Intelligent Robots and Systems (IROS)** (pp. 5026–5033). IEEE.
6. **Beard, R. W., & McLain, T. W.** (2012). *Small Unmanned Aircraft: Theory and Practice.* Princeton University Press.
