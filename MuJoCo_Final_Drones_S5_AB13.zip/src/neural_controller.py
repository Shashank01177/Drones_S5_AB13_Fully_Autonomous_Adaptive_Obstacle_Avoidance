"""
Adaptive Neural Controller for Autonomous Drone Obstacle Avoidance
Based on IEEE 8491889 (Devos, Ebeid, Manoonpong 2018) and foundational papers
(Pedersen & Manoonpong 2018; Grinke et al. 2015; Jaiton et al. 2022).

Architecture:
- 2-neuron Minimal Recurrent Controller (MRC) with even inhibitory loop
- Online correlation-based learning rule for synaptic plasticity
- Synaptic scaling for homeostatic stabilization
- Dynamic turning angle modulation (hysteresis expansion)
- Speed adaptation with proximity-based braking and emergency back-up
"""

import numpy as np


class AdaptiveNeuralController:
    """
    Two-neuron recurrent neural controller with synaptic plasticity
    and homeostatic scaling for adaptive drone navigation.
    """

    def __init__(
        self,
        # Sensor normalization parameters
        d_min: float = 0.25,      # meters (maximum proximity danger)
        d_max: float = 3.5,       # meters (detection horizon)
        d_reflex: float = 0.85,    # meters (reflexive trigger threshold)
        
        # Neural network architectural parameters
        a1: float = 4.7,          # Input synaptic weight
        b_init: float = 2.4,      # Initial self-excitatory weight
        q_init: float = 3.5,      # Initial mutual inhibitory weight (c = -q)
        
        # Plasticity & scaling parameters
        enable_plasticity: bool = True,
        mu_b: float = 0.08,       # Learning rate for self-excitation
        mu_q: float = 0.12,       # Learning rate for mutual inhibition
        gamma_b: float = 0.005,   # Synaptic scaling (forgetting) rate for b
        gamma_q: float = 0.005,   # Synaptic scaling (forgetting) rate for q
        
        # Velocity and steering mapping
        v_cruise: float = 0.5,    # Default forward cruise speed (m/s) (range 0.001 - 1.0 m/s)
        k_yaw: float = 0.40,      # Slow, smooth steering yaw-rate gain (gentle graceful turning)
        dt: float = 0.02,         # Control update step (50 Hz)
    ):
        self.d_min = d_min
        self.d_max = d_max
        self.d_reflex = d_reflex
        
        self.a1 = a1
        self.b_init = b_init
        self.q_init = q_init
        
        self.enable_plasticity = enable_plasticity
        self.mu_b = mu_b
        self.mu_q = mu_q
        self.gamma_b = gamma_b
        self.gamma_q = gamma_q
        
        self.v_cruise = v_cruise
        self.k_yaw = k_yaw
        self.dt = dt
        
        self.reset()

    def reset(self):
        """Reset neural states, weights, and histories to initial values."""
        # Neuronal activation outputs O_i in [-1, 1]
        # Initialized to -1 (no obstacle state)
        self.O1 = -1.0
        self.O2 = -1.0
        
        # Normalized firing rates v_i in [0, 1]
        self.v1 = (self.O1 + 1.0) / 2.0
        self.v2 = (self.O2 + 1.0) / 2.0
        self.v1_prev = self.v1
        self.v2_prev = self.v2
        
        # Synaptic weights
        self.b1 = self.b_init
        self.b2 = self.b_init
        self.q1 = self.q_init
        self.q2 = self.q_init
        self.c = -self.q_init  # Symmetric mutual inhibition
        
        # Reflex signals (5 LiDAR beams)
        self.T_far_left = 0.0
        self.T1 = 0.0
        self.T_center = 0.0
        self.T2 = 0.0
        self.T_far_right = 0.0
        
        # Raw sensory inputs I_i in [-1, 1]
        self.I_far_left = -1.0
        self.I1 = -1.0
        self.I_center = -1.0
        self.I2 = -1.0
        self.I_far_right = -1.0
        
        # Commands
        self.cmd_vx = self.v_cruise
        self.cmd_yaw_rate = 0.0
        
        # Evasion persistence memory for goal navigation
        self.evasion_timer = 0.0
        self.evasion_side = 0.0
        
        # Statistics for diagnostics
        self.time = 0.0
        self.total_plasticity_updates = 0

    def normalize_sensor(self, d: float) -> float:
        """
        Maps a distance reading d (meters) to neural input I in [-1, 1].
        -1.0 means no obstacle (d >= d_max).
        +1.0 means obstacle in collision distance (d <= d_min).
        """
        if np.isnan(d) or d >= self.d_max or d < 0:
            return -1.0
        d_clamped = np.clip(d, self.d_min, self.d_max)
        # Linear inverse mapping: d_max -> -1.0, d_min -> +1.0
        return float(1.0 - 2.0 * ((d_clamped - self.d_min) / (self.d_max - self.d_min)))

    def step(
        self,
        dist_left: float,
        dist_right: float,
        dist_center: float = None,
        dist_far_left: float = None,
        dist_far_right: float = None,
        goal_heading_err: float = None,
        dist_to_goal: float = None,
    ) -> dict:
        """
        Executes one discrete update of the adaptive neural controller with 5-LiDAR sensory array.
        
        Args:
            dist_left: Mid-left rangefinder reading (+9 deg) (meters)
            dist_right: Mid-right rangefinder reading (-9 deg) (meters)
            dist_center: Center rangefinder reading (0 deg forward) (meters)
            dist_far_left: Far-left rangefinder reading (+18 deg flank) (meters)
            dist_far_right: Far-right rangefinder reading (-18 deg flank) (meters)
            goal_heading_err: Optional heading angle error to goal (radians, [-pi, pi])
            dist_to_goal: Optional Euclidean distance to destination goal (meters)
            
        Returns:
            dict containing commanded forward velocity, yaw rate, and telemetry state.
        """
        if dist_center is None:
            dist_center = self.d_max
        if dist_far_left is None:
            dist_far_left = self.d_max
        if dist_far_right is None:
            dist_far_right = self.d_max

        # 1. Normalize all 5 sensory inputs
        self.I_far_left = self.normalize_sensor(dist_far_left)
        self.I1 = self.normalize_sensor(dist_left)
        self.I_center = self.normalize_sensor(dist_center)
        self.I2 = self.normalize_sensor(dist_right)
        self.I_far_right = self.normalize_sensor(dist_far_right)
        
        # 2. Evaluate reflex signals T_i
        self.T_far_left = 1.0 if (dist_far_left < self.d_reflex and dist_far_left > 0) else 0.0
        self.T1 = 1.0 if (dist_left < self.d_reflex and dist_left > 0) else 0.0
        self.T_center = 1.0 if (dist_center < self.d_reflex and dist_center > 0) else 0.0
        self.T2 = 1.0 if (dist_right < self.d_reflex and dist_right > 0) else 0.0
        self.T_far_right = 1.0 if (dist_far_right < self.d_reflex and dist_far_right > 0) else 0.0

        # Strengthen side reflexes from flank sensors
        if self.T_far_left > 0:
            self.T1 = max(self.T1, self.T_far_left)
        if self.T_far_right > 0:
            self.T2 = max(self.T2, self.T_far_right)

        # Center reflex distribution: if center sensor triggers reflex, steer towards the clearer hemisphere
        min_l = min(dist_left, dist_far_left)
        min_r = min(dist_right, dist_far_right)
        if self.T_center > 0:
            if min_l <= min_r:
                self.T1 = max(self.T1, self.T_center)
            else:
                self.T2 = max(self.T2, self.T_center)
        
        # 3. Update discrete-time recurrent neuron outputs O_i(t)
        O1_prev = self.O1
        O2_prev = self.O2
        
        # Mutual inhibition is symmetric: c12 = c21 = c = -(q1 + q2)/2
        self.c = -0.5 * (self.q1 + self.q2)
        
        # Incorporate 5 sensors into directional drive:
        # Left hemisphere drive: combination of mid-left and flank-left
        drive_1 = max(self.I1, 0.75 * self.I_far_left)
        # Right hemisphere drive: combination of mid-right and flank-right
        drive_2 = max(self.I2, 0.75 * self.I_far_right)

        # Center forward drive: adds bias towards clearer hemisphere
        center_boost = max(0.0, self.I_center)
        if min_l <= min_r:
            drive_1 += center_boost
        else:
            drive_2 += center_boost

        act1 = self.b1 * O1_prev + self.c * O2_prev + self.a1 * drive_1
        act2 = self.b2 * O2_prev + self.c * O1_prev + self.a1 * drive_2
        
        self.O1 = float(np.tanh(act1))
        self.O2 = float(np.tanh(act2))
        
        # 4. Compute positive normalized firing rates v_i in [0, 1]
        self.v1_prev = self.v1
        self.v2_prev = self.v2
        self.v1 = float((self.O1 + 1.0) / 2.0)
        self.v2 = float((self.O2 + 1.0) / 2.0)
        
        # 5. Online Correlation-Based Synaptic Plasticity & Homeostatic Scaling
        if self.enable_plasticity:
            noise_asym = 0.0
            if (self.T1 > 0 and self.T2 > 0) or (self.T_center > 0 and abs(min_l - min_r) < 0.1):
                noise_asym = 0.05

            dot_b1 = self.mu_b * (self.v1 + noise_asym) * self.T1 - self.gamma_b * (self.b1 - self.b_init)
            dot_b2 = self.mu_b * self.v2 * self.T2 - self.gamma_b * (self.b2 - self.b_init)
            
            dot_q1 = self.mu_q * (self.v1 + noise_asym) * self.T1 - self.gamma_q * (self.q1 - self.q_init)
            dot_q2 = self.mu_q * self.v2 * self.T2 - self.gamma_q * (self.q2 - self.q_init)
            
            # Integrate weight changes
            self.b1 = float(np.clip(self.b1 + dot_b1, self.b_init * 0.8, 6.5))
            self.b2 = float(np.clip(self.b2 + dot_b2, self.b_init * 0.8, 6.5))
            self.q1 = float(np.clip(self.q1 + dot_q1, self.q_init * 0.8, 8.0))
            self.q2 = float(np.clip(self.q2 + dot_q2, self.q_init * 0.8, 8.0))
            
            if self.T1 > 0 or self.T2 > 0 or self.T_center > 0:
                self.total_plasticity_updates += 1
        else:
            self.b1 = self.b_init
            self.b2 = self.b_init
            self.q1 = self.q_init
            self.q2 = self.q_init
            self.c = -self.q_init
            
        # 6. Motor Output Mapping
        # (A) Steering command (yaw rate)
        avoid_yaw_rate = float(np.clip(-self.k_yaw * (self.O1 - self.O2), -0.35, 0.35))
        
        min_dist = min(dist_far_left, dist_left, dist_center, dist_right, dist_far_right)
        max_v = max(self.v1, self.v2)

        # Detect active obstacle avoidance need and maintain evasion memory
        if min_dist < 2.5 or max_v > 0.15:
            self.evasion_timer = 0.9  # Maintain evasion heading bias for 0.9s
            if min_l < min_r - 0.05:
                self.evasion_side = -1.0  # Obstacle on left -> detour right
            elif min_r < min_l - 0.05:
                self.evasion_side = 1.0   # Obstacle on right -> detour left
            elif self.evasion_side == 0.0:
                self.evasion_side = -1.0  # Default initial evasion side
        elif self.evasion_timer > 0.0:
            self.evasion_timer = max(0.0, self.evasion_timer - self.dt)
            if self.evasion_timer == 0.0:
                self.evasion_side = 0.0

        if goal_heading_err is not None:
            self.cmd_yaw_rate = float(np.clip(0.75 * goal_heading_err, -0.35, 0.35))
        else:
            self.cmd_yaw_rate = float(np.clip(avoid_yaw_rate, -0.35, 0.35))
        
        # (B) Forward Speed Adaptation across 5 LiDAR sensors:
        if dist_to_goal is not None and dist_to_goal < 0.38:
            self.cmd_vx = 0.0
            self.cmd_yaw_rate = 0.0
        else:
            # 1. Goal approach deceleration profile
            if dist_to_goal is not None:
                v_goal = max(0.15, 0.85 * dist_to_goal)
            else:
                v_goal = self.v_cruise

            # Slow down during significant turns
            if goal_heading_err is not None and abs(goal_heading_err) > 0.30:
                turn_factor = max(0.25, 1.0 - 0.75 * (abs(goal_heading_err) / np.pi))
                v_goal = min(v_goal, self.v_cruise * turn_factor)

            # 2. Obstacle evasion deceleration based on all 5 LiDAR sensors:
            if min_dist < 0.8:
                v_obs = min(0.15, 0.25 * self.v_cruise)
            elif min_dist < 1.3:
                v_obs = min(0.30, 0.50 * self.v_cruise)
            elif min_dist < 2.5:
                v_obs = min(0.45, 0.75 * self.v_cruise)
            else:
                v_obs = self.v_cruise

            # Additional Center sensor collision brake:
            if dist_center < 0.60:
                v_obs = min(v_obs, 0.05)
            elif dist_center < 1.0:
                v_obs = min(v_obs, 0.20)
            elif dist_center < 1.5:
                v_obs = min(v_obs, 0.35)

            # Flank sensor safety margin: if obstacle is close to peripheral flank (< 0.75m), ensure slow controlled bypass
            min_flank = min(dist_far_left, dist_far_right)
            if min_flank < 0.75:
                v_obs = min(v_obs, 0.30)

            self.cmd_vx = float(min(self.v_cruise, v_goal, max(min(0.05, self.v_cruise), v_obs)))

        self.time += self.dt
        
        return {
            "time": self.time,
            "dist_far_left": dist_far_left,
            "dist_left": dist_left,
            "dist_center": dist_center,
            "dist_right": dist_right,
            "dist_far_right": dist_far_right,
            "I1": self.I1,
            "I2": self.I2,
            "I_center": self.I_center,
            "I_far_left": self.I_far_left,
            "I_far_right": self.I_far_right,
            "O1": self.O1,
            "O2": self.O2,
            "v1": self.v1,
            "v2": self.v2,
            "T1": self.T1,
            "T2": self.T2,
            "T_center": self.T_center,
            "T_far_left": self.T_far_left,
            "T_far_right": self.T_far_right,
            "b1": self.b1,
            "b2": self.b2,
            "q1": self.q1,
            "q2": self.q2,
            "c": self.c,
            "cmd_vx": self.cmd_vx,
            "cmd_yaw_rate": self.cmd_yaw_rate,
        }
