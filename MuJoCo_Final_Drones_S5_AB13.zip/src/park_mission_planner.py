"""
Interactive Mission Planner & Live Flight Commander for Autonomous Drone.
Strict adherence to IEEE 8491889 (Devos, Ebeid, Manoonpong 2018).

User Specifications:
1. Fix Speed in 0.001 m/s to 1 m/s at starting (direct typing box & fine presets).
2. Drone moves when the object is there (1st Start, 2nd End, 3rd Obstacle placed).
3. Slow, smooth, graceful turning (capped at 0.35 rad/s ~ 20 deg/s with gentle gain).
4. Drone stops at end location but DOES NOT CLOSE, so user can see a new journey from there!
5. ZERO blue transparency (all transparent blue glass removed; natural park environment).
"""

import os
import sys
import math
import time
import queue
import threading
import tkinter as tk
from tkinter import messagebox
import numpy as np

# Ensure project root in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.neural_controller import AdaptiveNeuralController
from src.quadrotor_sim import QuadrotorSimulation


class ParkMissionPlanner:
    """
    Interactive Mission Planner & Continuous Multi-Journey Commander.
    Supports setting speed in [0.001, 1.0] m/s, slow graceful turning,
    and continuous multi-journey navigation without closing the 3D window.
    """

    def __init__(self, root=None, standalone=True, initial_start=None, initial_goal=None, initial_stick=None, initial_speed=0.10, auto_launch=False):
        self.standalone = standalone
        if root is None:
            self.root = tk.Tk()
            self._owns_root = True
        else:
            self.root = root
            self._owns_root = False

        self.root.title("🚁 Autonomous Drone Nature Park Mission Commander (IEEE 8491889)")
        self.root.geometry("1100x950")
        self.root.minsize(1020, 850)
        self.root.configure(bg="#111827")

        # Full Canvas Coordinate Mapping (Meters)
        self.X_MIN = -3.0
        self.X_MAX = 15.0
        self.Y_MIN = -4.0
        self.Y_MAX = 4.0
        self.CANVAS_W = 1040
        self.CANVAS_H = 430

        # Physical Arena Boundaries
        self.RECT_X_MIN = -1.5
        self.RECT_X_MAX = 13.5
        self.RECT_Y_MIN = -2.5
        self.RECT_Y_MAX = 2.5

        # 4-Step Input State: 1st Start, 2nd Multiple End Points, 3rd Obstacles, 4th Speed
        self.step = 1
        self.start_pos = initial_start    # 1st: Starting point (x, y)
        self.end_points = []              # 2nd: Multiple Ending points [(x1, y1), ...]
        if initial_goal is not None:
            if isinstance(initial_goal, (list, tuple)) and len(initial_goal) > 0 and isinstance(initial_goal[0], (list, tuple)):
                self.end_points.extend([tuple(p) for p in initial_goal])
            else:
                self.end_points.append(tuple(initial_goal))
        self.goal_pos = self.end_points[-1] if self.end_points else None
        
        # Placed Obstacles Pool (slender stick obstacles)
        self.obstacles = []
        if initial_stick is not None:
            if isinstance(initial_stick, (list, tuple)) and len(initial_stick) > 0 and isinstance(initial_stick[0], (list, tuple)):
                self.obstacles.extend([tuple(p) for p in initial_stick])
            else:
                self.obstacles.append(tuple(initial_stick))
        self.stick_pos = self.obstacles[-1] if self.obstacles else None

        # User-fixed forward cruise speed in range [0.001, 1.0] m/s
        self.cruise_speed = max(0.001, min(1.0, float(initial_speed)))
        self.flight_mode = "single"

        # Multi-journey continuous execution handles
        self.sim = None
        self.sim_thread = None
        self.sim_running = False
        self.obstacle_queue = queue.Queue()
        self.journey_queue = queue.Queue()
        
        self.journey_count = 1
        self.at_destination_standby = False
        self.has_spoken_finished = False

        self.drone_live_state = {
            "x": 0.0, "y": 0.0, "z": 0.072,
            "yaw": 0.0, "vx": 0.0, "alert": False,
            "mission_complete": False, "goal_reached": False
        }

        self._build_ui()
        self._draw_park_background()
        self.update_step_banner()

        # Handle window close
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

        if auto_launch:
            self.one_click_launch_mujoco()

    def announce_task_finished(self):
        """
        Announces 'Task finished' both audibly via speech synthesis and visually in the UI
        once the drone has safely landed on the ground.
        """
        if getattr(self, "has_spoken_finished", False):
            return
        self.has_spoken_finished = True

        dx = self.drone_live_state.get("x", 0.0)
        dy = self.drone_live_state.get("y", 0.0)
        print("\n" + "=" * 65)
        print(f"  [MISSION SUCCESS] [OK] Task finished! Drone landed on ground at ({dx:.2f}, {dy:.2f})m.")
        print("=" * 65 + "\n")

        # 1. Voice audio speech announcement using Windows Speech API (non-blocking)
        def _speak_worker():
            try:
                cmd = ["powershell", "-NoProfile", "-Command", "(New-Object -ComObject SAPI.SpVoice).Speak('Task finished')"]
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

        threading.Thread(target=_speak_worker, daemon=True).start()

        # 2. Update UI status bar and guidance banner
        def _update_ui():
            self.hud_status.configure(
                text=f"STATUS: ✅ Task finished! Drone landed safely on ground at ({dx:.2f}, {dy:.2f})m. Ready for next journey."
            )
            self.banner_frame.configure(bg="#059669")
            self.banner_lbl.configure(
                text="✅ TASK FINISHED! Drone has landed on ground (Motors Off).  👉 Click map to set NEW End Place & fly again!",
                bg="#059669",
            )
            self._redraw_mission_elements()

        try:
            self.root.after(0, _update_ui)
        except Exception:
            pass

    def announce_path_blocked(self, gap_w: float, drone_sz: float):
        """Announces that obstacles in front are whole packed and passage is smaller than drone size."""
        print("\n" + "=" * 65)
        print(f"  [COLLISION AVOIDANCE] ⛔ PATH BLOCKED: Obstacles whole packed ahead!")
        print(f"  Measured Gap: {gap_w:.2f}m < Drone Size: {drone_sz:.2f}m — Halting forward motion.")
        print("=" * 65 + "\n")

        def _speak():
            try:
                cmd = ["powershell", "-NoProfile", "-Command", "(New-Object -ComObject SAPI.SpVoice).Speak('Path blocked, cannot pass')"]
                subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass

        threading.Thread(target=_speak, daemon=True).start()

        def _update_ui():
            self.banner_frame.configure(bg="#DC2626")
            self.banner_lbl.configure(
                text=f"⛔ PATH BLOCKED! Obstacles whole packed ahead (Gap: {gap_w:.2f}m < Drone Size {drone_sz:.2f}m). Drone stopped safely.",
                bg="#DC2626",
            )
            self.hud_status.configure(
                text=f"STATUS: ⛔ PATH BLOCKED! Measured Gap: {gap_w:.2f}m < Drone Size: {drone_sz:.2f}m. Holding safe hover standoff."
            )
        try:
            self.root.after(0, _update_ui)
        except Exception:
            pass

    def parse_speed_text(self, text: str) -> float:
        """Parses speed text like '0.001', '0.01', '0.1', '0.01m/s', clamped to [0.001, 1.0]."""
        if not text:
            return 0.10
        cleaned = text.lower().replace("m/s", "").replace("mps", "").replace("m", "").strip()
        try:
            val = float(cleaned)
            return max(0.001, min(1.0, val))
        except ValueError:
            return 0.10

    def world_to_screen(self, x: float, y: float) -> tuple:
        """Converts world coordinates (meters) to canvas pixel coordinates."""
        px = int((x - self.X_MIN) / (self.X_MAX - self.X_MIN) * self.CANVAS_W)
        py = int((self.Y_MAX - y) / (self.Y_MAX - self.Y_MIN) * self.CANVAS_H)
        return px, py

    def screen_to_world(self, px: int, py: int) -> tuple:
        """Converts canvas pixel coordinates to world coordinates (meters)."""
        x = self.X_MIN + (px / self.CANVAS_W) * (self.X_MAX - self.X_MIN)
        y = self.Y_MAX - (py / self.CANVAS_H) * (self.Y_MAX - self.Y_MIN)
        return round(float(x), 2), round(float(y), 2)

    def _build_ui(self):
        # ==================== 1. HEADER ====================
        header_frame = tk.Frame(self.root, bg="#1F2937", pady=5)
        header_frame.pack(fill=tk.X)

        title_lbl = tk.Label(
            header_frame,
            text="🚁 AUTONOMOUS DRONE NATURE MISSION COMMANDER (IEEE 8491889)",
            font=("Segoe UI", 12, "bold"),
            fg="#F3F4F6",
            bg="#1F2937",
        )
        title_lbl.pack()

        subtitle_lbl = tk.Label(
            header_frame,
            text="1st: Start Place (White)  ➔  2nd: End Points (Light Red, keep as many as you wish!)  ➔  3rd: Place Obstacles  ➔  4th: Speed & Run",
            font=("Segoe UI", 8),
            fg="#9CA3AF",
            bg="#1F2937",
        )
        subtitle_lbl.pack()

        # ==================== 2. SPEED INPUT BAR (RANGE: 0.001 m/s to 1 m/s) ====================
        self.speed_bar = tk.Frame(self.root, bg="#1F2937", pady=5, padx=14, highlightbackground="#FBBF24", highlightcolor="#FBBF24", highlightthickness=1)
        self.speed_bar.pack(fill=tk.X, padx=12, pady=(2, 2))

        self.lbl_speed_title = tk.Label(
            self.speed_bar,
            text="⚡ Step 4: Speed (0.001 - 1.0 m/s):",
            font=("Segoe UI", 9, "bold"),
            fg="#FBBF24",
            bg="#1F2937",
        )
        self.lbl_speed_title.pack(side=tk.LEFT, padx=(0, 4))

        # Direct Speed Input Box
        self.ent_speed = tk.Entry(
            self.speed_bar,
            width=8,
            font=("Consolas", 10, "bold"),
            bg="#111827",
            fg="#FBBF24",
            insertbackground="#FFFFFF",
            justify="center",
        )
        self.ent_speed.pack(side=tk.LEFT, padx=(0, 6))
        self.ent_speed.insert(0, f"{self.cruise_speed:.3f}".rstrip("0").rstrip("."))
        self.ent_speed.bind("<Return>", lambda e: self.apply_speed_and_launch())

        # Main RUN FLIGHT button right beside speed entry
        self.btn_run_speed = tk.Button(
            self.speed_bar,
            text=f"🚀 RUN FLIGHT ({self.cruise_speed:.3f} m/s) ➔",
            font=("Segoe UI", 9, "bold"),
            bg="#059669",
            fg="#FFFFFF",
            activebackground="#10B981",
            relief=tk.FLAT,
            padx=10,
            pady=2,
            command=self.apply_speed_and_launch,
        )
        self.btn_run_speed.pack(side=tk.LEFT, padx=(0, 10))

        # Quick Preset Buttons strictly in [0.001, 1.0] m/s
        tk.Label(self.speed_bar, text="Presets:", font=("Segoe UI", 8), fg="#9CA3AF", bg="#1F2937").pack(side=tk.LEFT, padx=(0, 2))

        preset_speeds = [
            ("0.001", 0.001),
            ("0.01", 0.01),
            ("0.05", 0.05),
            ("0.1", 0.1),
            ("0.25", 0.25),
            ("0.5", 0.5),
            ("1.0", 1.0),
        ]
        for lbl, spd in preset_speeds:
            btn = tk.Button(
                self.speed_bar,
                text=lbl,
                font=("Segoe UI", 8),
                bg="#111827",
                fg="#F3F4F6",
                activebackground="#374151",
                relief=tk.FLAT,
                padx=5,
                pady=1,
                command=lambda s=spd: self.set_preset_speed(s),
            )
            btn.pack(side=tk.LEFT, padx=1)

        # Fine adjustment
        btn_minus = tk.Button(
            self.speed_bar,
            text="➖ -0.01",
            font=("Segoe UI", 8),
            bg="#111827",
            fg="#9CA3AF",
            relief=tk.FLAT,
            padx=4,
            pady=1,
            command=lambda: self.adjust_speed(-0.01),
        )
        btn_minus.pack(side=tk.LEFT, padx=(6, 1))

        btn_plus = tk.Button(
            self.speed_bar,
            text="➕ +0.01",
            font=("Segoe UI", 8),
            bg="#111827",
            fg="#9CA3AF",
            relief=tk.FLAT,
            padx=4,
            pady=1,
            command=lambda: self.adjust_speed(+0.01),
        )
        btn_plus.pack(side=tk.LEFT, padx=1)

        # 1-Click Launch 3D MuJoCo button
        btn_1click = tk.Button(
            self.speed_bar,
            text="⚡ 1-CLICK LAUNCH 3D MUJOCO",
            font=("Segoe UI", 8, "bold"),
            bg="#2563EB",
            fg="#FFFFFF",
            activebackground="#1D4ED8",
            relief=tk.FLAT,
            padx=10,
            pady=2,
            command=self.one_click_launch_mujoco,
        )
        btn_1click.pack(side=tk.RIGHT, padx=4)

        # Benchmark Example button
        btn_quick_ex = tk.Button(
            self.speed_bar,
            text="💡 Example (0,0 ➔ 12,0 | Stick 5,0)",
            font=("Segoe UI", 8, "bold"),
            bg="#374151",
            fg="#F3F4F6",
            activebackground="#4B5563",
            relief=tk.FLAT,
            padx=8,
            pady=2,
            command=self.load_quick_example,
        )
        btn_quick_ex.pack(side=tk.RIGHT, padx=2)

        # ==================== 3. STEP SELECTOR TABS ====================
        step_bar = tk.Frame(self.root, bg="#1F2937", pady=4, padx=14)
        step_bar.pack(fill=tk.X, padx=12, pady=(1, 2))

        self.btn_step1 = tk.Button(
            step_bar,
            text="1️⃣ 1st: Set Start (White)",
            font=("Segoe UI", 9, "bold"),
            bg="#059669",
            fg="#FFFFFF",
            relief=tk.FLAT,
            padx=8,
            pady=3,
            command=lambda: self.set_active_step(1),
        )
        self.btn_step1.pack(side=tk.LEFT, padx=2)

        self.btn_step2 = tk.Button(
            step_bar,
            text="2️⃣ 2nd: Set End Points (Light Red)",
            font=("Segoe UI", 9, "bold"),
            bg="#374151",
            fg="#9CA3AF",
            relief=tk.FLAT,
            padx=8,
            pady=3,
            command=lambda: self.set_active_step(2),
        )
        self.btn_step2.pack(side=tk.LEFT, padx=2)

        self.btn_step3 = tk.Button(
            step_bar,
            text="3️⃣ 3rd: Place Obstacles (Sticks)",
            font=("Segoe UI", 9, "bold"),
            bg="#374151",
            fg="#9CA3AF",
            relief=tk.FLAT,
            padx=8,
            pady=3,
            command=lambda: self.set_active_step(3),
        )
        self.btn_step3.pack(side=tk.LEFT, padx=2)

        self.btn_step4 = tk.Button(
            step_bar,
            text="4️⃣ 4th: Set Speed & Run 🚀",
            font=("Segoe UI", 9, "bold"),
            bg="#374151",
            fg="#9CA3AF",
            relief=tk.FLAT,
            padx=8,
            pady=3,
            command=lambda: self.set_active_step(4),
        )
        self.btn_step4.pack(side=tk.LEFT, padx=2)

        self.btn_clear_ends = tk.Button(
            step_bar,
            text="🧹 Clear Ends",
            font=("Segoe UI", 8),
            bg="#374151",
            fg="#F87171",
            relief=tk.FLAT,
            padx=5,
            pady=3,
            command=self.clear_all_endpoints,
        )
        self.btn_clear_ends.pack(side=tk.LEFT, padx=2)

        self.btn_clear_obs = tk.Button(
            step_bar,
            text="🧹 Clear Obstacles",
            font=("Segoe UI", 8),
            bg="#374151",
            fg="#F87171",
            relief=tk.FLAT,
            padx=5,
            pady=3,
            command=self.clear_all_obstacles,
        )
        self.btn_clear_obs.pack(side=tk.LEFT, padx=2)

        self.lbl_obs_count = tk.Label(
            step_bar,
            text="🥢 Obstacles: 0 placed",
            font=("Segoe UI", 8, "bold"),
            fg="#FBBF24",
            bg="#1F2937",
        )
        self.lbl_obs_count.pack(side=tk.RIGHT, padx=4)

        self.lbl_ends_count = tk.Label(
            step_bar,
            text="🎯 End Points: 0 placed",
            font=("Segoe UI", 8, "bold"),
            fg="#F87171",
            bg="#1F2937",
        )
        self.lbl_ends_count.pack(side=tk.RIGHT, padx=4)

        # ==================== 4. DYNAMIC INSTRUCTION BANNER ====================
        self.banner_frame = tk.Frame(self.root, bg="#065F46", pady=6)
        self.banner_frame.pack(fill=tk.X, padx=12, pady=(1, 2))

        self.banner_lbl = tk.Label(
            self.banner_frame,
            text="",
            font=("Segoe UI", 10, "bold"),
            fg="#FFFFFF",
            bg="#065F46",
        )
        self.banner_lbl.pack()

        # ==================== 5. DIRECT COORDINATES INPUT BAR ====================
        coord_frame = tk.Frame(self.root, bg="#1F2937", pady=5, padx=14)
        coord_frame.pack(fill=tk.X, padx=12, pady=1)

        tk.Label(coord_frame, text="1️⃣ Start [White]:", font=("Segoe UI", 8, "bold"), fg="#F3F4F6", bg="#1F2937").pack(side=tk.LEFT, padx=(0, 2))
        self.ent_start = tk.Entry(coord_frame, width=8, font=("Consolas", 9), bg="#111827", fg="#F3F4F6", insertbackground="#FFFFFF")
        self.ent_start.pack(side=tk.LEFT, padx=(0, 6))

        tk.Label(coord_frame, text="2️⃣ End [Light Red]:", font=("Segoe UI", 8, "bold"), fg="#F87171", bg="#1F2937").pack(side=tk.LEFT, padx=(0, 2))
        self.ent_goal = tk.Entry(coord_frame, width=8, font=("Consolas", 9), bg="#111827", fg="#F3F4F6", insertbackground="#FFFFFF")
        self.ent_goal.pack(side=tk.LEFT, padx=(0, 2))

        btn_add_end_manual = tk.Button(
            coord_frame,
            text="➕ Add End",
            font=("Segoe UI", 8, "bold"),
            bg="#DC2626",
            fg="#FFFFFF",
            relief=tk.FLAT,
            padx=4,
            command=self.add_typed_endpoint,
        )
        btn_add_end_manual.pack(side=tk.LEFT, padx=(0, 6))

        tk.Label(coord_frame, text="3️⃣ Stick [1 Colour]:", font=("Segoe UI", 8, "bold"), fg="#D97706", bg="#1F2937").pack(side=tk.LEFT, padx=(0, 2))
        self.ent_stick = tk.Entry(coord_frame, width=8, font=("Consolas", 9), bg="#111827", fg="#F3F4F6", insertbackground="#FFFFFF")
        self.ent_stick.pack(side=tk.LEFT, padx=(0, 2))

        btn_add_stick_manual = tk.Button(
            coord_frame,
            text="➕ Add Stick",
            font=("Segoe UI", 8, "bold"),
            bg="#059669",
            fg="#FFFFFF",
            relief=tk.FLAT,
            padx=4,
            command=self.add_typed_stick,
        )
        btn_add_stick_manual.pack(side=tk.LEFT, padx=(0, 6))

        btn_apply_coords = tk.Button(
            coord_frame,
            text="✅ Set Typed Coords",
            font=("Segoe UI", 8, "bold"),
            bg="#374151",
            fg="#6EE7B7",
            relief=tk.FLAT,
            padx=6,
            command=self.apply_text_coordinates,
        )
        btn_apply_coords.pack(side=tk.LEFT)

        lbl_hint = tk.Label(
            coord_frame,
            text="[Park Arena: X(-1.5 to 13.5m) | Y(-2.5 to +2.5m) | Z(1.5m cruise)]",
            font=("Consolas", 8, "italic"),
            fg="#9CA3AF",
            bg="#1F2937",
        )
        lbl_hint.pack(side=tk.RIGHT)

        # ==================== 6. INTERACTIVE PARK CANVAS (CLEAN NATURAL LOOK - NO BLUE TINT) ====================
        canvas_container = tk.Frame(self.root, bg="#111827", padx=12, pady=2)
        canvas_container.pack(fill=tk.BOTH, expand=False)

        self.canvas = tk.Canvas(
            canvas_container,
            width=self.CANVAS_W,
            height=self.CANVAS_H,
            bg="#42552B",
            highlightthickness=1,
            highlightbackground="#4B5563",
            cursor="crosshair",
        )
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self.on_canvas_click)

        # ==================== 7. ACTION CONTROLS & NEW JOURNEY BUTTON ====================
        btn_bar = tk.Frame(self.root, bg="#1F2937", pady=6, padx=14)
        btn_bar.pack(fill=tk.X, padx=12, pady=2)

        # Main Launch Button
        self.btn_launch = tk.Button(
            btn_bar,
            text="🚀 LAUNCH 3D NATURE FLIGHT",
            font=("Segoe UI", 9, "bold"),
            bg="#4B5563",
            fg="#FFFFFF",
            activebackground="#059669",
            relief=tk.FLAT,
            padx=10,
            pady=5,
            state=tk.DISABLED,
            command=self.launch_3d_simulation,
        )
        self.btn_launch.pack(side=tk.LEFT, padx=3)

        # Quick Advance Button
        self.btn_next_step = tk.Button(
            btn_bar,
            text="➔ Proceed to Step 2: Set End Points",
            font=("Segoe UI", 9, "bold"),
            bg="#2563EB",
            fg="#FFFFFF",
            activebackground="#1D4ED8",
            relief=tk.FLAT,
            padx=10,
            pady=5,
            command=self.proceed_to_next_step,
        )
        self.btn_next_step.pack(side=tk.LEFT, padx=3)

        # CONTINUOUS NEW JOURNEY BUTTON ("see new journey from there")
        self.btn_new_journey = tk.Button(
            btn_bar,
            text="🚀 FLY NEW JOURNEY FROM HERE",
            font=("Segoe UI", 9, "bold"),
            bg="#4B5563",
            fg="#FFFFFF",
            activebackground="#059669",
            relief=tk.FLAT,
            padx=10,
            pady=5,
            state=tk.DISABLED,
            command=self.fly_new_journey_from_here,
        )
        self.btn_new_journey.pack(side=tk.LEFT, padx=3)

        # Add Stick Ahead
        self.btn_drop = tk.Button(
            btn_bar,
            text="🥢 Add Stick Ahead",
            font=("Segoe UI", 8, "bold"),
            bg="#059669",
            fg="#FFFFFF",
            relief=tk.FLAT,
            padx=8,
            pady=5,
            command=self.move_stick_ahead,
        )
        self.btn_drop.pack(side=tk.LEFT, padx=3)

        # Center Stick on Path
        self.btn_center_stick = tk.Button(
            btn_bar,
            text="🎯 Center Stick on Path",
            font=("Segoe UI", 8),
            bg="#374151",
            fg="#F3F4F6",
            relief=tk.FLAT,
            padx=8,
            pady=5,
            command=self.center_stick_on_path,
        )
        self.btn_center_stick.pack(side=tk.LEFT, padx=3)

        # Reset Positions
        self.btn_reset = tk.Button(
            btn_bar,
            text="🧹 Clear / Start Over",
            font=("Segoe UI", 8),
            bg="#DC2626",
            fg="#FFFFFF",
            activebackground="#B91C1C",
            relief=tk.FLAT,
            padx=8,
            pady=5,
            command=self.start_new_flight_again,
        )
        self.btn_reset.pack(side=tk.LEFT, padx=3)

        # ==================== 8. LIVE TELEMETRY HUD BAR ====================
        hud_bar = tk.Frame(self.root, bg="#111827", pady=6, padx=14)
        hud_bar.pack(fill=tk.X, side=tk.BOTTOM)

        self.hud_status = tk.Label(
            hud_bar,
            text="STATUS: Step 1 of 3: Please choose STARTING PLACE.",
            font=("Consolas", 9, "bold"),
            fg="#6EE7B7",
            bg="#111827",
        )
        self.hud_status.pack(side=tk.LEFT)

        self.hud_stick_info = tk.Label(
            hud_bar,
            text="STICK OBSTACLES: 0 placed",
            font=("Consolas", 9, "bold"),
            fg="#FBBF24",
            bg="#111827",
        )
        self.hud_stick_info.pack(side=tk.RIGHT)

    def apply_speed_from_entry(self):
        """Reads speed entered in the text box in range [0.001, 1.0]."""
        val = self.parse_speed_text(self.ent_speed.get())
        self.cruise_speed = val
        self.ent_speed.delete(0, tk.END)
        self.ent_speed.insert(0, f"{val:.3f}".rstrip("0").rstrip("."))
        if hasattr(self, "btn_run_speed"):
            self.btn_run_speed.configure(text=f"🚀 RUN FLIGHT ({val:.3f} m/s) ➔")
        if hasattr(self, "btn_launch"):
            self.btn_launch.configure(text=f"🚀 RUN FLIGHT ({val:.3f} m/s)")
        if self.sim_running and self.sim is not None:
            self.sim.cruise_speed = val
            self.sim.controller.v_cruise = val
            self.hud_status.configure(text=f"STATUS: ⚡ Cruise Speed updated to {val:.3f} m/s!")
        else:
            self.hud_status.configure(text=f"STATUS: ⚡ Starting Speed fixed at {val:.3f} m/s.")

    def set_preset_speed(self, speed: float):
        """Sets one of the presets in [0.001, 1.0]."""
        clamped = max(0.001, min(1.0, float(speed)))
        self.cruise_speed = clamped
        self.ent_speed.delete(0, tk.END)
        self.ent_speed.insert(0, f"{clamped:.3f}".rstrip("0").rstrip("."))
        if hasattr(self, "btn_run_speed"):
            self.btn_run_speed.configure(text=f"🚀 RUN FLIGHT ({clamped:.3f} m/s) ➔")
        if hasattr(self, "btn_launch"):
            self.btn_launch.configure(text=f"🚀 RUN FLIGHT ({clamped:.3f} m/s)")
        if self.sim_running and self.sim is not None:
            self.sim.cruise_speed = clamped
            self.sim.controller.v_cruise = clamped
            self.hud_status.configure(text=f"STATUS: ⚡ Preset Speed selected: {clamped:.3f} m/s!")
        else:
            self.hud_status.configure(text=f"STATUS: ⚡ Starting Speed fixed: {clamped:.3f} m/s.")

    def apply_speed_and_launch(self):
        """Reads speed entered by user, confirms it, and immediately starts flight."""
        val = self.parse_speed_text(self.ent_speed.get())
        self.cruise_speed = val
        self.ent_speed.delete(0, tk.END)
        self.ent_speed.insert(0, f"{val:.3f}".rstrip("0").rstrip("."))
        if hasattr(self, "btn_run_speed"):
            self.btn_run_speed.configure(text=f"🚀 RUN FLIGHT ({val:.3f} m/s) ➔")
        if hasattr(self, "btn_launch"):
            self.btn_launch.configure(text=f"🚀 RUN FLIGHT ({val:.3f} m/s)")
            
        if self.at_destination_standby:
            self.fly_new_journey_from_here()
        else:
            self.launch_3d_simulation()

    def adjust_speed(self, delta: float):
        """Fine speed adjustment."""
        new_val = max(0.001, min(1.0, round(self.cruise_speed + delta, 3)))
        self.set_preset_speed(new_val)

    def set_active_step(self, step: int):
        """Allows user to select which location to set or edit."""
        self.step = step
        self.update_step_banner()
        self._redraw_mission_elements()

    def proceed_to_next_step(self):
        """Advances smoothly to the next sequential mission step."""
        if self.step == 1:
            if self.start_pos is None:
                messagebox.showwarning("Start Place Required", "Please click on the map to set the 1st Starting Place (White Helipad).")
                return
            self.set_active_step(2)
        elif self.step == 2:
            if not self.end_points:
                messagebox.showwarning("Ending Points Required", "Please click on the map to place at least one Ending Point (Light Red Helipad).")
                return
            self.set_active_step(3)
        elif self.step == 3:
            if not self.obstacles:
                messagebox.showwarning("Obstacles Required", "Please click on the map to place at least one Stick Obstacle.")
                return
            self.set_active_step(4)
        elif self.step == 4:
            self.apply_speed_and_launch()

    def add_typed_endpoint(self):
        """Adds ending point from coordinates typed in End entry box."""
        g_text = self.ent_goal.get().strip()
        if not g_text:
            return
        try:
            g_raw = g_text.replace(",", " ").split()
            gx = max(self.RECT_X_MIN + 0.3, min(self.RECT_X_MAX - 0.3, float(g_raw[0])))
            gy = max(self.RECT_Y_MIN + 0.3, min(self.RECT_Y_MAX - 0.3, float(g_raw[1])))
            new_pt = (round(gx, 2), round(gy, 2))
            self.end_points.append(new_pt)
            self.goal_pos = new_pt
            self.update_step_banner()
            self._redraw_mission_elements()
            self.hud_status.configure(text=f"STATUS: Added End Point #{len(self.end_points)} at ({gx:.2f}, {gy:.2f})m!")
        except Exception as e:
            messagebox.showerror("Invalid Coordinates", f"Please enter valid 'X, Y' numbers:\n{e}")

    def clear_all_endpoints(self):
        """Clears all placed ending points."""
        self.end_points = []
        self.goal_pos = None
        self.ent_goal.delete(0, tk.END)
        self.step = 2
        self.update_step_banner()
        self._redraw_mission_elements()
        self.hud_status.configure(text="STATUS: Cleared all ending points. Click canvas to add new ones.")

    def update_step_banner(self):
        """Updates the guidance banner according to planning step or live flight state."""
        n_ends = len(self.end_points)
        n_obs = len(self.obstacles)
        if hasattr(self, "lbl_ends_count"):
            self.lbl_ends_count.configure(text=f"🎯 End Points: {n_ends} placed")
        if hasattr(self, "lbl_obs_count"):
            self.lbl_obs_count.configure(text=f"🥢 Obstacles: {n_obs} placed")

        if self.step == 1:
            self.btn_step1.configure(bg="#059669", fg="#FFFFFF")
            self.btn_step2.configure(bg="#374151", fg="#9CA3AF")
            self.btn_step3.configure(bg="#374151", fg="#9CA3AF")
            self.btn_step4.configure(bg="#374151", fg="#9CA3AF")
            if hasattr(self, "btn_next_step"):
                self.btn_next_step.configure(text="➔ Proceed to Step 2: Set End Points", bg="#2563EB")
            if hasattr(self, "speed_bar"):
                self.speed_bar.configure(highlightbackground="#4B5563")
        elif self.step == 2:
            self.btn_step1.configure(bg="#065F46", fg="#A7F3D0")
            self.btn_step2.configure(bg="#DC2626", fg="#FFFFFF")
            self.btn_step3.configure(bg="#374151", fg="#9CA3AF")
            self.btn_step4.configure(bg="#374151", fg="#9CA3AF")
            if hasattr(self, "btn_next_step"):
                self.btn_next_step.configure(text="➔ Proceed to Step 3: Place Obstacles", bg="#D97706")
            if hasattr(self, "speed_bar"):
                self.speed_bar.configure(highlightbackground="#4B5563")
        elif self.step == 3:
            self.btn_step1.configure(bg="#065F46", fg="#A7F3D0")
            self.btn_step2.configure(bg="#7F1D1D", fg="#FCA5A5")
            self.btn_step3.configure(bg="#D97706", fg="#FFFFFF")
            self.btn_step4.configure(bg="#374151", fg="#9CA3AF")
            if hasattr(self, "btn_next_step"):
                self.btn_next_step.configure(text="➔ Proceed to Step 4: Speed & Run 🚀", bg="#059669")
            if hasattr(self, "speed_bar"):
                self.speed_bar.configure(highlightbackground="#4B5563")
        elif self.step == 4:
            self.btn_step1.configure(bg="#065F46", fg="#A7F3D0")
            self.btn_step2.configure(bg="#7F1D1D", fg="#FCA5A5")
            self.btn_step3.configure(bg="#78350F", fg="#FDE68A")
            self.btn_step4.configure(bg="#059669", fg="#FFFFFF")
            if hasattr(self, "btn_next_step"):
                self.btn_next_step.configure(text=f"🚀 RUN FLIGHT ({self.cruise_speed:.3f} m/s)", bg="#10B981")
            if hasattr(self, "speed_bar"):
                self.speed_bar.configure(highlightbackground="#10B981")

        if self.at_destination_standby:
            self.banner_frame.configure(bg="#059669")
            self.banner_lbl.configure(
                text=f"✅ TASK FINISHED! Drone landed on ground (Motors Off).  👉 Click map to add NEW End Points & fly again!",
                bg="#059669",
            )
            if self.end_points:
                self.btn_new_journey.configure(state=tk.NORMAL, bg="#10B981")
                self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")
            else:
                self.btn_new_journey.configure(state=tk.DISABLED, bg="#4B5563")

        elif self.sim_running:
            if self.drone_live_state.get("alert", False):
                self.banner_frame.configure(bg="#991B1B")
                self.banner_lbl.configure(
                    text="🚨 5-LIDAR SENSORS ALERT! Evading obstacle with 80° panoramic 5-beam array and smooth clearance!",
                    bg="#991B1B",
                )
            else:
                self.banner_frame.configure(bg="#1E3A8A")
                self.banner_lbl.configure(
                    text=f"🛸 3D DRONE EN ROUTE (Speed: {self.cruise_speed:.3f} m/s) ▶ Sequential ground touchdowns active!",
                    bg="#1E3A8A",
                )
        elif self.step == 1:
            self.banner_frame.configure(bg="#065F46")
            self.banner_lbl.configure(
                text="📍 STEP 1: CLICK ON MAP TO SET 1st START PLACE (White Helipad) [or type X, Y and click Set]",
                bg="#065F46",
            )
        elif self.step == 2:
            self.banner_frame.configure(bg="#991B1B")
            self.banner_lbl.configure(
                text=f"🎯 STEP 2: CLICK MAP TO ADD ENDING POINTS ({n_ends} placed). Keep as many as you wish! When done, click 'Proceed to Step 3'.",
                bg="#991B1B",
            )
        elif self.step == 3:
            self.banner_frame.configure(bg="#B45309")
            self.banner_lbl.configure(
                text=f"🥢 STEP 3: CLICK MAP TO PLACE STICK OBSTACLES ({n_obs} placed, 1-colour). When done, click 'Proceed to Step 4'.",
                bg="#B45309",
            )
        elif self.step == 4:
            self.banner_frame.configure(bg="#047857")
            self.banner_lbl.configure(
                text=f"⚡ STEP 4: ENTER YOUR DESIRED FLIGHT SPEED (0.001 - 1.0 m/s) ➔ CLICK 'RUN FLIGHT' TO COMMENCE MISSION!",
                bg="#047857",
            )
            self.btn_launch.configure(state=tk.NORMAL, bg="#10B981")
            self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")

    def _draw_park_background(self):
        """Draws realistic open nature park (Zero blue transparency)."""
        self.canvas.delete("all")

        # 1. Daylight Sky (Natural soft daylight - No neon blue)
        self.canvas.create_rectangle(0, 0, self.CANVAS_W, 55, fill="#688EA8", outline="")
        self.canvas.create_oval(110, 8, 190, 28, fill="#E6EEF4", outline="")
        self.canvas.create_oval(160, 5, 260, 30, fill="#E6EEF4", outline="")
        self.canvas.create_oval(520, 10, 630, 32, fill="#E6EEF4", outline="")
        self.canvas.create_oval(820, 6, 920, 28, fill="#E6EEF4", outline="")

        # Rolling Mountains Horizon
        mountain_pts = [
            0, 60,
            60, 28,
            150, 42,
            240, 18,
            330, 38,
            420, 15,
            510, 32,
            600, 14,
            700, 38,
            800, 20,
            900, 36,
            self.CANVAS_W, 25,
            self.CANVAS_W, 60,
            0, 60,
        ]
        self.canvas.create_polygon(mountain_pts, fill="#756453", outline="#5A4B3D", width=2)

        # 2. Expansive Meadow Grass Ground (Olive green nature)
        self.canvas.create_rectangle(0, 60, self.CANVAS_W, self.CANVAS_H, fill="#4D6234", outline="")

        # Arena Flight Boundary Line (Clean white sports chalk line - ZERO blue glass)
        rx1, ry1 = self.world_to_screen(self.RECT_X_MIN, self.RECT_Y_MAX)
        rx2, ry2 = self.world_to_screen(self.RECT_X_MAX, self.RECT_Y_MIN)
        self.canvas.create_rectangle(rx1, ry1, rx2, ry2, fill="", outline="#D4DED0", width=2, dash=(6, 6))

        # Natural Wood Corner Boundary Markers
        for cx, cy in [
            (self.RECT_X_MIN, self.RECT_Y_MAX),
            (self.RECT_X_MAX, self.RECT_Y_MAX),
            (self.RECT_X_MIN, self.RECT_Y_MIN),
            (self.RECT_X_MAX, self.RECT_Y_MIN),
        ]:
            px, py = self.world_to_screen(cx, cy)
            self.canvas.create_oval(px - 5, py - 5, px + 5, py + 5, fill="#3A2A1D", outline="#1F150D", width=2)

        # Centerline Guideline
        c_x1, c_y1 = self.world_to_screen(self.RECT_X_MIN, 0.0)
        c_x2, c_y2 = self.world_to_screen(self.RECT_X_MAX, 0.0)
        self.canvas.create_line(c_x1, c_y1, c_x2, c_y2, fill="#637C44", dash=(8, 8), width=2)

        # Grass Vegetation Tufts
        for gx, gy in [(1.5, 1.2), (3.2, -1.8), (8.4, -1.4), (10.5, 1.9), (-1.2, -1.2)]:
            tx, ty = self.world_to_screen(gx, gy)
            self.canvas.create_text(tx, ty, text="🌿", font=("Segoe UI", 9), fill="#709148")

        # Background Trees outside arena
        for bx, by in [(-2.2, 3.2), (4.0, 3.3), (10.0, 3.2), (14.2, 3.3), (-2.2, -3.2), (5.0, -3.3), (12.0, -3.2)]:
            tx, ty = self.world_to_screen(bx, by)
            self.canvas.create_line(tx, ty + 10, tx, ty, fill="#2F2116", width=2)
            self.canvas.create_oval(tx - 10, ty - 14, tx + 10, ty, fill="#2E421B", outline="#1F2D12")

        # Coordinate Grid Lines
        for x in range(int(self.X_MIN), int(self.X_MAX) + 1, 2):
            gx, _ = self.world_to_screen(x, 0)
            self.canvas.create_line(gx, 60, gx, self.CANVAS_H, fill="#384A24", dash=(2, 6), width=1)
            self.canvas.create_text(gx, self.CANVAS_H - 10, text=f"{x}m", font=("Consolas", 7), fill="#A3C280")

        for y in range(int(self.Y_MIN), int(self.Y_MAX) + 1, 2):
            _, gy = self.world_to_screen(0, y)
            self.canvas.create_line(0, gy, self.CANVAS_W, gy, fill="#384A24", dash=(2, 6), width=1)
            self.canvas.create_text(18, gy, text=f"{y:+}m", font=("Consolas", 7), fill="#A3C280")

        self._redraw_mission_elements()

    def on_canvas_click(self, event):
        """Handles canvas clicks: 1st Start -> 2nd End -> 3rd Obstacle."""
        wx, wy = self.screen_to_world(event.x, event.y)
        wx = max(self.RECT_X_MIN + 0.3, min(self.RECT_X_MAX - 0.3, wx))
        wy = max(self.RECT_Y_MIN + 0.3, min(self.RECT_Y_MAX - 0.3, wy))

        # If drone is parked/hovering at destination, clicking sets a NEW End destination!
        if self.at_destination_standby:
            if self.step == 2:
                self.end_points.append((wx, wy))
                self.goal_pos = (wx, wy)
                self.ent_goal.delete(0, tk.END)
                self.ent_goal.insert(0, f"{wx:.1f}, {wy:.1f}")
                self.hud_status.configure(text=f"STATUS: Added End Point #{len(self.end_points)} at ({wx:.2f}, {wy:.2f})m! Click to add more or place obstacle.")
            elif self.step == 3:
                self.obstacles.append((wx, wy))
                self.stick_pos = (wx, wy)
                self.obstacle_queue.put((wx, wy))
                self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
                self.hud_status.configure(text=f"STATUS: Added Obstacle at ({wx:.2f}, {wy:.2f})m! STEP 4: Enter flight speed & click RUN FLIGHT.")
                self.btn_new_journey.configure(state=tk.NORMAL, bg="#10B981")
                self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")
            elif self.step == 4:
                self.obstacles.append((wx, wy))
                self.stick_pos = (wx, wy)
                self.obstacle_queue.put((wx, wy))
                self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
                self.hud_status.configure(text=f"STATUS: Added Obstacle at ({wx:.2f}, {wy:.2f})m! Click RUN FLIGHT to launch.")
            self.update_step_banner()
            self._redraw_mission_elements()
            return

        if self.sim_running:
            # During live flight: clicking adds another stick obstacle live!
            self.obstacles.append((wx, wy))
            self.obstacle_queue.put((wx, wy))
            self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
            self.hud_status.configure(text=f"STATUS: 🥢 Live-placed Obstacle #{len(self.obstacles)} at ({wx:.2f}, {wy:.2f})m!")
            self._redraw_mission_elements()
            return

        # Step 1: Set Starting Place (1 Starting Place)
        if self.step == 1:
            self.start_pos = (wx, wy)
            self.ent_start.delete(0, tk.END)
            self.ent_start.insert(0, f"{wx:.1f}, {wy:.1f}")
            self.hud_status.configure(text=f"STATUS: 1st Starting Place set at ({wx:.2f}, {wy:.2f})m! Now click to place Ending Points (keep as many as you wish).")
            self.step = 2
            self.update_step_banner()
            self._redraw_mission_elements()

        # Step 2: Set Ending Points (User can place multiple ending points!)
        elif self.step == 2:
            self.end_points.append((wx, wy))
            self.goal_pos = (wx, wy)
            self.ent_goal.delete(0, tk.END)
            self.ent_goal.insert(0, f"{wx:.1f}, {wy:.1f}")
            self.hud_status.configure(
                text=f"STATUS: Added End Point #{len(self.end_points)} at ({wx:.2f}, {wy:.2f})m! Add more, or click 'Proceed to Step 3: Place Obstacles'."
            )
            self.update_step_banner()
            self._redraw_mission_elements()

        # Step 3: Place Obstacles (User can place multiple stick obstacles!)
        elif self.step == 3:
            # Helipad safety exclusion check: require safe clearance from takeoff and landing pads
            if self.start_pos and np.hypot(wx - self.start_pos[0], wy - self.start_pos[1]) < 1.0:
                self.hud_status.configure(text=f"⚠️ Obstacle too close to Start Helipad (>= 1.0m clearance required for safe takeoff).")
                return
            for idx_ep, ep in enumerate(self.end_points):
                if np.hypot(wx - ep[0], wy - ep[1]) < 0.9:
                    self.hud_status.configure(text=f"⚠️ Obstacle too close to End Point #{idx_ep+1} (>= 0.9m clearance required for safe landing).")
                    return

            self.obstacles.append((wx, wy))
            self.stick_pos = (wx, wy)
            self.ent_stick.delete(0, tk.END)
            self.ent_stick.insert(0, f"{wx:.1f}, {wy:.1f}")
            self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
            self.hud_status.configure(
                text=f"STATUS: Added Obstacle #{len(self.obstacles)} at ({wx:.2f}, {wy:.2f})m! Add more, or click 'Proceed to Step 4: Speed & Run'."
            )
            self.btn_launch.configure(state=tk.NORMAL, bg="#10B981")
            self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")
            self.update_step_banner()
            self._redraw_mission_elements()

        # Step 4: Can place additional obstacles if desired
        elif self.step == 4:
            if self.start_pos and np.hypot(wx - self.start_pos[0], wy - self.start_pos[1]) < 1.0:
                self.hud_status.configure(text=f"⚠️ Obstacle too close to Start Helipad (>= 1.0m clearance required for safe takeoff).")
                return
            for idx_ep, ep in enumerate(self.end_points):
                if np.hypot(wx - ep[0], wy - ep[1]) < 0.9:
                    self.hud_status.configure(text=f"⚠️ Obstacle too close to End Point #{idx_ep+1} (>= 0.9m clearance required for safe landing).")
                    return

            self.obstacles.append((wx, wy))
            self.stick_pos = (wx, wy)
            self.ent_stick.delete(0, tk.END)
            self.ent_stick.insert(0, f"{wx:.1f}, {wy:.1f}")
            self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
            self.hud_status.configure(text=f"STATUS: 🥢 Added Obstacle #{len(self.obstacles)} at ({wx:.2f}, {wy:.2f})m! Enter speed & click RUN FLIGHT.")
            self._redraw_mission_elements()

    def add_typed_stick(self):
        """Adds obstacle from coordinates typed in Stick entry box."""
        st_text = self.ent_stick.get().strip()
        if not st_text:
            return
        try:
            st_raw = st_text.replace(",", " ").split()
            st_x = max(self.RECT_X_MIN + 0.3, min(self.RECT_X_MAX - 0.3, float(st_raw[0])))
            st_y = max(self.RECT_Y_MIN + 0.3, min(self.RECT_Y_MAX - 0.3, float(st_raw[1])))
            new_stick = (round(st_x, 2), round(st_y, 2))
            self.obstacles.append(new_stick)
            self.stick_pos = new_stick
            self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
            if self.sim_running:
                self.obstacle_queue.put(new_stick)
            else:
                self.step = 4
                self.ent_speed.focus_set()
                self.ent_speed.select_range(0, tk.END)
            self.btn_launch.configure(state=tk.NORMAL, bg="#10B981")
            self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")
            self.update_step_banner()
            self._redraw_mission_elements()
            self.hud_status.configure(text=f"STATUS: Added Obstacle #{len(self.obstacles)} at ({st_x:.2f}, {st_y:.2f})m! STEP 4: Enter flight speed & click RUN FLIGHT.")
        except Exception as e:
            messagebox.showerror("Invalid Coordinates", f"Please enter valid 'X, Y' numbers:\n{e}")

    def clear_all_obstacles(self):
        """Clears all placed obstacles."""
        self.obstacles = []
        self.stick_pos = None
        self.ent_stick.delete(0, tk.END)
        self.hud_stick_info.configure(text="STICK OBSTACLES: 0 placed")
        if self.sim_running and self.sim is not None:
            self.sim.clear_stick_obstacles()
        self.update_step_banner()
        self._redraw_mission_elements()
        self.hud_status.configure(text="STATUS: Cleared all obstacles. Click canvas to place new ones.")

    def apply_text_coordinates(self):
        """Applies coordinates from text boxes."""
        try:
            s_text = self.ent_start.get().strip()
            if s_text:
                s_raw = s_text.replace(",", " ").split()
                sx = max(self.RECT_X_MIN + 0.3, min(self.RECT_X_MAX - 0.3, float(s_raw[0])))
                sy = max(self.RECT_Y_MIN + 0.3, min(self.RECT_Y_MAX - 0.3, float(s_raw[1])))
                self.start_pos = (round(sx, 2), round(sy, 2))

            g_text = self.ent_goal.get().strip()
            if g_text:
                g_raw = g_text.replace(",", " ").split()
                gx = max(self.RECT_X_MIN + 0.3, min(self.RECT_X_MAX - 0.3, float(g_raw[0])))
                gy = max(self.RECT_Y_MIN + 0.3, min(self.RECT_Y_MAX - 0.3, float(g_raw[1])))
                pt = (round(gx, 2), round(gy, 2))
                if pt not in self.end_points:
                    self.end_points.append(pt)
                self.goal_pos = pt

            self.apply_speed_from_entry()

            if self.start_pos is None:
                self.step = 1
            elif not self.end_points:
                self.step = 2
            elif not self.obstacles:
                self.step = 3
            else:
                self.step = 4

            self.update_step_banner()
            self._redraw_mission_elements()
            self.hud_status.configure(text="STATUS: Applied coordinates and fixed speed.")
        except Exception as e:
            messagebox.showerror("Invalid Input", f"Please enter valid numbers:\n{e}")

    def load_quick_example(self):
        """Benchmark: Start (0,0), End Points [(4.0, 1.0), (8.0, -1.0), (12.0, 0.0)], Stick (6.0, 0.0), Speed 0.1 m/s."""
        self.start_pos = (0.0, 0.0)
        self.end_points = [(4.0, 1.0), (8.0, -1.0), (12.0, 0.0)]
        self.goal_pos = self.end_points[-1]
        self.obstacles = [(6.0, 0.0)]
        self.stick_pos = (6.0, 0.0)
        self.cruise_speed = 0.10

        self.ent_start.delete(0, tk.END); self.ent_start.insert(0, "0.0, 0.0")
        self.ent_goal.delete(0, tk.END); self.ent_goal.insert(0, "12.0, 0.0")
        self.ent_stick.delete(0, tk.END); self.ent_stick.insert(0, "6.0, 0.0")
        self.ent_speed.delete(0, tk.END); self.ent_speed.insert(0, "0.100")

        self.step = 4
        self.hud_stick_info.configure(text="STICK OBSTACLES: 1 placed (6.0, 0.0)m")
        self.btn_launch.configure(state=tk.NORMAL, bg="#10B981")
        self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")
        self.update_step_banner()
        self._redraw_mission_elements()
        self.hud_status.configure(text="STATUS: Benchmark loaded with 3 End Points & 1 Stick! Click 'RUN FLIGHT' to launch.")
        self.ent_speed.focus_set()
        self.ent_speed.select_range(0, tk.END)

    def one_click_launch_mujoco(self):
        """Immediately loads benchmark points and launches the 3D MuJoCo simulation window."""
        self.load_quick_example()
        self.root.after(120, self.launch_3d_simulation)

    def move_stick_ahead(self):
        """Adds an obstacle 2.5m ahead of drone heading."""
        if self.sim_running:
            dx = self.drone_live_state["x"]
            dy = self.drone_live_state["y"]
            yaw_rad = np.deg2rad(self.drone_live_state["yaw"])
            ox = round(dx + 2.5 * math.cos(yaw_rad), 2)
            oy = round(dy + 2.5 * math.sin(yaw_rad), 2)
        else:
            s = self.start_pos if self.start_pos else (0.0, 0.0)
            g = self.goal_pos if self.goal_pos else (12.0, 0.0)
            ox = round((s[0] + g[0]) / 2.0, 2)
            oy = round((s[1] + g[1]) / 2.0, 2)

        ox = max(self.RECT_X_MIN + 0.3, min(self.RECT_X_MAX - 0.3, ox))
        oy = max(self.RECT_Y_MIN + 0.3, min(self.RECT_Y_MAX - 0.3, oy))
        new_obs = (ox, oy)
        self.obstacles.append(new_obs)
        self.stick_pos = new_obs
        self.ent_stick.delete(0, tk.END)
        self.ent_stick.insert(0, f"{ox:.1f}, {oy:.1f}")
        self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
        if not self.sim_running:
            self.step = 4
            self.btn_launch.configure(state=tk.NORMAL, bg="#10B981")
            self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")
            self.ent_speed.focus_set()
            self.ent_speed.select_range(0, tk.END)
        self.update_step_banner()
        self._redraw_mission_elements()

    def center_stick_on_path(self):
        """Places stick obstacle at midpoint between start and goal on flight centerline."""
        s = self.start_pos if self.start_pos else (0.0, 0.0)
        g = self.goal_pos if self.goal_pos else (12.0, 0.0)
        ox = round((s[0] + g[0]) / 2.0, 2)
        oy = round((s[1] + g[1]) / 2.0, 2)
        new_obs = (ox, oy)
        self.obstacles.append(new_obs)
        self.stick_pos = new_obs
        self.ent_stick.delete(0, tk.END)
        self.ent_stick.insert(0, f"{ox:.1f}, {oy:.1f}")
        self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
        if self.sim_running:
            self.obstacle_queue.put(new_obs)
        else:
            self.step = 4
            self.btn_launch.configure(state=tk.NORMAL, bg="#10B981")
            self.btn_run_speed.configure(state=tk.NORMAL, bg="#059669")
            self.ent_speed.focus_set()
            self.ent_speed.select_range(0, tk.END)
        self.hud_status.configure(text=f"STATUS: 🥢 Centered Obstacle #{len(self.obstacles)} on path at ({ox:.1f}, {oy:.1f})m! STEP 4: Enter flight speed & click RUN FLIGHT.")
        self.update_step_banner()
        self._redraw_mission_elements()
        if self.sim_running:
            self.obstacle_queue.put(new_obs)
            self.hud_status.configure(text=f"STATUS: 🥢 Added Obstacle #{len(self.obstacles)} 2.5m ahead at ({ox:.2f}, {oy:.2f})m!")
        else:
            self.hud_status.configure(text=f"STATUS: 🥢 Placed Obstacle #{len(self.obstacles)} at ({ox:.2f}, {oy:.2f})m!")
        self.update_step_banner()
        self._redraw_mission_elements()

    def center_stick_on_path(self):
        """Places obstacle at midpoint of flight path."""
        s = self.start_pos if self.start_pos else (0.0, 0.0)
        g = self.goal_pos if self.goal_pos else (12.0, 0.0)
        ox = round((s[0] + g[0]) / 2.0, 2)
        oy = round((s[1] + g[1]) / 2.0, 2)
        new_obs = (ox, oy)
        self.obstacles.append(new_obs)
        self.stick_pos = new_obs
        self.ent_stick.delete(0, tk.END)
        self.ent_stick.insert(0, f"{ox:.1f}, {oy:.1f}")
        self.hud_stick_info.configure(text=f"STICK OBSTACLES: {len(self.obstacles)} placed")
        if self.sim_running:
            self.obstacle_queue.put(new_obs)
        self.hud_status.configure(text=f"STATUS: 🥢 Centered Obstacle #{len(self.obstacles)} on path at ({ox:.1f}, {oy:.1f})m!")
        self.update_step_banner()
        self._redraw_mission_elements()

    def fly_new_journey_from_here(self):
        """
        Continuously starts a new journey from the drone's current destination spot
        WITHOUT closing the 3D window!
        """
        if not self.end_points:
            messagebox.showwarning("Missing End Place", "Please click on the map to set the NEW End Points first!")
            return

        final_goal = self.end_points[-1]
        self.apply_speed_from_entry()
        self.at_destination_standby = False
        self.has_spoken_finished = False
        self.journey_count += 1

        # Send command to background MuJoCo simulation thread
        journey_cmd = {
            "goal": final_goal,
            "waypoints": list(self.end_points),
            "obstacles": list(self.obstacles),
            "speed": self.cruise_speed,
        }
        self.journey_queue.put(journey_cmd)

        self.btn_new_journey.configure(state=tk.DISABLED, bg="#4B5563")
        self.hud_status.configure(text=f"STATUS: 🚀 Flying Journey #{self.journey_count} with {len(self.end_points)} End Points at {self.cruise_speed:.3f} m/s!")
        self.update_step_banner()
        self._redraw_mission_elements()

    def start_new_flight_again(self):
        """Completely resets all mission points and stops simulation."""
        self.sim_running = False
        time.sleep(0.15)
        self.step = 1
        self.start_pos = None
        self.end_points = []
        self.goal_pos = None
        self.obstacles = []
        self.stick_pos = None
        self.at_destination_standby = False
        self.has_spoken_finished = False
        self.journey_count = 1
        self.ent_start.delete(0, tk.END)
        self.ent_goal.delete(0, tk.END)
        self.ent_stick.delete(0, tk.END)
        self.btn_launch.configure(state=tk.DISABLED, bg="#4B5563")
        self.btn_new_journey.configure(state=tk.DISABLED, bg="#4B5563")
        if hasattr(self, "btn_run_speed"):
            self.btn_run_speed.configure(state=tk.DISABLED, bg="#4B5563")
        if hasattr(self, "lbl_ends_count"):
            self.lbl_ends_count.configure(text="🎯 End Points: 0 placed")
        if hasattr(self, "lbl_obs_count"):
            self.lbl_obs_count.configure(text="🥢 Obstacles: 0 placed")
        self.update_step_banner()
        self._draw_park_background()
        self.hud_status.configure(text="STATUS: Reset complete. 1st: Click on map to set STARTING PLACE (White).")

    def _redraw_mission_elements(self):
        """Draws helipads, flight path corridor, and placed stick obstacles on canvas."""
        self.canvas.delete("mission_item")

        mid_x, mid_y = self.world_to_screen(6.0, 0.0)
        if self.start_pos is None:
            self.canvas.create_text(
                mid_x, mid_y,
                text="👉 1ST: CLICK HERE TO SET STARTING PLACE (White)",
                font=("Segoe UI", 12, "bold"),
                fill="#FFFFFF",
                tags="mission_item",
            )
        elif not self.end_points:
            self.canvas.create_text(
                mid_x, mid_y,
                text="👉 2ND: CLICK TO PLACE ENDING POINTS (Light Red) — Keep as many as you wish!",
                font=("Segoe UI", 12, "bold"),
                fill="#F87171",
                tags="mission_item",
            )
        elif not self.obstacles:
            self.canvas.create_text(
                mid_x, mid_y,
                text="👉 3RD: CLICK HERE TO PLACE OBSTACLES (1-Colour Sticks)",
                font=("Segoe UI", 12, "bold"),
                fill="#FBBF24",
                tags="mission_item",
            )
        elif self.step == 4 and not self.sim_running:
            self.canvas.create_text(
                mid_x, mid_y,
                text=f"⚡ STEP 4: ENTER SPEED ({self.cruise_speed:.3f} m/s) & CLICK 'RUN FLIGHT' ➔",
                font=("Segoe UI", 12, "bold"),
                fill="#6EE7B7",
                tags="mission_item",
            )

        # Draw Flight Path Corridor: START -> END 1 -> END 2 -> ... -> END N
        if self.start_pos and self.end_points:
            curr_pt = self.start_pos
            for idx, end_pt in enumerate(self.end_points):
                p1 = self.world_to_screen(*curr_pt)
                p2 = self.world_to_screen(*end_pt)
                self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], fill="#FBBF24", dash=(6, 4), width=2, arrow=tk.LAST, tags="mission_item")
                curr_pt = end_pt

        # 1. Start Helipad (Pure White Pad on ground)
        if self.start_pos:
            sx, sy = self.world_to_screen(*self.start_pos)
            r = 24
            # White helipad circle
            self.canvas.create_oval(sx - r, sy - r, sx + r, sy + r, fill="#FFFFFF", outline="#94A3B8", width=3, tags="mission_item")
            # Dark contrast 'H' on white
            self.canvas.create_text(sx, sy - 2, text="H", font=("Segoe UI", 14, "bold"), fill="#0F172A", tags="mission_item")
            # Start coordinate badge
            self.canvas.create_rectangle(sx - 48, sy + 11, sx + 48, sy + 25, fill="#0F172A", outline="", tags="mission_item")
            self.canvas.create_text(sx, sy + 18, text=f"START ({self.start_pos[0]:.1f}, {self.start_pos[1]:.1f})", font=("Segoe UI", 8, "bold"), fill="#FFFFFF", tags="mission_item")

        # 2. ALL Destination Helipads (Light Red Pads on ground)
        total_ends = len(self.end_points)
        for idx, (gx, gy) in enumerate(self.end_points):
            px, py = self.world_to_screen(gx, gy)
            r = 24
            # Light red helipad circle
            self.canvas.create_oval(px - r, py - r, px + r, py + r, fill="#F87171", outline="#DC2626", width=3, tags="mission_item")
            # White 'H' on light red
            self.canvas.create_text(px, py - 2, text="H", font=("Segoe UI", 14, "bold"), fill="#FFFFFF", tags="mission_item")
            # End badge with number
            is_final = (idx == total_ends - 1 and total_ends > 1)
            lbl = f"END #{idx+1} (FINAL)" if is_final else f"END #{idx+1}"
            badge_w = 54 if is_final else 44
            self.canvas.create_rectangle(px - badge_w, py + 11, px + badge_w, py + 25, fill="#991B1B", outline="", tags="mission_item")
            self.canvas.create_text(px, py + 18, text=f"{lbl} ({gx:.1f}, {gy:.1f})", font=("Segoe UI", 8, "bold"), fill="#FFFFFF", tags="mission_item")

        # 3. Placed Slender Stick Obstacles (STRICTLY 1 SINGLE UNIFORM COLOUR ONLY)
        for idx, (ox, oy) in enumerate(self.obstacles):
            px, py = self.world_to_screen(ox, oy)
            r_safe = 20

            # Subtle clearance guide ring
            self.canvas.create_oval(px - r_safe, py - r_safe, px + r_safe, py + r_safe, outline="#64748B", dash=(4, 4), width=1, tags="mission_item")

            # Slender stick pole: STRICTLY 1 UNIFORM COLOUR (#784B27) - NO red bands, NO gold tips!
            self.canvas.create_line(px, py + 2, px, py - 22, fill="#784B27", width=4, tags="mission_item")
            # Rounded top cap in the exact same single colour
            self.canvas.create_oval(px - 3, py - 25, px + 3, py - 19, fill="#784B27", outline="#784B27", tags="mission_item")
            # Ground base dot in the exact same single colour
            self.canvas.create_oval(px - 4, py, px + 4, py + 4, fill="#784B27", outline="#784B27", tags="mission_item")

            # Label badge
            self.canvas.create_rectangle(px - 40, py + r_safe + 1, px + 40, py + r_safe + 15, fill="#1F2937", outline="", tags="mission_item")
            self.canvas.create_text(px, py + r_safe + 8, text=f"🥢 Stick #{idx+1} ({ox:.1f}, {oy:.1f})m", font=("Segoe UI", 8, "bold"), fill="#F3F4F6", tags="mission_item")
            self.canvas.create_text(px, py + r_safe + 8, text=f"🥢 Stick #{idx+1} ({ox:.1f}, {oy:.1f})m", font=("Segoe UI", 8, "bold"), fill="#F3F4F6", tags="mission_item")

    def _update_live_drone_on_map(self):
        """Draws live drone marker on canvas with red front arms, green rear arms, and 2 golden/red LiDAR beams."""
        if not self.sim_running:
            return

        self.canvas.delete("drone_marker")
        dx = self.drone_live_state["x"]
        dy = self.drone_live_state["y"]
        yaw_deg = self.drone_live_state["yaw"]
        alert = self.drone_live_state["alert"]
        px, py = self.world_to_screen(dx, dy)

        # 1. 4 Rotor Arms: Front 2 RED, Rear 2 GREEN
        for angle_deg in [-45, 45]:
            rad = np.deg2rad(yaw_deg + angle_deg)
            ax = px + 17 * math.cos(rad)
            ay = py - 17 * math.sin(rad)
            self.canvas.create_line(px, py, ax, ay, fill="#EF4444", width=3, tags="drone_marker")
            self.canvas.create_oval(ax - 5, ay - 5, ax + 5, ay + 5, fill="#18181B", outline="#475569", tags="drone_marker")

        for angle_deg in [-135, 135]:
            rad = np.deg2rad(yaw_deg + angle_deg)
            ax = px + 17 * math.cos(rad)
            ay = py - 17 * math.sin(rad)
            self.canvas.create_line(px, py, ax, ay, fill="#22C55E", width=3, tags="drone_marker")
            self.canvas.create_oval(ax - 5, ay - 5, ax + 5, ay + 5, fill="#18181B", outline="#475569", tags="drone_marker")

        # 2. Fuselage Body (Black with Yellow core accent)
        self.canvas.create_oval(px - 9, py - 9, px + 9, py + 9, fill="#1F2937", outline="#FACC15", width=2, tags="drone_marker")
        c_core = "#EF4444" if alert else "#FACC15"
        self.canvas.create_oval(px - 4, py - 4, px + 4, py + 4, fill=c_core, outline="", tags="drone_marker")

        # 3. Heading Vector Pointer
        yaw_rad = np.deg2rad(yaw_deg)
        hx = px + 20 * math.cos(yaw_rad)
        hy = py - 20 * math.sin(yaw_rad)
        self.canvas.create_line(px, py, hx, hy, fill="#FACC15", width=2, arrow=tk.LAST, tags="drone_marker")

        # 4. 5 FORWARD & FLANK LIDAR SENSOR LIGHTS (Warm Golden Laser, Red on Obstacle)
        c_laser = "#EF4444" if alert else "#FBBF24"
        for offset_deg in [+18.0, +9.0, 0.0, -9.0, -18.0]:
            beam_rad = np.deg2rad(yaw_deg + offset_deg)
            bx = px + 36 * math.cos(beam_rad)
            by = py - 36 * math.sin(beam_rad)
            self.canvas.create_line(px, py, bx, by, fill=c_laser, width=2, dash=(3, 3), tags="drone_marker")
            self.canvas.create_oval(bx - 2, by - 2, bx + 2, by + 2, fill=c_laser, outline="", tags="drone_marker")

        # Check destination arrival / Task Finished
        is_finished = self.drone_live_state.get("mission_complete", False) or self.drone_live_state.get("goal_reached", False) or self.at_destination_standby
        if is_finished:
            # Render celebratory "TASK FINISHED" badge directly on canvas above drone
            self.canvas.create_rectangle(px - 58, py - 38, px + 58, py - 18, fill="#059669", outline="#34D399", width=2, tags="drone_marker")
            self.canvas.create_text(px, py - 28, text="✅ TASK FINISHED", font=("Segoe UI", 9, "bold"), fill="#FFFFFF", tags="drone_marker")

            if not self.at_destination_standby:
                self.at_destination_standby = True
                self.announce_task_finished()
                # Automatically prepare for next journey: current spot is new start!
                self.start_pos = (round(dx, 2), round(dy, 2))
                self.ent_start.delete(0, tk.END)
                self.ent_start.insert(0, f"{dx:.1f}, {dy:.1f}")
                self.goal_pos = None
                self.ent_goal.delete(0, tk.END)
                self.step = 2
                self.update_step_banner()
                self._redraw_mission_elements()
        elif self.drone_live_state.get("path_blocked", False):
            gap_w = self.drone_live_state.get("gap_width", 0.0)
            self.canvas.create_rectangle(px - 72, py - 38, px + 72, py - 18, fill="#DC2626", outline="#FCA5A5", width=2, tags="drone_marker")
            self.canvas.create_text(px, py - 28, text=f"⛔ BLOCKED: GAP {gap_w:.2f}m < 0.68m", font=("Segoe UI", 8, "bold"), fill="#FFFFFF", tags="drone_marker")

        self.root.after(40, self._update_live_drone_on_map)

    def launch_3d_simulation(self):
        """Launches photorealistic 3D MuJoCo simulation."""
        if self.sim_running:
            messagebox.showinfo("Simulation Active", "The 3D simulation is already running!")
            return

        if self.start_pos is None:
            messagebox.showwarning("Missing Location", "Please give the 1st STARTING PLACE (White Helipad) first!")
            self.set_active_step(1)
            return
        if not self.end_points:
            messagebox.showwarning("Missing Location", "Please place the 2nd ENDING POINTS (Light Red Helipads)! You can place as many as you wish.")
            self.set_active_step(2)
            return
        if not self.obstacles:
            messagebox.showwarning("Missing Obstacle", "Please place the OBSTACLE object! (The drone moves when the object is there)")
            self.set_active_step(3)
            return

        self.apply_speed_from_entry()
        self.sim_running = True
        self.at_destination_standby = False
        self.has_spoken_finished = False
        self.btn_launch.configure(state=tk.DISABLED, bg="#4B5563")
        self.update_step_banner()

        # Start 3D MuJoCo simulation on worker thread
        self.sim_thread = threading.Thread(target=self._run_mujoco_thread, daemon=True)
        self.sim_thread.start()

        # Start live 2D map tracking loop
        self.root.after(100, self._update_live_drone_on_map)

    def _run_mujoco_thread(self):
        """Worker thread executing MuJoCo physics and continuous multi-journey rendering."""
        try:
            park_xml_path = os.path.join(PROJECT_ROOT, "models", "world_park_environment.xml")
            if not os.path.exists(park_xml_path):
                print(f"Error: {park_xml_path} not found.")
                return

            speed = self.cruise_speed
            final_goal = self.end_points[-1] if self.end_points else (12.0, 0.0)
            # Slow graceful turning controller: k_yaw=0.40
            controller = AdaptiveNeuralController(v_cruise=speed, enable_plasticity=True, k_yaw=0.40)
            self.sim = QuadrotorSimulation(
                world_xml_path=park_xml_path,
                neural_controller=controller,
                cruise_speed=speed,
                target_goal=(final_goal[0], final_goal[1], 1.5),
                waypoints=list(self.end_points),
                continuous_mode=False,
            )
            self.sim.pending_obstacles_queue = self.obstacle_queue

            # Reset with start pad, all ending points, and placed stick obstacles (starts on ground!)
            self.sim.reset(
                start_pos=(self.start_pos[0], self.start_pos[1], 0.072),
                target_goal=(final_goal[0], final_goal[1], 1.5),
                waypoints=list(self.end_points),
                continuous_mode=False,
                obstacles=self.obstacles,
            )

            # Launch interactive viewer (STAYS OPEN CONTINUOUSLY)
            import mujoco.viewer
            with mujoco.viewer.launch_passive(self.sim.model, self.sim.data) as viewer:
                viewer.cam.distance = 4.8
                viewer.cam.elevation = -14.0
                viewer.cam.azimuth = 180.0
                viewer.cam.lookat[:] = [self.start_pos[0], self.start_pos[1], 0.20]

                # Main loop: continues indefinitely until window is explicitly closed by user
                while viewer.is_running() and self.sim_running:
                    t_start = time.time()

                    # Check for new journey command from GUI ("see new journey from there")
                    if not self.journey_queue.empty():
                        try:
                            cmd = self.journey_queue.get_nowait()
                            new_goal = cmd.get("goal")
                            new_wps = cmd.get("waypoints", [new_goal])
                            new_obs = cmd.get("obstacles", [])
                            new_spd = cmd.get("speed", None)
                            if new_spd is not None:
                                self.sim.cruise_speed = new_spd
                                self.sim.controller.v_cruise = new_spd
                            self.sim.start_new_journey_from_here(new_goal_xy=new_goal, new_obstacles=new_obs, new_waypoints=new_wps)
                        except Exception as e:
                            print(f"[JOURNEY] Error starting new leg: {e}")

                    rec = self.sim.step_control()
                    
                    # Strictly render ONLY the 2 LiDAR lights (Zero blue transparency)
                    self.sim.render_lidar_beams(viewer)

                    # Dynamic camera tracking behind drone
                    d_pos = [rec["pos_x"], rec["pos_y"], rec["pos_z"]]
                    d_yaw_rad = np.deg2rad(rec["yaw"])
                    viewer.cam.lookat[:] = [d_pos[0] + 0.3 * np.cos(d_yaw_rad), d_pos[1] + 0.3 * np.sin(d_yaw_rad), d_pos[2] + 0.15]
                    viewer.cam.azimuth = float(rec["yaw"] + 180.0)

                    # Update live state for 2D map GCS
                    alert = (min(rec.get("dist_far_left", 999.0), rec["dist_left"], rec.get("dist_center", 999.0), rec["dist_right"], rec.get("dist_far_right", 999.0)) < 2.5)
                    self.drone_live_state["x"] = rec["pos_x"]
                    self.drone_live_state["y"] = rec["pos_y"]
                    self.drone_live_state["z"] = rec["pos_z"]
                    self.drone_live_state["yaw"] = rec["yaw"]
                    self.drone_live_state["vx"] = rec["cmd_vx"]
                    self.drone_live_state["alert"] = alert
                    self.drone_live_state["goal_reached"] = rec.get("goal_reached", False)
                    self.drone_live_state["mission_complete"] = rec.get("mission_complete", False)
                    self.drone_live_state["path_blocked"] = rec.get("path_blocked", False)
                    self.drone_live_state["gap_width"] = rec.get("gap_width", 999.0)
                    self.drone_live_state["min_passable_width"] = rec.get("min_passable_width", 0.68)

                    # Update HUD status label safely
                    phase = rec.get("flight_phase", "CRUISE")
                    is_blocked = rec.get("path_blocked", False)
                    gap_w = rec.get("gap_width", 999.0)
                    drone_sz = rec.get("min_passable_width", 0.68)
                    wp_idx = rec.get("waypoint_idx", 0)
                    total_wps = len(self.end_points) if self.end_points else 1
                    wp_num = wp_idx + 1

                    if self.at_destination_standby or phase == "LANDED" or rec.get("mission_complete", False):
                        stage_txt = f"✅ TASK FINISHED (Landed on Ground | All {total_wps} End Points Complete!)"
                        if not self.has_spoken_finished:
                            self.announce_task_finished()
                    elif is_blocked:
                        stage_txt = f"⛔ PATH BLOCKED (Gap {gap_w:.2f}m < Drone {drone_sz:.2f}m | Hovering Safe)"
                        if not getattr(self, "has_spoken_blocked", False):
                            self.has_spoken_blocked = True
                            self.announce_path_blocked(gap_w, drone_sz)
                    elif phase == "TAKEOFF":
                        stage_txt = f"🛫 VERTICAL TAKEOFF FROM GROUND (Heading to End #{wp_num} of {total_wps})"
                    elif phase == "LANDING":
                        stage_txt = f"🛬 VERTICAL DESCENT TO GROUND (Ending Point #{wp_num} of {total_wps})"
                    elif alert:
                        stage_txt = f"🚨 5-LIDAR ALERT (EVADING OBSTACLE | End #{wp_num} of {total_wps})"
                    else:
                        stage_txt = f"🛸 CRUISING TO END POINT #{wp_num} OF {total_wps}"

                    if not is_blocked:
                        self.has_spoken_blocked = False

                    hud_text = (
                        f"POS: ({rec['pos_x']:4.1f}, {rec['pos_y']:4.1f})m | "
                        f"ALT: {rec['pos_z']:4.2f}m | "
                        f"SPD: {rec['cmd_vx']:5.3f}m/s | "
                        f"STAGE: {stage_txt}"
                    )
                    self.root.after(0, lambda t=hud_text: self.hud_status.configure(text=t))

                    viewer.sync()
                    elapsed = time.time() - t_start
                    dt_sleep = self.sim.ctrl_dt - elapsed
                    if dt_sleep > 0:
                        time.sleep(dt_sleep)

        except Exception as e:
            print(f"[PARK GCS] Error in simulation thread: {e}")
        finally:
            self.sim_running = False
            self.root.after(0, self._on_sim_terminated)

    def _on_sim_terminated(self):
        """Invoked on GUI thread when 3D window closes."""
        self.sim_running = False
        self.at_destination_standby = False
        self.btn_launch.configure(state=tk.NORMAL, bg="#059669")
        self.btn_new_journey.configure(state=tk.DISABLED, bg="#4B5563")
        self.update_step_banner()
        self.hud_status.configure(text="STATUS: Simulation session finished. Click 'LAUNCH 3D NATURE FLIGHT' to start again.")

    def on_close(self):
        """Gracefully closes simulation thread and Tkinter window."""
        self.sim_running = False
        if self._owns_root:
            self.root.destroy()

    def run(self):
        """Starts the Tkinter event loop."""
        if self._owns_root:
            self.root.mainloop()


def launch_planner(start=None, goal=None, stick=None, speed=0.10, auto_launch=False):
    app = ParkMissionPlanner(initial_start=start, initial_goal=goal, initial_stick=stick, initial_speed=speed, auto_launch=auto_launch)
    app.run()


if __name__ == "__main__":
    launch_planner()
