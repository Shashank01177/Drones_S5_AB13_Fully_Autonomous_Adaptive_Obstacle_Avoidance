# MuJoCo Drone Obstacle Avoidance: Benchmark Performance Evaluation

Evaluation across 10 benchmark scenarios comparing obstacle avoidance strategies:
- **Reactive**: Finite State Machine with 6-sector virtual LiDAR rangefinding, 360� gap escape & vertical climb-over state machine, and closing-velocity dynamic prediction.
- **APF**: Artificial Potential Fields (gradient-based repulsive obstacle & attractive goal fields).
- **DWA**: Vectorized Dynamic Window Approach with forward trajectory arc sampling.
- **3D Avoidance**: 3D Volumetric avoidance with dynamic altitude climbing and overhang descent.

## Detailed Results Table

| Scenario | Scenario Name | Algorithm | Result | Flight Time (s) | Path Length (m) | Collisions | Min Clear (m) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | Frontal Obstacle | NEURAL_BRAIN | **SUCCESS** | 16.0 | 5.937 | 0 | 0.195 |
| 2 | Offset Left | NEURAL_BRAIN | **SUCCESS** | 15.56 | 5.827 | 0 | 0.206 |
| 3 | Offset Right | NEURAL_BRAIN | **SUCCESS** | 15.62 | 5.819 | 0 | 0.212 |
| 4 | Narrow Corridor | NEURAL_BRAIN | **SUCCESS** | 15.0 | 5.754 | 0 | 0.224 |
| 5 | Dead-End U-Trap | NEURAL_BRAIN | **SUCCESS** | 19.98 | 7.052 | 0 | 0.2 |
| 6 | Forest Maze | NEURAL_BRAIN | **SUCCESS** | 18.73 | 6.232 | 0 | 0.234 |
| 7 | Dynamic Slider | NEURAL_BRAIN | **SUCCESS** | 16.65 | 6.041 | 0 | 0.316 |
| 8 | 3D Cluttered | NEURAL_BRAIN | **SUCCESS** | 16.62 | 6.141 | 0 | 0.223 |
| 9 | Dynamic Intruder | NEURAL_BRAIN | **SUCCESS** | 17.85 | 6.513 | 0 | 0.246 |
| 10 | Dead-End Ring | NEURAL_BRAIN | **SUCCESS** | 15.38 | 6.321 | 0 | 0.4 |
| 1 | Frontal Obstacle | REACTIVE | **SUCCESS** | 15.79 | 6.019 | 0 | 0.34 |
| 2 | Offset Left | REACTIVE | **SUCCESS** | 15.73 | 5.929 | 0 | 0.303 |
| 3 | Offset Right | REACTIVE | **SUCCESS** | 15.73 | 5.929 | 0 | 0.303 |
| 4 | Narrow Corridor | REACTIVE | **SUCCESS** | 16.17 | 6.305 | 46 | 0.15 |
| 5 | Dead-End U-Trap | REACTIVE | **SUCCESS** | 16.5 | 6.316 | 59 | 0.151 |
| 6 | Forest Maze | REACTIVE | **SUCCESS** | 15.56 | 6.391 | 0 | 0.321 |
| 7 | Dynamic Slider | REACTIVE | **SUCCESS** | 16.08 | 6.27 | 19 | 0.15 |
| 8 | 3D Cluttered | REACTIVE | **SUCCESS** | 15.75 | 6.148 | 0 | 0.151 |
| 9 | Dynamic Intruder | REACTIVE | **SUCCESS** | 15.77 | 6.102 | 27 | 0.15 |
| 10 | Dead-End Ring | REACTIVE | **SUCCESS** | 15.75 | 6.323 | 0 | 0.4 |
| 1 | Frontal Obstacle | SINDY_DWA | **SUCCESS** | 22.02 | 5.839 | 29 | 0.152 |
| 2 | Offset Left | SINDY_DWA | **SUCCESS** | 16.5 | 5.775 | 0 | 0.167 |
| 3 | Offset Right | SINDY_DWA | **SUCCESS** | 16.5 | 5.775 | 0 | 0.167 |
| 4 | Narrow Corridor | SINDY_DWA | **SUCCESS** | 16.44 | 5.753 | 0 | 0.23 |
| 5 | Dead-End U-Trap | SINDY_DWA | **SUCCESS** | 29.4 | 9.137 | 299 | 0.15 |
| 6 | Forest Maze | SINDY_DWA | **SUCCESS** | 23.04 | 5.942 | 92 | 0.151 |
| 7 | Dynamic Slider | SINDY_DWA | **SUCCESS** | 17.54 | 5.871 | 26 | 0.15 |
| 8 | 3D Cluttered | SINDY_DWA | **SUCCESS** | 22.6 | 6.007 | 86 | 0.15 |
| 9 | Dynamic Intruder | SINDY_DWA | **SUCCESS** | 17.17 | 5.771 | 12 | 0.155 |
| 10 | Dead-End Ring | SINDY_DWA | **SUCCESS** | 16.38 | 6.32 | 0 | 0.4 |
| 1 | Frontal Obstacle | APF | **SUCCESS** | 16.94 | 6.766 | 0 | 0.369 |
| 2 | Offset Left | APF | **SUCCESS** | 15.85 | 6.342 | 0 | 0.428 |
| 3 | Offset Right | APF | **SUCCESS** | 15.85 | 6.342 | 0 | 0.428 |
| 4 | Narrow Corridor | APF | RUNNING | 60.0 | 23.905 | 0 | 0.587 |
| 5 | Dead-End U-Trap | APF | RUNNING | 60.0 | 2.482 | 0 | 0.643 |
| 6 | Forest Maze | APF | **SUCCESS** | 31.06 | 12.394 | 0 | 0.335 |
| 7 | Dynamic Slider | APF | **SUCCESS** | 17.58 | 7.033 | 83 | 0.15 |
| 8 | 3D Cluttered | APF | RUNNING | 60.0 | 21.583 | 0 | 0.613 |
| 1 | Frontal Obstacle | DWA | **SUCCESS** | 22.04 | 5.837 | 31 | 0.152 |
| 2 | Offset Left | DWA | **SUCCESS** | 16.5 | 5.775 | 0 | 0.167 |
| 3 | Offset Right | DWA | **SUCCESS** | 16.5 | 5.775 | 0 | 0.167 |
| 4 | Narrow Corridor | DWA | **SUCCESS** | 16.44 | 5.753 | 0 | 0.23 |
| 5 | Dead-End U-Trap | DWA | **SUCCESS** | 26.83 | 8.37 | 211 | 0.15 |
| 6 | Forest Maze | DWA | **SUCCESS** | 23.12 | 5.95 | 82 | 0.151 |
| 7 | Dynamic Slider | DWA | **SUCCESS** | 17.62 | 5.898 | 38 | 0.152 |
| 8 | 3D Cluttered | DWA | **SUCCESS** | 22.62 | 6.01 | 87 | 0.151 |
| 1 | Frontal Obstacle | 3D | **SUCCESS** | 17.4 | 5.833 | 78 | 0.15 |
| 2 | Offset Left | 3D | **SUCCESS** | 16.6 | 5.829 | 0 | 0.222 |
| 3 | Offset Right | 3D | **SUCCESS** | 16.6 | 5.829 | 0 | 0.222 |
| 4 | Narrow Corridor | 3D | **SUCCESS** | 17.62 | 6.12 | 0 | 0.225 |
| 5 | Dead-End U-Trap | 3D | **SUCCESS** | 17.23 | 6.0 | 91 | 0.15 |
| 6 | Forest Maze | 3D | **SUCCESS** | 18.42 | 5.916 | 127 | 0.15 |
| 7 | Dynamic Slider | 3D | **SUCCESS** | 16.71 | 5.822 | 35 | 0.151 |
| 8 | 3D Cluttered | 3D | **SUCCESS** | 17.9 | 6.045 | 101 | 0.15 |
| 10 | Ring Gap (seed 42) | REACTIVE | **SUCCESS** | 58.98 | 20.733 | 159 | 0.15 |
| 10 | Ring Gap (seed 100) | REACTIVE | RUNNING | 60.0 | 20.335 | 152 | 0.15 |
| 10 | Ring Gap (seed 2023) | REACTIVE | **SUCCESS** | 53.58 | 18.957 | 161 | 0.15 |
| 10 | Ring Gap (seed 777) | REACTIVE | RUNNING | 60.0 | 4.204 | 2518 | 0.15 |
| 10 | Ring Gap (seed 999) | REACTIVE | **SUCCESS** | 40.56 | 14.582 | 182 | 0.15 |

## Performance Metrics by Algorithm

| Algorithm | Success Rate | Mean Flight Time (s) | Mean Path Length (m) | Total Collision Steps |
| :--- | :--- | :--- | :--- | :--- |
| **NEURAL_BRAIN** | 100.0% (10/10) | 16.74 | 6.16 | 0 |
| **REACTIVE** | 86.7% (13/15) | 24.00 | 8.92 | 3323 |
| **SINDY_DWA** | 100.0% (10/10) | 19.76 | 6.22 | 544 |
| **APF** | 62.5% (5/8) | 19.46 | 7.78 | 83 |
| **DWA** | 100.0% (8/8) | 20.21 | 6.17 | 449 |
| **3D** | 100.0% (8/8) | 17.31 | 5.92 | 432 |
