"""
Neural Brain Controller module alias.
"""
from ..avoidance.neural_brain import AdaptiveNeuralBrain, BrainConfig, RAY_ANGLES_DEG, wrap
