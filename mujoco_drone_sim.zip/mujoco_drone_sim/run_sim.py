"""
Interactive and Headless Simulation Runner for MuJoCo Drone Obstacle Avoidance.

Usage:
  python run_sim.py --scenario 1 --algo neural_brain --gui
  python run_sim.py --scenario 5 --algo neural_brain --gui
  python run_sim.py --scenario 9 --algo neural_brain --gui
  python run_sim.py --scenario 10 --sub-scenario ring_with_gap --gui
  python run_sim.py --benchmark
  python run_sim.py --dashboard
"""

import sys
import os
import time
import argparse
import json
import numpy as np

# Ensure workspace root is in python path
current_dir = os.path.dirname(os.path.abspath(__file__))
workspace_dir = os.path.abspath(os.path.join(current_dir, ".."))
if workspace_dir not in sys.path:
    sys.path.insert(0, workspace_dir)
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import mujoco
from mujoco_drone_sim.simulation.drone_sim import DroneObstacleSimulation


def run_simulation(
    scenario_id=1,
    algo="sindy_dwa",
    gui=False,
    duration=60.0,
    realtime_sync=True,
    verbose=True,
    log_file=None,
    sub_scenario="closed_ring",
    seed=42,
    intruder_speed=1.0
):
    """
    Run single scenario flight simulation with optional MuJoCo 3D interactive viewer.
    """
    print("=" * 65)
    print(f"  MuJoCo Quadcopter Obstacle Avoidance Simulation")
    print(f"  Scenario: {scenario_id} | Algorithm: {algo.upper()} | GUI: {gui}")
    if scenario_id == 10:
        print(f"  Sub-scenario: {sub_scenario} | Seed: {seed}")
    elif scenario_id == 9:
        print(f"  Intruder Speed Multiplier: {intruder_speed}x")
    print("=" * 65)

    sim = DroneObstacleSimulation(
        scenario_id=scenario_id,
        algorithm=algo,
        sub_scenario=sub_scenario,
        seed=seed,
        intruder_speed_multiplier=intruder_speed
    )

    total_steps = int(duration * sim.control_freq)
    step_delay = 1.0 / sim.control_freq

    viewer = None
    if gui:
        try:
            import mujoco.viewer
            viewer = mujoco.viewer.launch_passive(sim.model, sim.data)
            print("[INFO] Interactive MuJoCo 3D Viewer launched successfully!")
        except Exception as e:
            print(f"[WARNING] Could not launch passive GUI viewer ({e}). Running in headless console mode.")
            viewer = None

    start_time = time.time()
    last_print_time = start_time

    try:
        for step in range(total_steps):
            step_start = time.time()
            info = sim.step()

            # Render 3D frame if viewer is open
            if viewer is not None and viewer.is_running():
                viewer.sync()
            elif viewer is not None and not viewer.is_running():
                print("\n[INFO] Viewer window closed by user.")
                break

            # Print telemetry to console at 5Hz
            now = time.time()
            if verbose and (now - last_print_time >= 0.20 or info["result"] != "RUNNING"):
                pos = info["pos"]
                vel = info["vel"]
                dist_goal = info["dist_to_goal"]
                mode = info["mode"]
                distances = info["perception"]["distances"]
                front_d = distances.get("front", 2.0)
                left_d = distances.get("left", 2.0)
                right_d = distances.get("right", 2.0)

                print(
                    f"Time: {info['sim_time']:5.2f}s | "
                    f"Mode: {mode:16s} | "
                    f"Pos: ({pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f}) | "
                    f"Vel: {np.linalg.norm(vel):.2f}m/s | "
                    f"Front: {front_d:.2f}m | "
                    f"L: {left_d:.2f}m | "
                    f"R: {right_d:.2f}m | "
                    f"Goal Dist: {dist_goal:.2f}m"
                )
                last_print_time = now

            if info["result"] != "RUNNING":
                break

            # Real-time synchronization
            if realtime_sync and gui:
                elapsed_step = time.time() - step_start
                sleep_time = step_delay - elapsed_step
                if sleep_time > 0:
                    time.sleep(sleep_time)

    except KeyboardInterrupt:
        print("\n[INFO] Simulation interrupted by user.")
    finally:
        if viewer is not None:
            viewer.close()

    summary = sim.get_summary()

    print("\n" + "=" * 65)
    print("  EXPERIMENT PERFORMANCE SUMMARY")
    print("=" * 65)
    print(f"  Result:              {summary['result']}")
    print(f"  Completion Time:     {summary['completion_time']:.2f} s")
    print(f"  Control Steps:       {summary['control_steps']}")
    print(f"  Final Position:      {summary['final_position']}")
    print(f"  Path Length:         {summary['path_length']:.3f} m")
    print(f"  Collision Steps:     {summary['collision_steps']}")
    print(f"  Minimum Clearance:   {summary['min_clearance']:.3f} m")
    print(f"  Avoidance Events:    {summary['avoidance_events']}")
    print(f"  Emergency Reversals: {summary['emergency_reversals']}")
    print("=" * 65 + "\n")

    if log_file:
        def make_serializable(obj):
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            if isinstance(obj, (np.float32, np.float64, np.floating)):
                return float(obj)
            if isinstance(obj, (np.int32, np.int64, np.integer)):
                return int(obj)
            if isinstance(obj, dict):
                return {k: make_serializable(v) for k, v in obj.items()}
            if isinstance(obj, list):
                return [make_serializable(x) for x in obj]
            return obj

        summary_export = make_serializable(summary)
        summary_export["flight_history"] = make_serializable(sim.history)
        with open(log_file, "w") as f:
            json.dump(summary_export, f, indent=2)
        print(f"[INFO] Flight telemetry saved to {log_file}")

    return summary


def main():
    parser = argparse.ArgumentParser(description="MuJoCo Quadcopter Obstacle Avoidance Runner")
    parser.add_argument("--scenario", "-s", type=int, default=1, choices=range(1, 11),
                        help="Scenario ID (1-10): 1:Frontal, 2:Left, 3:Right, 4:Narrow, 5:Dead-end, 6:Forest, 7:Dynamic, 8:3D, 9:Intruder, 10:Ring")
    parser.add_argument("--sub-scenario", type=str, default="closed_ring", choices=["closed_ring", "ring_with_gap"],
                        help="Sub-scenario for Scenario 10: closed_ring or ring_with_gap")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for Scenario 10 gap orientation (default: 42)")
    parser.add_argument("--intruder-speed", type=float, default=1.0,
                        help="Speed multiplier for Scenario 9 lateral intruder (default: 1.0)")
    parser.add_argument("--algo", "-a", type=str, default="sindy_dwa", choices=["sindy_dwa", "sindy", "neural_brain"],
                        help="Autonomous Avoidance Algorithm: sindy_dwa (SINDy-Enhanced Data-Driven Avoidance, default)")
    parser.add_argument("--sindy-train", action="store_true",
                        help="Run flight trajectory and identify symbolic equations of motion using SINDy")
    parser.add_argument("--gui", "-g", action="store_true",
                        help="Launch interactive MuJoCo 3D GUI viewer")
    parser.add_argument("--duration", "-d", type=float, default=60.0,
                        help="Maximum simulation duration in seconds (default: 60)")
    parser.add_argument("--no-sync", action="store_true",
                        help="Run faster than real-time (no FPS sync)")
    parser.add_argument("--benchmark", "-b", action="store_true",
                        help="Run full automated benchmark across all scenarios and algorithms")
    parser.add_argument("--dashboard", action="store_true",
                        help="Launch interactive Web Telemetry Dashboard")
    parser.add_argument("--log", type=str, default=None,
                        help="Output JSON log filepath")

    args = parser.parse_args()

    if args.sindy_train:
        from mujoco_drone_sim.sindy import DroneDynamicsIdentifier
        print("\n[INFO] Starting SINDy Quadcopter Dynamics Identification...")
        sim = DroneObstacleSimulation(scenario_id=args.scenario, algorithm="reactive", intruder_speed_multiplier=args.intruder_speed)
        log = []
        for _ in range(int(args.duration * sim.control_freq)):
            pos, quat, vel, angvel = sim.get_drone_state()
            info = sim.step()
            log.append({
                "time": sim.sim_time,
                "pos": pos,
                "vel": vel,
                "quat": quat,
                "angvel": angvel,
                "ctrl": sim.data.ctrl.copy()
            })
            if info["result"] != "RUNNING":
                break
        identifier = DroneDynamicsIdentifier(dt=1.0 / sim.control_freq)
        identifier.fit_from_telemetry(log)
        identifier.print_summary()

    elif args.dashboard:
        from mujoco_drone_sim.web_dashboard.app import start_dashboard
        start_dashboard()
    elif args.benchmark:
        from mujoco_drone_sim.benchmark import run_benchmark_suite
        run_benchmark_suite()
    else:
        run_simulation(
            scenario_id=args.scenario,
            algo=args.algo,
            gui=args.gui,
            duration=args.duration,
            realtime_sync=not args.no_sync,
            log_file=args.log,
            sub_scenario=args.sub_scenario,
            seed=args.seed,
            intruder_speed=args.intruder_speed
        )


if __name__ == "__main__":
    main()
