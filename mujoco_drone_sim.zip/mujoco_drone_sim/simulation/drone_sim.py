"""
Core Simulation Engine for Quadcopter Obstacle Detection & Navigation in MuJoCo.
Driven by the Adaptive Neural Brain (recurrent neural network with Hebbian plasticity,
frustration dynamics, speed neuron, and directional steering), removing PID controller dependence.
Includes 360-degree perimeter check and vertical climb-over escape for Scenario 10 dead-end closed ring.
"""

import time
import numpy as np
import mujoco

from ..models.scene_generator import generate_scene_xml
from ..perception.lidar_sensor import LiDARPerceptionSystem
from ..avoidance.neural_brain import AdaptiveNeuralBrain, BrainConfig, RAY_ANGLES_DEG, NeuralBrainAvoidance
from ..avoidance.reactive_avoidance import ReactiveObstacleAvoidance
from ..avoidance.apf_avoidance import APFObstacleAvoidance
from ..avoidance.dwa_avoidance import DWAObstacleAvoidance
from ..avoidance.avoidance_3d import Avoidance3D
from ..avoidance.sindy_dwa_avoidance import SINDyDWAAvoidance


class DroneObstacleSimulation:
    """
    MuJoCo Simulation environment for drone obstacle avoidance and navigation.
    Driven by Adaptive Neural Brain.
    """

    def __init__(
        self,
        scenario_id=1,
        algorithm="sindy_dwa",
        start_pos=(0.0, 0.0, 1.0),
        goal_pos=(6.0, 0.0, 1.0),
        control_freq=48.0,
        sim_timestep=0.002,
        sub_scenario="closed_ring",
        seed=42,
        intruder_speed_multiplier=1.0
    ):
        self.scenario_id = scenario_id
        self.algorithm_name = algorithm.lower() if algorithm else "sindy_dwa"
        self.start_pos = np.array(start_pos, dtype=float)
        self.goal_pos = np.array(goal_pos, dtype=float)
        self.control_freq = control_freq
        self.sim_timestep = sim_timestep
        self.sub_scenario = sub_scenario
        self.seed = seed
        self.intruder_speed_multiplier = intruder_speed_multiplier
        self.substeps = int(round((1.0 / self.control_freq) / self.sim_timestep))

        # Scenario 10 Ring Deadlock State
        self.ring_inspected = False
        self.ring_has_gap = False
        self.ring_gap_bearing = 0.0
        self.climb_state = "IDLE"  # IDLE, CLIMBING, FLYING_OVER, DESCENDING, CLEARED
        self.current_altitude = float(self.start_pos[2])
        self.target_climb_altitude = 1.55  # 0.40m above 1.15m ring wall height
        self.nominal_altitude = float(self.start_pos[2])

        # Build and load MuJoCo model
        self.xml_string = generate_scene_xml(
            scenario_id=self.scenario_id,
            start_pos=self.start_pos,
            goal_pos=self.goal_pos,
            sub_scenario=self.sub_scenario,
            seed=self.seed
        )
        self.model = mujoco.MjModel.from_xml_string(self.xml_string)
        self.data = mujoco.MjData(self.model)

        # Track drone body, root joint, geoms, and obstacle geoms
        self.drone_body_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_BODY, "drone")
        self.root_jnt_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, "root")
        self.drone_geom_ids = set()
        self.obstacle_geom_ids = set()

        for g_id in range(self.model.ngeom):
            g_name = mujoco.mj_id2name(self.model, mujoco.mjtObj.mjOBJ_GEOM, g_id)
            if not g_name:
                continue
            if g_name.startswith("drone") or g_name.startswith("arm") or g_name.startswith("m") or g_name.startswith("prop") or g_name.startswith("front_") or g_name.startswith("rear_"):
                self.drone_geom_ids.add(g_id)
            elif g_name.startswith("obs"):
                self.obstacle_geom_ids.add(g_id)

        # Initialize Perception
        self.perception = LiDARPerceptionSystem(self.model, max_range=2.0, danger_dist=0.75, emergency_dist=0.30)

        # Initialize Neural Brain
        self.neural_brain = AdaptiveNeuralBrain(
            goal_xy=self.goal_pos[:2],
            start_xy=self.start_pos[:2],
            dt=1.0 / self.control_freq
        )

        # Initialize Avoidance Strategy (if other algorithms are specified)
        self._init_avoidance_algorithm()

        # Dynamic obstacle joint IDs (Scenario 7 or Scenario 9)
        self.dynamic_joint_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, "obs_dynamic_slide")
        if self.dynamic_joint_id < 0:
            self.dynamic_joint_id = mujoco.mj_name2id(self.model, mujoco.mjtObj.mjOBJ_JOINT, "obs_intruder_slide")

        self.reset()

    def _init_avoidance_algorithm(self):
        """Create avoidance strategy instance."""
        if self.algorithm_name in ["neural", "neural_brain", "adaptive_neural", "brain"]:
            self.avoidance = NeuralBrainAvoidance(self.goal_pos, self.start_pos[2], self.control_freq)
        elif self.algorithm_name == "reactive":
            self.avoidance = ReactiveObstacleAvoidance(self.goal_pos, self.start_pos[2], self.control_freq)
        elif self.algorithm_name == "apf":
            self.avoidance = APFObstacleAvoidance(self.goal_pos, self.start_pos[2])
        elif self.algorithm_name == "dwa":
            self.avoidance = DWAObstacleAvoidance(self.goal_pos, self.start_pos[2])
        elif self.algorithm_name in ["3d", "volumetric"]:
            self.avoidance = Avoidance3D(self.goal_pos, self.start_pos[2])
        elif self.algorithm_name in ["sindy", "sindy_dwa"]:
            self.avoidance = SINDyDWAAvoidance(self.goal_pos, self.start_pos[2], self.control_freq)
        else:
            self.avoidance = NeuralBrainAvoidance(self.goal_pos, self.start_pos[2], self.control_freq)

    def set_algorithm(self, algorithm_name):
        """Switch active navigation/avoidance algorithm at runtime."""
        self.algorithm_name = algorithm_name.lower()
        self._init_avoidance_algorithm()
        self.avoidance.reset()
        self.neural_brain.reset()

    def reset(self):
        """Reset simulation state to start configuration."""
        mujoco.mj_resetData(self.model, self.data)

        # Set drone initial position
        qpos_adr = self.model.jnt_qposadr[self.root_jnt_id]
        self.data.qpos[qpos_adr:qpos_adr + 3] = self.start_pos
        self.data.qpos[qpos_adr + 3:qpos_adr + 7] = [1.0, 0.0, 0.0, 0.0]  # identity quaternion
        self.data.qvel[:] = 0.0
        self.data.ctrl[:] = 0.0

        mujoco.mj_forward(self.model, self.data)

        self.neural_brain.reset()
        if hasattr(self, "avoidance"):
            self.avoidance.reset()

        # Reset Scenario 10 Ring state
        self.ring_inspected = False
        self.ring_has_gap = False
        self.ring_gap_bearing = 0.0
        self.climb_state = "IDLE"
        self.current_altitude = float(self.start_pos[2])

        # Metrics
        self.step_count = 0
        self.sim_time = 0.0
        self.path_length = 0.0
        self.collision_steps = 0
        self.min_clearance = float("inf")
        self.previous_pos = self.start_pos.copy()
        self.result = "RUNNING"
        self.history = []

    def get_drone_state(self):
        """Read 6-DOF state from MuJoCo sensor arrays or qpos/qvel."""
        qpos_adr = self.model.jnt_qposadr[self.root_jnt_id]
        qvel_adr = self.model.jnt_dofadr[self.root_jnt_id]

        pos = self.data.qpos[qpos_adr:qpos_adr + 3].copy()
        quat = self.data.qpos[qpos_adr + 3:qpos_adr + 7].copy()
        vel = self.data.qvel[qvel_adr:qvel_adr + 3].copy()
        angvel = self.data.qvel[qvel_adr + 3:qvel_adr + 6].copy()

        return pos, quat, vel, angvel

    def check_collisions(self):
        """Check if any drone geom is currently in physical contact with an obstacle."""
        for c_idx in range(self.data.ncon):
            contact = self.data.contact[c_idx]
            g1, g2 = contact.geom1, contact.geom2
            if (g1 in self.drone_geom_ids and g2 in self.obstacle_geom_ids) or \
               (g2 in self.drone_geom_ids and g1 in self.obstacle_geom_ids):
                return True
        return False

    def update_dynamic_obstacles(self, t):
        """Animate dynamic obstacles if present."""
        if self.dynamic_joint_id >= 0:
            qpos_adr = self.model.jnt_qposadr[self.dynamic_joint_id]
            dof_adr = self.model.jnt_dofadr[self.dynamic_joint_id]
            if self.scenario_id == 9:
                omega = 1.0 * self.intruder_speed_multiplier
                self.data.qpos[qpos_adr] = 0.60 * np.sin(omega * t)
                self.data.qvel[dof_adr] = 0.60 * omega * np.cos(omega * t)
            else:
                self.data.qpos[qpos_adr] = 0.75 * np.sin(1.2 * t)
                self.data.qvel[dof_adr] = 0.75 * 1.2 * np.cos(1.2 * t)
            mujoco.mj_forward(self.model, self.data)

    def full_sweep(self, current_pos=None):
        """Perform on-demand 360-degree LiDAR sweep using perception system."""
        if current_pos is None:
            current_pos, _, _, _ = self.get_drone_state()
        return self.perception.full_sweep(self.data, current_pos)

    def step(self):
        """
        Execute one complete control step using the Adaptive Neural Brain (no PID).
        For Scenario 10, inspects 360 ring perimeter and executes climb-over escape if full deadlock.
        """
        if self.result != "RUNNING":
            return self.get_summary()

        current_pos, current_quat, current_vel, current_angvel = self.get_drone_state()
        dt = 1.0 / self.control_freq

        # Update dynamic moving obstacles
        self.update_dynamic_obstacles(self.sim_time)

        # 1. Cast Ray Fan for the Adaptive Neural Brain
        ray_angles_rad = self.neural_brain.ray_angles
        ray_distances, brain_rays = self.perception.cast_ray_fan(
            self.data, current_pos, ray_angles_rad,
            heading_yaw=self.neural_brain.psi,
            max_range=self.neural_brain.cfg.sensor_range
        )

        # 2. Perception Telemetry Update
        perception_data = self.perception.update(
            self.data, current_pos, current_quat, current_vel=current_vel, dt=dt
        )
        perception_data["brain_distances"] = ray_distances
        perception_data["brain_rays"] = brain_rays

        min_dist = min(perception_data["min_dist"], float(np.min(ray_distances)))
        if min_dist < self.min_clearance:
            self.min_clearance = min_dist

        # 3. Collision Detection
        is_collision = self.check_collisions()
        if is_collision:
            self.collision_steps += 1

        # 4. Scenario 10 360-degree LiDAR Perimeter Inspection
        if self.scenario_id == 10:
            if not self.ring_inspected and (self.neural_brain.frustration > 0.35 or self.min_clearance < 0.85 or self.step_count > int(1.5 * self.control_freq)):
                self.ring_inspected = True
                sweep_data = self.full_sweep(current_pos)
                h_scan = sweep_data["horizontal_scan"]

                front_rays = [item[1] for item in h_scan if item[0] <= 45.0 or item[0] >= 315.0]
                left_rays = [item[1] for item in h_scan if 45.0 < item[0] <= 135.0]
                rear_rays = [item[1] for item in h_scan if 135.0 < item[0] <= 225.0]
                right_rays = [item[1] for item in h_scan if 225.0 < item[0] < 315.0]

                clear_indices = [i for i, item in enumerate(h_scan) if item[1] > 3.2]
                max_run = 0
                best_bearing = 0.0
                if clear_indices:
                    groups = []
                    curr_group = [clear_indices[0]]
                    for idx in clear_indices[1:]:
                        if idx == curr_group[-1] + 1:
                            curr_group.append(idx)
                        else:
                            groups.append(curr_group)
                            curr_group = [idx]
                    groups.append(curr_group)

                    if len(groups) > 1 and groups[0][0] == 0 and groups[-1][-1] == len(h_scan) - 1:
                        merged = groups[-1] + groups[0]
                        groups = groups[1:-1] + [merged]

                    best_group = max(groups, key=len)
                    max_run = len(best_group)
                    best_bearing = float(np.mean([h_scan[i % len(h_scan)][0] for i in best_group]))

                print("\n" + "=" * 72)
                print("  [360-DEGREE LIDAR PERIMETER INSPECTION] Inspecting Circular Deadlock...")
                print("=" * 72)
                print(f"  * Sector Front (315°-45°)   : {'BLOCKED (min: ' + f'{min(front_rays):.2f}m)' if min(front_rays) < 3.0 else 'OPEN (' + f'{min(front_rays):.2f}m)'}")
                print(f"  * Sector Left  (45°-135°)   : {'BLOCKED (min: ' + f'{min(left_rays):.2f}m)' if min(left_rays) < 3.0 else 'OPEN (' + f'{min(left_rays):.2f}m)'}")
                print(f"  * Sector Rear  (135°-225°)  : {'BLOCKED (min: ' + f'{min(rear_rays):.2f}m)' if min(rear_rays) < 3.0 else 'OPEN (' + f'{min(rear_rays):.2f}m)'}")
                print(f"  * Sector Right (225°-315°)  : {'BLOCKED (min: ' + f'{min(right_rays):.2f}m)' if min(right_rays) < 3.0 else 'OPEN (' + f'{min(right_rays):.2f}m)'}")
                print(f"  * Upward Vertical Ray (+Z)  : {sweep_data['vertical_clearance']:.2f}m (CLEAR)")
                print("-" * 72)

                if max_run >= 2:
                    self.ring_has_gap = True
                    self.ring_gap_bearing = best_bearing
                    print(f"  ==> DECISION: Horizontal opening verified at bearing {self.ring_gap_bearing:.1f}°. Escaping via gap...")
                else:
                    self.ring_has_gap = False
                    self.climb_state = "CLIMBING"
                    print("  ==> DECISION: Entire 360-degree perimeter is 100% solid with NO openings anywhere.")
                    print(f"      Executing Vertical Climb-Over Escape (climbing to {self.target_climb_altitude:.2f}m to fly over ring wall)...")
                print("=" * 72 + "\n")

        # 5. Navigation Decision / Motion Computation
        if self.scenario_id == 10 and not self.ring_has_gap and self.climb_state in ["CLIMBING", "FLYING_OVER", "DESCENDING"]:
            climb_rate = 0.35
            cruise_speed = 0.40

            to_goal_2d = self.goal_pos[:2] - current_pos[:2]
            dist_goal_2d = float(np.linalg.norm(to_goal_2d))
            dir_to_goal = to_goal_2d / (dist_goal_2d + 1e-6)
            dist_from_start = float(np.linalg.norm(current_pos[:2] - self.start_pos[:2]))

            if self.climb_state == "CLIMBING":
                self.current_altitude += climb_rate * dt
                if self.current_altitude >= self.target_climb_altitude:
                    self.current_altitude = self.target_climb_altitude
                    self.climb_state = "FLYING_OVER"
                    print(f"[RING ESCAPE] Reached altitude {self.current_altitude:.2f}m. Flying over ring wall toward goal...")
                desired_vel = np.array([dir_to_goal[0] * 0.15, dir_to_goal[1] * 0.15, climb_rate])
                yaw = float(np.arctan2(dir_to_goal[1], dir_to_goal[0]))
                omega = 0.0
                mode = "CLIMB_ESCAPE"
                done = False
                avoidance_info = {
                    "mode": mode,
                    "status_text": f"Climbing to {self.target_climb_altitude:.2f}m (alt={self.current_altitude:.2f}m)"
                }

            elif self.climb_state == "FLYING_OVER":
                self.current_altitude = self.target_climb_altitude
                desired_vel = np.array([dir_to_goal[0] * cruise_speed, dir_to_goal[1] * cruise_speed, 0.0])
                yaw = float(np.arctan2(dir_to_goal[1], dir_to_goal[0]))
                omega = 0.0
                mode = "FLY_OVER_RING"
                done = False
                avoidance_info = {
                    "mode": mode,
                    "status_text": f"Flying over ring wall at {self.current_altitude:.2f}m (dist_start={dist_from_start:.2f}m)"
                }
                if dist_from_start > 2.85 and current_pos[0] > 2.80:
                    self.climb_state = "DESCENDING"
                    print(f"[RING ESCAPE] Cleared ring footprint at x={current_pos[0]:.2f}m! Descending to nominal altitude {self.nominal_altitude:.2f}m...")

            elif self.climb_state == "DESCENDING":
                self.current_altitude -= climb_rate * dt
                if self.current_altitude <= self.nominal_altitude:
                    self.current_altitude = self.nominal_altitude
                    self.climb_state = "CLEARED"
                    print(f"[RING ESCAPE] Descended to {self.nominal_altitude:.2f}m. Resuming neural brain navigation to goal.")
                desired_vel = np.array([dir_to_goal[0] * cruise_speed, dir_to_goal[1] * cruise_speed, -climb_rate])
                yaw = float(np.arctan2(dir_to_goal[1], dir_to_goal[0]))
                omega = 0.0
                mode = "DESCEND_RETURN"
                done = False
                avoidance_info = {
                    "mode": mode,
                    "status_text": f"Descending to {self.nominal_altitude:.2f}m (alt={self.current_altitude:.2f}m)"
                }

            target_pos = current_pos + desired_vel * dt
            target_pos[2] = self.current_altitude

        elif self.algorithm_name in ["neural", "neural_brain", "adaptive_neural", "brain"]:
            v_cmd_2d, done = self.neural_brain.step(current_pos[:2], ray_distances)
            desired_vel = np.array([v_cmd_2d[0], v_cmd_2d[1], 0.0])
            target_pos = current_pos + desired_vel * dt
            target_pos[2] = self.nominal_altitude
            brain_info = self.neural_brain.last
            mode = brain_info.get("mode", "GOAL_SEEK")
            omega = float(brain_info.get("omega", 0.0))
            yaw = float(self.neural_brain.psi)
            avoidance_info = {
                "mode": mode,
                "status_text": f"NeuralBrain F={self.neural_brain.frustration:.2f} w_LL={self.neural_brain.w_self[0]:.2f}",
                "brain_info": brain_info
            }
        else:
            # Alternate avoidance algorithm mode
            if isinstance(self.avoidance, (ReactiveObstacleAvoidance, SINDyDWAAvoidance)):
                target_pos, desired_vel, avoidance_info = self.avoidance.compute_step(
                    current_pos, current_vel, perception_data,
                    dt=dt, full_sweep_fn=lambda: self.full_sweep(current_pos)
                )
            else:
                target_pos, desired_vel, avoidance_info = self.avoidance.compute_step(
                    current_pos, current_vel, perception_data, dt=dt
                )
            done = False
            yaw = float(np.arctan2(desired_vel[1], desired_vel[0])) if np.linalg.norm(desired_vel[:2]) > 0.05 else float(self.neural_brain.psi)
            omega = 0.0
            mode = avoidance_info.get("mode", "FORWARD")

        # 6. Direct Physics Integration (replaces PID controller)
        next_pos = current_pos + desired_vel * dt
        next_pos[2] = self.current_altitude

        qpos_adr = self.model.jnt_qposadr[self.root_jnt_id]
        qvel_adr = self.model.jnt_dofadr[self.root_jnt_id]

        self.data.qpos[qpos_adr:qpos_adr + 3] = next_pos
        self.data.qpos[qpos_adr + 3:qpos_adr + 7] = [
            np.cos(yaw / 2.0), 0.0, 0.0, np.sin(yaw / 2.0)
        ]
        self.data.qvel[qvel_adr:qvel_adr + 3] = desired_vel
        self.data.qvel[qvel_adr + 3:qvel_adr + 6] = [0.0, 0.0, omega]

        mujoco.mj_forward(self.model, self.data)

        # 7. Path Length Tracking
        step_disp = np.linalg.norm(next_pos - self.previous_pos)
        self.path_length += float(step_disp)
        self.previous_pos = next_pos.copy()

        self.step_count += 1
        self.sim_time = self.step_count * dt

        # Check Termination Criteria
        dist_to_goal = float(np.linalg.norm(self.goal_pos - next_pos))
        if dist_to_goal < self.neural_brain.cfg.goal_tolerance or done:
            self.result = "SUCCESS"
        elif next_pos[2] < 0.10:
            self.result = "GROUND CRASH"
        elif self.sim_time > 60.0:
            self.result = "TIME LIMIT REACHED"

        step_info = {
            "step": self.step_count,
            "sim_time": self.sim_time,
            "pos": next_pos,
            "vel": desired_vel,
            "dist_to_goal": dist_to_goal,
            "min_dist": min_dist,
            "target_pos": target_pos,
            "desired_vel": desired_vel,
            "mode": mode,
            "status_text": avoidance_info.get("status_text", ""),
            "perception": perception_data,
            "is_collision": is_collision,
            "collision_steps": self.collision_steps,
            "path_length": self.path_length,
            "result": self.result,
            "avoidance_info": avoidance_info
        }

        self.history.append({
            "time": self.sim_time,
            "pos": next_pos.copy(),
            "mode": step_info["mode"]
        })

        return step_info

    def get_summary(self):
        """Return final experiment performance dictionary."""
        pos, _, _, _ = self.get_drone_state()
        return {
            "scenario_id": self.scenario_id,
            "sub_scenario": self.sub_scenario if self.scenario_id == 10 else "default",
            "seed": self.seed if self.scenario_id == 10 else 0,
            "algorithm": self.algorithm_name,
            "result": self.result,
            "control_steps": self.step_count,
            "completion_time": round(self.sim_time, 2),
            "final_position": [round(float(x), 3) for x in pos],
            "path_length": round(self.path_length, 3),
            "collision_steps": self.collision_steps,
            "min_clearance": round(self.min_clearance, 3),
            "avoidance_events": getattr(self.avoidance, "avoidance_events", 0) if hasattr(self, "avoidance") else 0,
            "emergency_reversals": getattr(self.avoidance, "emergency_reversals", 0) if hasattr(self, "avoidance") else 0,
            "frustration": round(float(self.neural_brain.frustration), 3),
            "neural_w_self": [round(float(w), 3) for w in self.neural_brain.w_self],
            "escape_method": "vertical_climb" if (self.scenario_id == 10 and not self.ring_has_gap) else ("horizontal_gap" if (self.scenario_id == 10 and self.ring_has_gap) else "none")
        }
